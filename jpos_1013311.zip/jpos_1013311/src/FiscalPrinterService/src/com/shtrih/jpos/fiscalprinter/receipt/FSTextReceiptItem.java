/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shtrih.jpos.fiscalprinter.receipt;

/**
 *
 * @author Kravtsov
 */
public class FSTextReceiptItem {
    
    public FSTextReceiptItem(){
    }
    
    public String text = "";
    public String preLine = "";
    public String postLine = "";
}
