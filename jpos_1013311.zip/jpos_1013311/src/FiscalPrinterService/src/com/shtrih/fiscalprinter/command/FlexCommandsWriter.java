/*
 * FlexCommandsWriter.java
 *
 * Created on 19 ������ 2009 �., 16:49
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.shtrih.fiscalprinter.command;

/**
 * @author V.Kravtsov
 */
public class FlexCommandsWriter {

    /** Creates a new instance of FlexCommandsWriter */
    public FlexCommandsWriter() {
    }

}
