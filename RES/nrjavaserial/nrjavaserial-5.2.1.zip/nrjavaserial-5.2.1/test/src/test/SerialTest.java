package test;

import static org.junit.Assert.*;

import org.junit.Test;

public class SerialTest {

	@Test
	public void test() throws Exception {
		//mNRJavaSerialTest.main(new String[0]);
		//ReadTest.main(new String[0]);
	}

}
