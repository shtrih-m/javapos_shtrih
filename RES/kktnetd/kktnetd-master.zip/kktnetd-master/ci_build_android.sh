#!/bin/bash
set -e
CPU_NUM=$(grep processor /proc/cpuinfo|wc -l)
GIT_LAST_TAG=$(git describe --always --tags|cut -f1 -d-)
GIT_COMMITS_COUNT=$(git rev-list --count HEAD)
GIT_VERSION=$GIT_LAST_TAG.$GIT_COMMITS_COUNT
ANDROID_HOME=${ANDROID_HOME:="$HOME/Android/android-sdk-linux"}
export ANDROID_HOME=$ANDROID_HOME
NDK_PATH=${NDK_PATH:="$ANDROID_HOME/ndk-bundle"}


function compile()
{
    local ARCH=$1
    local API=$2

    echo "compiling for $ARCH"
    mkdir -p build/android/$ARCH
    mkdir -p dist/android_$GIT_VERSION/$ARCH/
    mkdir -p dist/android_$GIT_VERSION/java/src/ru/shtrih_m/kktnetd/
    cd build/android/$ARCH
    echo "building for ARCH: $ARCH, API $API"
    cmake ../../../  -DCMAKE_SYSTEM_NAME=Android  -DCMAKE_ANDROID_ARCH_ABI=$ARCH -DCMAKE_ANDROID_NDK="$NDK_PATH" -DCMAKE_SYSTEM_VERSION=$API -DCMAKE_BUILD_TYPE=Release
    make -j$CPU_NUM
    DIST_OUT_COPY_PATH="../../../dist/android_$GIT_VERSION/$ARCH/"
    mv kktnetd $DIST_OUT_COPY_PATH
    cmake ../../../ -DCMAKE_SYSTEM_NAME=Android -Dkktnetd_SHARED_LIBS=ON -DCMAKE_ANDROID_ARCH_ABI=$ARCH -DCMAKE_ANDROID_NDK="$NDK_PATH" -DCMAKE_SYSTEM_VERSION=$API -DCMAKE_BUILD_TYPE=Release
    make -j$CPU_NUM
    mv libkktnetd.so $DIST_OUT_COPY_PATH
    cd ../../../
    cp src/jni/ru/shtrih_m/kktnetd/Api.java dist/android_$GIT_VERSION/java/src/ru/shtrih_m/kktnetd/
}

compile "$1" "$2"

