#include "resender_app.h"
#include "impl/resender_impl.h"
#include <IO/lwipsocketio.h>
#include <asio/any_io_executor.hpp>
#include <asio/ip/address.hpp>
#include <asio/strand.hpp>
#include <asio/ts/buffer.hpp>
#include <asio/ts/internet.hpp>
#include <utils/asio_async_poster_factory.h>
#include <utils/lwipcorelocker.h>

KKTNETD_NAMESPACE_BEGIN
namespace apps
{

constexpr std::size_t max_length = 1024;

namespace
{

class server : public std::enable_shared_from_this<server>
{
  net::io_context& ctx_;
  const resender_app::params& params_;

  net::ip::tcp::acceptor acceptor_;
  net::ip::tcp::socket socket_;
  bool need_stop = false;

  public:
  server(net::io_context& io_context, const resender_app::params& params)
      : ctx_(io_context)
      , params_(params)
      , acceptor_(ctx_, net::ip::tcp::endpoint(net::ip::make_address_v4(params_.local_host_), params_.local_port_))
      , socket_(net::make_strand(io_context))
  {
  }

  private:
  void on_accept(net::error_code ec, net::ip::tcp::socket socket)
  {
    if (ec)
    {
      do_accept();
      return;
    }
    auto lwip_socket = std::make_unique<lwip_socket_io>(std::make_shared<asio_async_poster_factory>(ctx_), params_.remote_host_, params_.remote_port_);
    std::make_shared<resender_session>(std::move(socket), std::move(lwip_socket))->run();
    do_accept();
  }

  void do_accept()
  {
    if (need_stop)
    {
      return;
    }
    acceptor_.async_accept(net::make_strand(acceptor_.get_executor()), std::bind(&server::on_accept, shared_from_this(), std::placeholders::_1, std::placeholders::_2));
  }

  public:
  void run()
  {
    need_stop = false;
    do_accept();
  }
  void stop() { need_stop = true; }
};

} // namespace
resender_app::resender_app(net::io_context& ctx, std::string_view remote_host, uint16_t remote_port, std::string_view local_host, uint16_t local_port)
    : base_app(ctx)
    , params_({ string(local_host), local_port, string(remote_host), remote_port })
    , worker_(std::make_shared<server>(ctx_, params_))
{
}

void resender_app::run() { std::static_pointer_cast<server>(worker_)->run(); }
void resender_app::stop() { std::static_pointer_cast<server>(worker_)->stop(); }

} // namespace apps
KKTNETD_NAMESPACE_END
