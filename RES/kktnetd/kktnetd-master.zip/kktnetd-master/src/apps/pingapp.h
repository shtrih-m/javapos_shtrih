#ifndef PING_APP_H
#define PING_APP_H
#include "baselwipapp.h"
#include <pppos_netif.h>
#include <utils/log.h>
KKTNETD_NAMESPACE_BEGIN

namespace apps
{

class ping_app : public base_app
{
  std::string host_;
  std::shared_ptr<void> worker_;

  public:
  explicit ping_app(net::io_context& ctx, std::string_view host);

  public:
  void run() override;
  void stop() override;
};

} // namespace apps
KKTNETD_NAMESPACE_END
#endif // PING_APP_H
