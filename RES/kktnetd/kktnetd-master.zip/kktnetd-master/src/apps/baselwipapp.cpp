#include "baselwipapp.h"

KKTNETD_NAMESPACE_BEGIN
namespace apps
{

base_app::base_app(net::io_context& ctx)
    : ctx_(ctx)
{
}
base_app::~base_app() { }

} // namespace apps
KKTNETD_NAMESPACE_END
