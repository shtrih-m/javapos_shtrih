#ifndef RESENDER_APP_H
#define RESENDER_APP_H

#include "baselwipapp.h"

KKTNETD_NAMESPACE_BEGIN
namespace apps
{
class resender_app : public base_app
{
  public:
  struct params
  {
    u8string local_host_;
    uint16_t local_port_;
    u8string remote_host_;
    uint16_t remote_port_;
  };

  private:
  params params_;
  std::shared_ptr<void> worker_;

  public:
  explicit resender_app(net::io_context& ctx, std::string_view remote_host = "192.168.1.169", uint16_t remote_port = 7778, std::string_view local_host = "0.0.0.0", uint16_t local_port = 7778);

  void run() override;
  void stop() override;
};

} // namespace apps
KKTNETD_NAMESPACE_END
#endif // RESENDER_APP_H
