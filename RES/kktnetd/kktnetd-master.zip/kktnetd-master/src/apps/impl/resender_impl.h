//
// Created by swex on 8/20/21.
//

#ifndef KKTNETD_RESENDER_IMPL_H
#define KKTNETD_RESENDER_IMPL_H
#include <IO/lwipsocketio.h>
#include <asio/any_io_executor.hpp>
#include <asio/ip/address.hpp>
#include <asio/strand.hpp>
#include <asio/ts/buffer.hpp>
#include <asio/ts/internet.hpp>
#include <kktnet_common.h>
#include <utils/log.h>
#include <utils/lwipcorelocker.h>

KKTNETD_NAMESPACE_BEGIN
namespace apps
{

class resender_session : public std::enable_shared_from_this<resender_session>
{
  std::shared_ptr<spdlog::logger> logger_;
  asio::ip::tcp::socket socket_;
  std::unique_ptr<kktnetd::lwip_socket_io> lwip_socket_;
  enum
  {
    max_length = 512
  };
  std::array<char, max_length> socket_data;
  size_t last_socket_data_size;
  size_t last_socket_data_offset;

  std::array<char, max_length> lwip_data;
  size_t last_lwip_data_size;
  size_t last_lwip_data_offset;

  bool both_ok = true;

  public:
  resender_session(net::ip::tcp::socket socket, std::unique_ptr<kktnetd::lwip_socket_io> lwip_socket);
  virtual ~resender_session() = default;

  private:
  void _log_error(const std::error_code& ec, std::string_view op);

  void do_lwip_socket_open();
  void on_lwip_socket_opened(std::error_code ec);
  void on_lwip_socket_write(const std::error_code& ec, std::size_t bytes);
  void on_lwip_socket_read(const std::error_code& ec, std::size_t bytes);
  void do_lwip_socket_read();

  void on_socket_write(const std::error_code& ec, std::size_t bytes);
  void on_socket_read(const std::error_code& ec, std::size_t bytes);
  void do_socket_read();

  void do_read_both();

  public:
  void run();
};

} // namespace apps
KKTNETD_NAMESPACE_END
#endif // KKTNETD_RESENDER_IMPL_H
