//
// Created by swex on 8/19/21.
//

#include "pingapp_impl.h"
#include <utils/asio_util.h>
#include <utils/log.h>

#include <spdlog/fmt/bundled/chrono.h>
#include <spdlog/fmt/bundled/printf.h>
// clang-format off
/* C runtime includes */


extern "C" {
  /* lwIP core includes */
#include <lwip/icmp.h>
#include <lwip/inet_chksum.h>
#include <lwip/ip4.h>
#include <lwip/ip4_addr.h>
#include <lwip/prot/ip.h>
#include <lwip/sockets.h>
#include <lwip/sys.h>
}

// clang-format on
#ifndef PING_DEBUG
#  define PING_DEBUG LWIP_DBG_ON
#endif

/** ping receive timeout - in milliseconds */
#ifndef PING_RCV_TIMEO
#  define PING_RCV_TIMEO 1000
#endif

/** ping delay - in milliseconds */
#ifndef PING_DELAY
#  define PING_DELAY 2
#endif
/** ping identifier - must fit on a u16_t */
//#ifndef PING_ID
//#define PING_ID 0xAFAF
//#endif

/** ping additional data size to include in the packet */
#ifndef PING_DATA_SIZE
#  define PING_DATA_SIZE 32
#endif

/** ping result action - no default action */
#ifndef PING_RESULT
#  define PING_RESULT(ping_ok)
#endif
KKTNETD_NAMESPACE_BEGIN
struct pppos_if
{
  struct netif* netif();
};
namespace apps
{
std::shared_ptr<pingapp_impl::ping_ctx> pingapp_impl::send(std::string_view host, std::error_code& ec)
{
  auto result = std::make_shared<ping_ctx>();

  //  log_set_level(m_logger, spdlog::level::trace);

  /** Prepare a echo ICMP request */
  auto ping_prepare_echo = [&](struct icmp_echo_hdr* iecho, u16_t len)
  {
    size_t i;
    size_t data_len = len - sizeof(struct icmp_echo_hdr);

    ICMPH_TYPE_SET(iecho, ICMP_ECHO);
    ICMPH_CODE_SET(iecho, 0);
    iecho->chksum = 0;
    iecho->id = id_;
    iecho->seqno = lwip_htons(++seqnum_);

    /* fill the additional data buffer with some data */
    for (i = 0; i < data_len; i++)
    {
      ((char*)iecho)[sizeof(struct icmp_echo_hdr) + i] = (char)i;
    }

    iecho->chksum = inet_chksum(iecho, len);
  };

  /* Ping using the socket ip */
  auto ping_send = [&](int s, const ip_addr_t* addr)
  {
    ssize_t err;
    struct icmp_echo_hdr* iecho;
    struct sockaddr_storage to = { 0 };
    size_t ping_size = sizeof(struct icmp_echo_hdr) + PING_DATA_SIZE;

    LWIP_ASSERT("ping_size is too big", ping_size <= 0xffff);

#if LWIP_IPV6
    if (IP_IS_V6(addr) && !ip6_addr_isipv4mappedipv6(ip_2_ip6(addr)))
    {
      /* todo: support ICMP6 echo */
      return ERR_VAL;
    }
#endif /* LWIP_IPV6 */

    iecho = (struct icmp_echo_hdr*)mem_malloc((mem_size_t)ping_size);
    if (!iecho)
    {
      return ERR_MEM;
    }

    ping_prepare_echo(iecho, (u16_t)ping_size);

#if LWIP_IPV4
    if (IP_IS_V4(addr))
    {
      struct sockaddr_in* to4 = (struct sockaddr_in*)&to;
      to4->sin_len = sizeof(sockaddr_in);
      to4->sin_family = AF_INET;
      inet_addr_from_ip4addr(&to4->sin_addr, ip_2_ip4(addr));
    }
#endif /* LWIP_IPV4 */

#if LWIP_IPV6
    if (IP_IS_V6(addr))
    {
      struct sockaddr_in6* to6 = (struct sockaddr_in6*)&to;
      to6->sin6_len = sizeof(to6);
      to6->sin6_family = AF_INET6;
      inet6_addr_from_ip6addr(&to6->sin6_addr, ip_2_ip6(addr));
    }
#endif /* LWIP_IPV6 */

    err = lwip_sendto(s, iecho, ping_size, 0, (struct sockaddr*)&to, sizeof(to));

    mem_free(iecho);

    return (err ? ERR_OK : ERR_VAL);
  };

  int& lwip_socket_fd = result->fd;
  int ret;
  ip_addr_t ping_target;
  int addr_ok = ip4addr_aton(host.data(), ip_2_ip4(&ping_target));
  if (!addr_ok)
  {
    log_error(logger_, fmt::format("unable to get ip addr from {}", host));
    ec = std::error_code(EADDRNOTAVAIL, std::generic_category());
    return {};
  }

#if LWIP_IPV6
  if (IP_IS_V4(ping_target) || ip6_addr_isipv4mappedipv6(ip_2_ip6(ping_target)))
  {
    s = lwip_socket(AF_INET6, SOCK_RAW, IP_PROTO_ICMP);
  }
  else
  {
    s = lwip_socket(AF_INET6, SOCK_RAW, IP6_NEXTH_ICMP6);
  }
#else
  lwip_socket_fd = lwip_socket(AF_INET, SOCK_RAW, IP_PROTO_ICMP);
#endif
  if (lwip_socket_fd < 0)
  {
    log_error(logger_, "unable to get lwip socket");
    ec = std::error_code(errno, std::generic_category());
    return std::move(result);
  }
  ifreq ifreq { 0 };
  auto opt = lwip_fcntl(lwip_socket_fd, F_GETFL, 0);
  LWIP_ASSERT("lwip_fcntl opt != -1", opt != -1);
  opt |= O_NONBLOCK;
  ret = lwip_fcntl(lwip_socket_fd, F_SETFL, opt);
  LWIP_ASSERT("setting nonblock failed", ret == 0);
  LWIP_UNUSED_ARG(ret);

  if (ping_send(lwip_socket_fd, &ping_target) == ERR_OK)
  {
    result->sent_time = std::chrono::steady_clock::now();

    log_trace(logger_, "ping: send ");

    ec = {};
    return std::move(result);
  }
  else
  {
    log_trace(logger_, "ping: send ");
    ip_addr_debug_print(PING_DEBUG, &ping_target);
    log_trace(logger_, " - error");
  }
  lwip_close(lwip_socket_fd);
  ec = {};
  return std::move(result);
}

void pingapp_impl::recv(pingapp_impl::ping_ctx& ctx, std::error_code& ec)
{
  auto s = ctx.fd;
  char buf[64];
  int len = -1;
  struct sockaddr_storage from;
  int fromlen = sizeof(from);
  while (0 == 0)
  {
    len = lwip_recvfrom(s, buf, sizeof(buf), 0, (struct sockaddr*)&from, (socklen_t*)&fromlen);

    if (len > 0)
    {
      if (len >= (int)(sizeof(struct ip_hdr) + sizeof(struct icmp_echo_hdr)))
      {
        ip_addr_t fromaddr;
        memset(&fromaddr, 0, sizeof(fromaddr));

#if LWIP_IPV4
        if (from.ss_family == AF_INET)
        {
          struct sockaddr_in* from4 = (struct sockaddr_in*)&from;
          inet_addr_to_ip4addr(ip_2_ip4(&fromaddr), &from4->sin_addr);
          IP_SET_TYPE_VAL(fromaddr, IPADDR_TYPE_V4);
        }
#endif /* LWIP_IPV4 */

#if LWIP_IPV6
        if (from.ss_family == AF_INET6)
        {
          struct sockaddr_in6* from6 = (struct sockaddr_in6*)&from;
          inet6_addr_to_ip6addr(ip_2_ip6(&fromaddr), &from6->sin6_addr);
          IP_SET_TYPE_VAL(fromaddr, IPADDR_TYPE_V6);
        }
#endif /* LWIP_IPV6 */

        ip_addr_debug_print_val(PING_DEBUG, fromaddr);
        auto pong_time = std::chrono::steady_clock::now();
        ctx.diff_time = pong_time - ctx.sent_time;

        /* todo: support ICMP6 echo */
#if LWIP_IPV4
        if (IP_IS_V4_VAL(fromaddr))
        {
          struct ip_hdr* iphdr;
          struct icmp_echo_hdr* iecho;

          iphdr = (struct ip_hdr*)buf;
          iecho = (struct icmp_echo_hdr*)(buf + (IPH_HL(iphdr) * 4));
          if ((iecho->id == id_) && (iecho->seqno == lwip_htons(seqnum_)))
          {
            /* do some ping result processing */
            auto is_ok = ICMPH_TYPE(iecho) == ICMP_ER;
            log_trace(logger_, fmt::format("ping: recv  {} ms", ctx.diff_time));
            if (is_ok)
            {
              ec = {};
            }
            else
            {
              ec = std::error_code(EHOSTUNREACH, std::generic_category());
            }
            return;
          }
          else
          {
            ec = std::error_code(EHOSTUNREACH, std::generic_category());
            log_trace(logger_, fmt::format("ping: drop"));
          }
        }
#endif /* LWIP_IPV4 */
      }
      fromlen = sizeof(from);
    }
    else
    {
      ec = std::error_code(errno, std::generic_category());
      return;
    }
  }
}
pingapp_impl::pingapp_impl(uint16_t id, uint32_t seqnum)
    : id_(id)
    , seqnum_(seqnum)
{
}
pingapp_impl::~pingapp_impl() { }

pingapp_impl::ping_ctx::~ping_ctx()
{
  if (fd < 0)
  {
    return;
  }
  lwip_close(fd);
}
} // namespace apps
KKTNETD_NAMESPACE_END
