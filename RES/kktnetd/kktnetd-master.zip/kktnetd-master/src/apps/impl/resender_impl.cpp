//
// Created by swex on 8/20/21.
//

#include "resender_impl.h"
#include <IO/lwipsocketio.h>
#include <asio/any_io_executor.hpp>
#include <asio/ip/address.hpp>
#include <asio/strand.hpp>
#include <asio/ts/buffer.hpp>
#include <asio/ts/internet.hpp>
#include <errno.h>
#include <kktnet_common.h>
#include <utils/log.h>
#include <utils/lwipcorelocker.h>

KKTNETD_NAMESPACE_BEGIN

namespace apps
{

resender_session::resender_session(net::ip::tcp::socket socket, std::unique_ptr<lwip_socket_io> lwip_socket)
    : logger_(LOGGER_FOR_CLASSNAME(ra_session))
    , socket_(std::move(socket))
    , lwip_socket_(std::move(lwip_socket))
{
  //  log_set_level(logger_, spdlog::level::trace);
  std::error_code ec;
  auto ep = socket_.remote_endpoint(ec);
  if (ec)
  {
    log_error(logger_, fmt::format("unable to get remote socket endpoint: {}", ec.message()));
  }
  log_trace(logger_, fmt::format("connection from: {}:{}", ep.address().to_string(), ep.port()));
  net::ip::tcp::no_delay option(true);
  socket_.set_option(option, ec);
  if (ec)
  {
    log_error(logger_, fmt::format("unable to set TCP_NODELAY socket option", ec.message()));
  }
}
void resender_session::_log_error(const std::error_code& ec, std::string_view op)
{
  if (ec == net::error::eof)
  {
    log_debug(logger_, fmt::format("connection ended"));
  }
  else
  {
    log_error(logger_, fmt::format("connection ended: {}:{}", op, ec.message()));
  }
  both_ok = false;
  std::error_code l_ec;
  socket_.close(l_ec);
  lwip_socket_->close();
}
void resender_session::on_lwip_socket_read(const std::error_code& ec, std::size_t bytes)
{
  log_trace(logger_, fmt::format("{}: errno {}:{}, bytes: {}", __func__, ec.value(), ec.message(), bytes));

  if (ec == std::errc::operation_would_block || ec == std::errc::operation_in_progress || ec == std::errc::connection_already_in_progress)
  {
    do_lwip_socket_read();
    return;
  }
  else if (ec == std::errc::bad_file_descriptor || ec == std::errc::not_connected)
  {
    // WARNING: BUG somewhere in LWIP stack, it returns EBADF or ENOTCONN, but really file is so we check if and ignore if its alive
    if (lwip_socket_->is_alive())
    {
      do_lwip_socket_read();
      return;
    }
    _log_error(ec, __func__);
    return;
  }
  else if (ec)
  {
    _log_error(ec, __func__);
    return;
  }
  if (bytes == 0)
  {
    do_lwip_socket_read();
    return;
  }

  last_lwip_data_size = bytes;
  last_lwip_data_offset = 0;
  net::async_write(socket_, net::buffer(lwip_data.data(), bytes), std::bind(&resender_session::on_socket_write, shared_from_this(), std::placeholders::_1, std::placeholders::_2));
}
void resender_session::on_lwip_socket_write(const std::error_code& ec, std::size_t bytes)
{
  log_trace(logger_, fmt::format("{}: errno {}:{}, bytes: {}", __func__, ec.value(), ec.message(), bytes));

  if (ec)
  {
    _log_error(ec, __func__);
    return;
  }
  if (bytes != last_socket_data_size)
  {
    last_socket_data_offset += bytes;
    last_socket_data_size -= bytes;
    lwip_socket_->async_write_some(
        net::buffer(socket_data.data() + last_lwip_data_offset, last_socket_data_size),
        std::bind(&resender_session::on_lwip_socket_write, shared_from_this(), std::placeholders::_1, std::placeholders::_2));
    return;
  }
  do_socket_read();
}
void resender_session::do_lwip_socket_read()
{
  if (!both_ok)
  {
    return;
  }
  lwip_socket_->async_read_some(net::buffer(lwip_data), std::bind(&resender_session::on_lwip_socket_read, shared_from_this(), std::placeholders::_1, std::placeholders::_2));
}
void resender_session::on_socket_write(const std::error_code& ec, std::size_t bytes)
{
  log_trace(logger_, fmt::format("{}: errno {}:{}, bytes: {}", __func__, ec.value(), ec.message(), bytes));

  if (ec)
  {
    _log_error(ec, __func__);
    return;
  }
  if (bytes != last_lwip_data_size)
  {
    last_lwip_data_offset += bytes;
    last_lwip_data_size -= bytes;
    net::async_write(
        socket_, net::buffer(lwip_data.data() + last_lwip_data_offset, last_lwip_data_size),
        std::bind(&resender_session::on_socket_write, shared_from_this(), std::placeholders::_1, std::placeholders::_2));
    return;
  }
  do_lwip_socket_read();
}
void resender_session::on_socket_read(const std::error_code& ec, std::size_t bytes)
{
  log_trace(logger_, fmt::format("{}: errno {}:{}, bytes: {}", __func__, ec.value(), ec.message(), bytes));

  if (ec == net::error::would_block)
  {
    do_socket_read();
    return;
  }

  else if (ec)
  {
    _log_error(ec, __func__);
    return;
  }
  if (bytes == 0)
  {
    do_socket_read();
    return;
  }
  last_socket_data_size = bytes;
  last_socket_data_offset = 0;

  lwip_socket_->async_write_some(net::buffer(socket_data.data(), bytes), std::bind(&resender_session::on_lwip_socket_write, shared_from_this(), std::placeholders::_1, std::placeholders::_2));
}
void resender_session::do_socket_read()
{
  if (!both_ok)
  {
    return;
  }
  net::async_read(socket_, net::buffer(socket_data), net::transfer_at_least(1), std::bind(&resender_session::on_socket_read, shared_from_this(), std::placeholders::_1, std::placeholders::_2));
}
void resender_session::do_read_both()
{
  log_debug(logger_, "start reading both sockets");

  do_socket_read();
  do_lwip_socket_read();
}
void resender_session::on_lwip_socket_opened(std::error_code ec)
{
  if (ec)
  {
    _log_error(ec, __func__);
    log_error(logger_, fmt::format("unable to open lwip_socket: {}", ec.message()));
    return;
  }
  log_debug(logger_, "lwip socket opened");
  do_read_both();
}
void resender_session::do_lwip_socket_open()
{
  if (lwip_socket_->is_alive()) // already opened case
  {
    on_lwip_socket_opened({});
    return;
  }
  lwip_socket_->async_connect(std::bind(&resender_session::on_lwip_socket_opened, shared_from_this(), std::placeholders::_1));
}
void resender_session::run() { do_lwip_socket_open(); }

} // namespace apps
KKTNETD_NAMESPACE_END