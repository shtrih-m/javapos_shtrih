#ifndef KKTNETWORKDAEMON_H
#define KKTNETWORKDAEMON_H

#include <kktnet_common.h>

#include <asio/io_context.hpp>

KKTNETD_NAMESPACE_BEGIN

class lwip_stack
{
  net::io_context& ctx_;

  public:
  explicit lwip_stack(net::io_context& ctx);
  ~lwip_stack();
  /**
   * @brief exec mainloop
   */
  void run();
};
KKTNETD_NAMESPACE_END
#endif // KKTNETWORKDAEMON_H
