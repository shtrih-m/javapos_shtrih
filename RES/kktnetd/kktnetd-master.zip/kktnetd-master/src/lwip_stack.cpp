#include "lwip_stack.h"
#include <IO/serialio.h>
#include <impl/lwip_stack_impl.h>
#include <spdlog/logger.h>
#include <utils/log.h>

KKTNETD_NAMESPACE_BEGIN

lwip_stack::lwip_stack(net::io_context& ctx)
    : ctx_(ctx)
{
}

lwip_stack::~lwip_stack() { }
void lwip_stack::run() { lwip_stack_impl::init(); }

KKTNETD_NAMESPACE_END
