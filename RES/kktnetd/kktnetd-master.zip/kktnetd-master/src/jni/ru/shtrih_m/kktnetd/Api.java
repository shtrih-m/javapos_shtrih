package ru.shtrih_m.kktnetd;

public class Api{
    static{
        System.loadLibrary("kktnetd");
    }
    //the function is defined in a c-file
    public static native int start(final String name);
    public static native void stop();
}
