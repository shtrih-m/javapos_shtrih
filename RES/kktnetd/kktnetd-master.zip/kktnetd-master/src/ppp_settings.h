/*  clang-format off */
#ifdef _MSC_VER
#pragma warning (disable: 4242) /* PPP only: conversion from 'x' to 'y', possible loss of data */
#pragma warning (disable: 4244) /* PPP only: conversion from 'x' to 'y', possible loss of data (again?) */
#pragma warning (disable: 4310) /* PPP only: cast truncates constant value */
#pragma warning (disable: 4706) /* PPP only: assignment within conditional expression */
#endif /* MSC_VER  */
/*  clang-format on */
#define PPP_SERVER 1
#undef PPPOE_SUPPORT
#define PPPOE_SUPPORT 0
#define PPP_NOTIFY_PHASE 1
#define LWIP_PPP_API 0
/* 
//#define MEMP_NUM_PPP_PCB 4
//// test minimize MRU
////#define PPP_DEFMRU 4
//#define PPP_MAXMRU 16384
////#define PPP_MRU PPP_DEFMRU
//#define PPP_MINMRU 1
*/
