//
// Created by swex on 8/17/21.
//

#include "lwip_ppp_interface.h"

extern "C"
{
  /* lwIP core includes */
#include "lwip/opt.h"

#include "lwip/api.h"
#include "lwip/debug.h"
#include "lwip/init.h"
#include "lwip/netif.h"
#include "lwip/stats.h"
#include "lwip/sys.h"
#include "lwip/tcpip.h"
#include "lwip/timeouts.h"

#include "lwip/autoip.h"
#include "lwip/dhcp.h"
#include "lwip/dns.h"
#include "lwip/tcp.h"
#include "lwip/udp.h"

  /* lwIP netif includes */
#include "lwip/etharp.h"
#include "netif/ethernet.h"
#if NO_SYS
  /* ... then we need information about the timer intervals: */
#include "lwip/igmp.h"
#include "lwip/ip4_frag.h"
#endif /* NO_SYS */

#include "netif/ppp/ppp_opts.h"
#if PPP_SUPPORT
  /* PPP includes */
#include "netif/ppp/pppapi.h"
#include "netif/ppp/pppos.h"
#endif /* PPP_SUPPORT */

  /* include the port-dependent configuration */
#include "lwipcfg.h"
}
/* This function initializes applications */

#if LWIP_NETIF_STATUS_CALLBACK

static auto netifLogger = []()
{
  static auto logger = getLog("lwip netif");
  return logger;
};

static void status_callback(struct netif* state_netif)
{
  static auto logger = netifLogger();
  if (netif_is_up(state_netif))
  {
#if LWIP_IPV4
    logger->info("status_callback==UP, local interface IP is {}", ip4addr_ntoa(netif_ip4_addr(state_netif)));
#else
    me->m_logger->debug("status_callback==UP");
#endif
  }
  else
  {
    logger->info("status_callback==DOWN");
  }
}
#if LWIP_NETIF_LINK_CALLBACK static void link_callback(struct netif * state_netif)
{
  static auto logger = netifLogger();

  if (netif_is_link_up(state_netif))
  {
    logger->info("link_callback==UP");
  }
  else
  {
    logger->info("link_callback==DOWN");
  }
}
#endif /* LWIP_NETIF_LINK_CALLBACK */

static void linkStatusCallback(ppp_pcb* pcb, int errCode, void* ctx)
{
  struct netif* pppif = ppp_netif(pcb);
  auto me = static_cast<pppos_if*>(ctx);
  switch (errCode)
  {
  case PPPERR_NONE:
  { /* No error. */

    me->m_logger->debug("PPPERR_NONE");
#if LWIP_IPV4
    me->m_logger->debug("   our_ipaddr  = {}", ip4addr_ntoa(netif_ip4_addr(pppif)));
    me->m_logger->debug("   his_ipaddr  = {}", ip4addr_ntoa(netif_ip4_gw(pppif)));
    me->m_logger->debug("   netmask     = {}", ip4addr_ntoa(netif_ip4_netmask(pppif)));
#endif /* LWIP_IPV4 */
#if LWIP_DNS
    me->m_logger->debug("   dns1        = {}", ipaddr_ntoa(dns_getserver(0)));
    me->m_logger->debug("   dns2        = {}", ipaddr_ntoa(dns_getserver(1)));
#endif /* LWIP_DNS */
#if PPP_IPV6_SUPPORT
    me->m_logger->debug("   our6_ipaddr = {}", ip6addr_ntoa(netif_ip6_addr(pppif, 0)));
#endif /* PPP_IPV6_SUPPORT */
    apps_init(me);
    return;
  }
  case PPPERR_PARAM:
  { /* Invalid parameter. */
    me->m_logger->debug("PPPERR_PARAM");
    break;
  }
  case PPPERR_OPEN:
  { /* Unable to open PPP session. */
    me->m_logger->debug("PPPERR_OPEN");
    break;
  }
  case PPPERR_DEVICE:
  { /* Invalid I/O device for PPP. */
    me->m_logger->debug("PPPERR_DEVICE");
    break;
  }
  case PPPERR_ALLOC:
  { /* Unable to allocate resources. */
    me->m_logger->debug("PPPERR_ALLOC");
    break;
  }
  case PPPERR_USER:
  { /* User interrupt. */
    me->m_logger->debug("PPPERR_USER");
    break;
  }
  case PPPERR_CONNECT:
  { /* Connection lost. */
    me->m_logger->debug("PPPERR_CONNECT");
    break;
  }
  case PPPERR_AUTHFAIL:
  { /* Failed authentication challenge. */
    me->m_logger->debug("PPPERR_AUTHFAIL");
    break;
  }
  case PPPERR_PROTOCOL:
  { /* Failed to meet protocol. */
    me->m_logger->debug("PPPERR_PROTOCOL");
    break;
  }
  case PPPERR_PEERDEAD:
  { /* Connection timeout */
    me->m_logger->debug("PPPERR_PEERDEAD");
    break;
  }
  case PPPERR_IDLETIMEOUT:
  { /* Idle Timeout */
    me->m_logger->debug("PPPERR_IDLETIMEOUT");
    break;
  }
  case PPPERR_CONNECTTIME:
  { /* Max connect time reached */
    me->m_logger->debug("PPPERR_CONNECTTIME");
    break;
  }
  case PPPERR_LOOPBACK:
  { /* Loopback detected */
    me->m_logger->debug("PPPERR_LOOPBACK");
    break;
  }
  default:
  {
    me->m_logger->debug("unknown errCode {}", errCode);
    break;
  }
  }
}
#endif /* LWIP_NETIF_STATUS_CALLBACK */