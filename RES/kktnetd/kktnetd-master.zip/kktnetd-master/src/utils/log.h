﻿#ifndef LOG_H
#define LOG_H

#include <kktnet_common.h>
#include <memory>
#include <spdlog/common.h>
#include <spdlog/fmt/fmt.h>
//#include <spdlog/logger.h> we can't

namespace spdlog
{
class logger;
namespace sinks
{
class sink;
}
} // namespace spdlog

KKTNETD_NAMESPACE_BEGIN

using logger = std::shared_ptr<spdlog::logger>;
void log_debug(logger logger, std::string_view message);
void log_trace(logger logger, std::string_view message);
void log_error(logger logger, std::string_view message);
void log_info(logger logger, std::string_view message);
void log_set_level(logger, spdlog::level::level_enum level);
void log_levels(std::string_view levels);
/**
 * @brief createLogSink sink factory
 * sink returned based on next process environment variables:
 * **KKTNETD_DEBUG_CONSOLE** - if defined all log output goes to platform stdout
 * **KKTNETD_LOG_PATH** - log file path
 *     default: 'fr_drv.log' in current working directory
 * **KKTNETD_LOG_FILE_COUNT** - log file rotation parts count
 *     default: 2
 * **KKTNETD_LOG_PART_SIZE** - size of each part in bytes
 *     default: 10485760
 * @return sink
 */
std::shared_ptr<spdlog::sinks::sink> createLogSink();
/**
 * @brief getLog factory function to get logger object all with the same output sink.

 * @param prefix to use with current logger
 * @return
 */
logger getLog(const std::string& prefix = "log") noexcept;

KKTNETD_NAMESPACE_END

#define LOGGER_FOR_INSTANCE(CLASS) m_logger(getLog(fmt::format(#CLASS "_{}", static_cast<void*>(this))))

#define LOGGER_FOR_CLASSNAME(CLASS) getLog(fmt::format(#CLASS "_{}", static_cast<void*>(this)))
#define LOGGER_FOR_FUNCTION() static auto logger = getLog(__FUNCTION__);

#endif // LOG_H
