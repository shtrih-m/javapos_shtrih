//
// Created by swex on 8/19/21.
//

#ifndef KKTNETD_ASYNC_POSTER_H
#define KKTNETD_ASYNC_POSTER_H
#include <functional>
#include <kktnet_common.h>
#include <memory>

KKTNETD_NAMESPACE_BEGIN

/**
 * @brief скрывашка системных socket api от lwip
 * для асинхронного поста в io_loop
 */
struct async_poster
{
  virtual ~async_poster() = default;
  virtual void post(std::function<void()> fn) = 0;
};

struct async_poster_factory
{
  virtual ~async_poster_factory() = default;
  virtual std::unique_ptr<async_poster> make() const = 0;
};
KKTNETD_NAMESPACE_END

#endif // KKTNETD_ASYNC_POSTER_H
