﻿#ifndef ANDROIDHELPER_H
#define ANDROIDHELPER_H
#include <jni.h>
#include <vector>
#include <kktnet_common.h>

KKTNETD_NAMESPACE_BEGIN

class JniEnvHolder {
    JNIEnv* m_env = nullptr;
    JavaVM* m_vm = nullptr;
    bool m_attached = false;

public:
    JNIEnv* env();
    explicit JniEnvHolder(JavaVM* jvm);
    ~JniEnvHolder();
};

class AndroidHelper {
    explicit AndroidHelper(JavaVM* vm);
    jint init();

public:
    JavaVM* jvm;
    JNIEnv* oldenv;
    JniEnvHolder env();
    void cleanup();
#ifdef BTSERIAL_IO
    jclass BluetoothAdapter;
    jclass UUID;
    jmethodID UUID_fromString;
    jobject RFCOMM_UUID_OBJECT;
    jmethodID BluetoothAdapter_getDefaultAdapter;
    jmethodID BluetoothAdapter_cancelDiscovery;
    jmethodID BluetoothAdapter_getRemoteDevice;
    jmethodID BluetoothAdapter_getState;
    jclass BluetoothDevice;
    jmethodID BluetoothDevice_createInsecureRfcommSocketToServiceRecord;
    jclass BluetoothSocket;
    jmethodID BluetoothSocket_connect;
    jmethodID BluetoothSocket_close;
    jmethodID BluetoothSocket_isConnected;
    jmethodID BluetoothSocket_getInputStream;
    jmethodID BluetoothSocket_getOutputStream;
    jclass InputStream;
    jmethodID InputStream_avaliable;
    jmethodID InputStream_read;
    jclass OutputStream;
    jmethodID OutputStream_write;
#endif
    jclass UsbCdcAcmHelper;
    jmethodID UsbCdcAcmHelper_getFd;
    jmethodID UsbCdcAcmHelper_setFd;
    jmethodID UsbCdcAcmHelper_updateFd;
    std::vector<jobject> globalRefs;
    bool initOk;

public:
    static AndroidHelper& instance(JavaVM* vm);
};
KKTNETD_NAMESPACE_END
#endif // ANDROIDHELPER_H
