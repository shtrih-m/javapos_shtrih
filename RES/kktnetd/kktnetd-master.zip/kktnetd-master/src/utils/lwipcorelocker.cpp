#include "lwipcorelocker.h"

extern "C"
{
#include <lwipopts.h>
}
KKTNETD_NAMESPACE_BEGIN
extern bool LWIP_STACK_INITIALIZED;
LWIPCoreLocker::LWIPCoreLocker()
{
  if (!LWIP_STACK_INITIALIZED)
  {
    return;
  }
  sys_lock_tcpip_core();
}

LWIPCoreLocker::~LWIPCoreLocker()
{
  if (!LWIP_STACK_INITIALIZED)
  {
    return;
  }
  sys_unlock_tcpip_core();
}

KKTNETD_NAMESPACE_END
