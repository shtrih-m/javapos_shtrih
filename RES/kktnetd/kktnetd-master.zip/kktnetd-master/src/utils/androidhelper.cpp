﻿#include "androidhelper.h"
#include "util.h"
#include <jni.h>
#include <vector>

#ifdef __cplusplus
extern "C"
{
#endif

  JNIEXPORT jint JNI_OnLoad(JavaVM* vm, void*)
  {
    try
    {
      auto helper = __KKTNETD_NAMESPACE__::AndroidHelper::instance(vm);
      return JNI_VERSION_1_6;
    }
    catch (...)
    {
      return JNI_ERR;
    }
  }

  JNIEXPORT void JNI_OnUnload(JavaVM* vm, void*)
  {
    auto helper = __KKTNETD_NAMESPACE__::AndroidHelper::instance(vm);
    helper.cleanup();
  }

#ifdef __cplusplus
}
#endif

#define DECLARE_GLOBAL_JAVA_CLASS(VAR, NAME)                                                                                                                                                           \
  VAR = env->FindClass((NAME));                                                                                                                                                                        \
  if (!VAR)                                                                                                                                                                                            \
    return JNI_ERR;                                                                                                                                                                                    \
  VAR = reinterpret_cast<jclass>(env->NewGlobalRef((VAR)));                                                                                                                                            \
  if (!VAR)                                                                                                                                                                                            \
    return JNI_ERR;                                                                                                                                                                                    \
  globalRefs.push_back((VAR));

KKTNETD_NAMESPACE_BEGIN

static const char* RFRCOMM_UUID = "00001101-0000-1000-8000-00805F9B34FB";

JniEnvHolder AndroidHelper::env() { return JniEnvHolder(jvm); }

void AndroidHelper::cleanup()
{
  auto holder = env();
  auto env = holder.env();
  for (auto&& ref : globalRefs)
  {
    env->DeleteGlobalRef(ref);
  }
}

AndroidHelper::AndroidHelper(JavaVM* vm)
    : jvm(vm)
{
  auto ret = init();
  if (ret != JNI_VERSION_1_6)
  {
    throw std::runtime_error("no java classes found");
  }
}

jint AndroidHelper::init()
{
  auto holder = env();
  auto env = holder.env();
#ifdef BTSERIAL_IO
  DECLARE_GLOBAL_JAVA_CLASS(BluetoothAdapter, "android/bluetooth/BluetoothAdapter");
  DECLARE_GLOBAL_JAVA_CLASS(BluetoothDevice, "android/bluetooth/BluetoothDevice");
  DECLARE_GLOBAL_JAVA_CLASS(BluetoothSocket, "android/bluetooth/BluetoothSocket");
  UUID = env->FindClass("java/util/UUID");
  if (!UUID)
    return JNI_ERR;
  DECLARE_GLOBAL_JAVA_CLASS(InputStream, "java/io/InputStream");
  DECLARE_GLOBAL_JAVA_CLASS(OutputStream, "java/io/OutputStream");
  BluetoothAdapter_getDefaultAdapter = env->GetStaticMethodID(BluetoothAdapter, "getDefaultAdapter", "()Landroid/bluetooth/BluetoothAdapter;");
  if (!BluetoothAdapter_getDefaultAdapter)
    return JNI_ERR;

  BluetoothAdapter_cancelDiscovery = env->GetMethodID(BluetoothAdapter, "cancelDiscovery", "()Z");
  if (!BluetoothAdapter_cancelDiscovery)
    return JNI_ERR;
  BluetoothAdapter_getState = env->GetMethodID(BluetoothAdapter, "getState", "()I");
  if (!BluetoothAdapter_getState)
  {
    return JNI_ERR;
  }
  BluetoothAdapter_getRemoteDevice = env->GetMethodID(BluetoothAdapter, "getRemoteDevice", "(Ljava/lang/String;)Landroid/bluetooth/BluetoothDevice;");
  if (!BluetoothAdapter_getRemoteDevice)
    return JNI_ERR;

  BluetoothDevice_createInsecureRfcommSocketToServiceRecord = env->GetMethodID(BluetoothDevice, "createInsecureRfcommSocketToServiceRecord", "(Ljava/util/UUID;)Landroid/bluetooth/BluetoothSocket;");
  if (!BluetoothDevice_createInsecureRfcommSocketToServiceRecord)
    return JNI_ERR;

  BluetoothSocket_connect = env->GetMethodID(BluetoothSocket, "connect", "()V");
  if (!BluetoothSocket_connect)
    return JNI_ERR;

  BluetoothSocket_isConnected = env->GetMethodID(BluetoothSocket, "isConnected", "()Z");
  if (!BluetoothSocket_isConnected)
    return JNI_ERR;

  BluetoothSocket_close = env->GetMethodID(BluetoothSocket, "close", "()V");
  if (!BluetoothSocket_close)
    return JNI_ERR;

  BluetoothSocket_getInputStream = env->GetMethodID(BluetoothSocket, "getInputStream", "()Ljava/io/InputStream;");
  if (!BluetoothSocket_getInputStream)
    return JNI_ERR;

  InputStream_read = env->GetMethodID(InputStream, "read", "([BII)I");
  if (!InputStream_read)
    return JNI_ERR;

  InputStream_avaliable = env->GetMethodID(InputStream, "available", "()I");
  if (!InputStream_avaliable)
    return JNI_ERR;

  BluetoothSocket_getOutputStream = env->GetMethodID(BluetoothSocket, "getOutputStream", "()Ljava/io/OutputStream;");
  if (!BluetoothSocket_getOutputStream)
    return JNI_ERR;

  OutputStream_write = env->GetMethodID(OutputStream, "write", "([BII)V");
  if (!OutputStream_write)
    return JNI_ERR;

  UUID_fromString = env->GetStaticMethodID(UUID, "fromString", "(Ljava/lang/String;)Ljava/util/UUID;");
  if (!UUID_fromString)
    return JNI_ERR;

  jstring uuid_jstring = env->NewStringUTF(RFRCOMM_UUID);
  RFCOMM_UUID_OBJECT = env->CallStaticObjectMethod(UUID, UUID_fromString, uuid_jstring);
  env->DeleteLocalRef(uuid_jstring);
  if (!RFCOMM_UUID_OBJECT)
    return JNI_ERR;
  RFCOMM_UUID_OBJECT = env->NewGlobalRef(RFCOMM_UUID_OBJECT);
  globalRefs.push_back(RFCOMM_UUID_OBJECT);
#endif
  DECLARE_GLOBAL_JAVA_CLASS(UsbCdcAcmHelper, "ru/shtrih_m/fr_drv_ng/android_util/UsbCdcAcmHelper");
  UsbCdcAcmHelper_getFd = env->GetStaticMethodID(UsbCdcAcmHelper, "getFd", "()I");
  if (!UsbCdcAcmHelper_getFd)
  {
    return JNI_ERR;
  }
  UsbCdcAcmHelper_setFd = env->GetStaticMethodID(UsbCdcAcmHelper, "setFd", "(I)V");
  if (!UsbCdcAcmHelper_setFd)
  {
    return JNI_ERR;
  }
  UsbCdcAcmHelper_updateFd = env->GetStaticMethodID(UsbCdcAcmHelper, "updateFd", "()V");
  if (!UsbCdcAcmHelper_updateFd)
  {
    return JNI_ERR;
  }
  initOk = true;
  return JNI_VERSION_1_6;
}

AndroidHelper& AndroidHelper::instance(JavaVM* vm)
{
  static AndroidHelper me(vm);
  return me;
}

JNIEnv* JniEnvHolder::env() { return m_env; }

JniEnvHolder::JniEnvHolder(JavaVM* jvm)
    : m_vm(jvm)
{
  auto ret = jvm->GetEnv(reinterpret_cast<void**>(&m_env), JNI_VERSION_1_6);
  if (ret == JNI_OK) { }
  else if (ret == JNI_EDETACHED)
  {
    if (jvm->AttachCurrentThread(&m_env, nullptr) == JNI_OK)
    {
      m_attached = true;
    }
  }
}

JniEnvHolder::~JniEnvHolder()
{
  if (m_attached)
  {
    m_vm->DetachCurrentThread();
  }
}
KKTNETD_NAMESPACE_END
