//
// Created by swex on 8/21/21.
//

#ifndef KKTNETD_ASIO_ASYNC_POSTER_FACTORY_H
#define KKTNETD_ASIO_ASYNC_POSTER_FACTORY_H
#include <asio/io_context.hpp>
#include <kktnet_common.h>
#include <utils/async_poster.h>

KKTNETD_NAMESPACE_BEGIN

class asio_async_poster_factory : public async_poster_factory
{
  net::io_context& ctx_;

  public:
  explicit asio_async_poster_factory(net::io_context& ctx);
  std::unique_ptr<async_poster> make() const override;
};

KKTNETD_NAMESPACE_END
#endif // KKTNETD_ASIO_ASYNC_POSTER_FACTORY_H
