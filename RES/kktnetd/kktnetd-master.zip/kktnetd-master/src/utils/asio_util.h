//
// Created by swex on 8/20/21.
//

#ifndef KKTNETD_ASIO_UTIL_H
#define KKTNETD_ASIO_UTIL_H
#include "async_poster.h"
#include <kktnet_common.h>
#include <system_error>

KKTNETD_NAMESPACE_BEGIN

namespace asio_util
{
const std::error_category& get_system_category();
const std::error_category& get_misc_category();
const std::error_category& get_addrinfo_category();
const std::error_category& get_netdb_category();

} // namespace asio_util
KKTNETD_NAMESPACE_END
#endif // KKTNETD_ASIO_UTIL_H
