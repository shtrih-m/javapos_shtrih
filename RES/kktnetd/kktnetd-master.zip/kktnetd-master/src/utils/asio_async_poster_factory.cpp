#include "asio_async_poster_factory.h"
#include <asio/steady_timer.hpp>
#include <utils/log.h>

KKTNETD_NAMESPACE_BEGIN

struct io_poster : public async_poster
{
  net::io_context& ctx_;
  net::steady_timer timer_;
  std::shared_ptr<spdlog::logger> logger_;
  std::chrono::milliseconds timeout_ms_;

  void post(std::function<void()> fn) override
  {
    //    ctx_.post(fn);
    auto timer = std::make_shared<net::steady_timer>(ctx_);
    timer->expires_from_now(timeout_ms_);
    timer->async_wait(
        [timer, this, fn](const std::error_code& ec)
        {
          if (ec)
          {
            log_error(logger_, fmt::format("timer error: {}: {}", ec.value(), ec.message()));
          }
          fn();
        });
  }
  explicit io_poster(net::io_context& ctx, std::chrono::milliseconds timeout_ms = std::chrono::milliseconds(1))
      : ctx_(ctx)
      , timer_(net::steady_timer(ctx))
      , logger_(LOGGER_FOR_CLASSNAME(timed_io_poster))
      , timeout_ms_(timeout_ms)
  {
  }
};

asio_async_poster_factory::asio_async_poster_factory(asio::io_context& ctx)
    : ctx_(ctx)
{
}

std::unique_ptr<async_poster> asio_async_poster_factory::make() const
{
  return std::make_unique<io_poster>(ctx_);
  ;
}

KKTNETD_NAMESPACE_END
