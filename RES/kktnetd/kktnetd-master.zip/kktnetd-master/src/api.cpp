#include "api.h"
#include <apps/pingapp.h>
#include <apps/resender_app.h>
#include <apps/socks5app.h>
#include <asio/ip/tcp.hpp>
#include <asio/local/stream_protocol.hpp>
#include <asio/read.hpp>
#include <asio/serial_port.hpp>
#include <asio/signal_set.hpp>
#include <asio/strand.hpp>
#include <asio/write.hpp>
#include <iostream>
#include <lwip_stack.h>
#include <mutex>
#include <optional>
#include <pppos_netif.h>
#include <queue>
#include <random>
#include <spdlog/logger.h>
#include <utils/async_poster.h>
#include <utils/log.h>

#ifdef __ANDROID__
#  include <jni/ru_shtrih_m_kktnetd_Api.h>
#endif //__ANDROID__
#ifdef _WIN32
#  include <signal.h>
//#include <winbase.h>
#endif
static __KKTNETD_NAMESPACE__::logger getLWIPLog()
{
  static auto logger = __KKTNETD_NAMESPACE__::getLog("LWIP");
  logger->set_level(spdlog::level::trace);
  return logger;
}
#ifdef __cplusplus
extern "C"
{
#endif

  void spdlogWrapper(const char* fmt, ...)
  {
    static auto logger = getLWIPLog();

    std::array<char, 1024> buf;
    va_list myargs;

    /* Initialise the va_list variable with the ... after fmt */

    va_start(myargs, fmt);

    /* Forward the '...' to vprintf */
    auto ret = vsnprintf(buf.data(), buf.size(), fmt, myargs);
    /* Clean up the va_list */
    va_end(myargs);
    if (buf[ret - 1] == '\n')
    {
      buf[ret - 1] = 0; // cut \n
    }
    logger->debug(buf.data());
  }

#ifdef __cplusplus
}
#endif

KKTNETD_NAMESPACE_BEGIN
static void handle_signal(int signal)
{
  const char* signal_name;

  // Find out which signal we're handling
  switch (signal)
  {
#ifndef _WIN32
  case SIGHUP:
    signal_name = "SIGHUP";
    break;
  case SIGUSR1:
    signal_name = "SIGUSR1";
    break;
#endif // ifndef _WIN32
  case SIGINT:
    printf("Caught SIGINT, exiting now\n");
    exit(0);
    break;
  case SIGTERM:
    printf("Caught SIGTERM stopping daemon\n");
    exit(0);
    break;
  default:
    fprintf(stderr, "Caught wrong signal: %d\n", signal);
    return;
  }
}
static void signal_handler(const net::error_code& ec, int signum)
{
  if (ec)
  {
    perror(ec.message().c_str());
    return;
  }
  handle_signal(signum);
}

class runnable
{
  public:
  virtual ~runnable() = default;
  virtual void run() = 0;
};

template <class AsyncStream> class port_reader : public runnable
{
  net::io_context& ctx_;
  AsyncStream stream_;
  pppos_if& ppp_;
  std::array<uint8_t, 1024> input_buf_;
  std::function<void(const net::error_code&)> on_error_;
  std::shared_ptr<spdlog::logger> logger_ = LOGGER_FOR_CLASSNAME(port_reader);
  std::queue<std::shared_ptr<std::vector<uint8_t>>> write_queue_;
  std::mutex write_queue_mutex_;
  void on_error(const net::error_code& ec, std::string_view op)
  {
    logger_->error("{}: {}", op, ec.message());

    if (on_error_)
    {
      on_error_(ec);
      return;
    }
  }
  void on_write(const net::error_code& ec, std::size_t bytes_transferred)
  {
    logger_->trace("{}: ec={}, bt={}", __func__, ec.message(), bytes_transferred);
    auto lock = std::lock_guard(write_queue_mutex_);
    write_queue_.pop();

    if (ec)
    {
      on_error(ec, __func__);
      return;
    }
    if (!write_queue_.empty())
    {
      initiate_write();
    }
  }
  void on_read(const net::error_code& ec, std::size_t bytes_transferred)
  {
    logger_->trace("{}: ec={}, bt={}", __func__, ec.message(), bytes_transferred);
    if (ec)
    {
      on_error(ec, __func__);
      return;
    }
    ppp_.input(net::buffer(input_buf_.data(), bytes_transferred));
    do_read();
  }
  void do_read() { net::async_read(stream_, net::buffer(input_buf_), net::transfer_at_least(1), std::bind(&port_reader::on_read, this, std::placeholders::_1, std::placeholders::_2)); }
  void queue_write(net::const_buffer buf)
  {
    auto lock = std::lock_guard(write_queue_mutex_);
    auto do_need_initiate_write = write_queue_.empty();
    auto begin = reinterpret_cast<const char*>(buf.data());
    write_queue_.emplace(std::make_shared<std::vector<uint8_t>>(begin, begin + buf.size()));
    if (do_need_initiate_write)
    {
      initiate_write();
    }
  }
  void initiate_write()
  {
    // assume write_queue_mutex_ locked somewhere above
    auto copy = write_queue_.front();

    net::async_write(stream_, net::buffer(copy->data(), copy->size()), [copy, this](const net::error_code& ec, std::size_t bytes_transferred) { on_write(ec, bytes_transferred); });
  }

  public:
  ~port_reader()
  {
    ppp_.output_cb([](net::const_buffer buf) -> uint32_t { return 0; });
  }
  port_reader(net::io_context& ctx, AsyncStream&& stream, pppos_if& ppp, std::function<void(const net::error_code&)> on_error)
      : ctx_(ctx)
      , stream_(std::move(stream))
      , ppp_(ppp)
      , on_error_(on_error)
  {
    ppp_.output_cb(
        [this](net::const_buffer buf) -> uint32_t
        {
          queue_write(buf);
          //          do_write(buf);
          return buf.size();
        });
  }
  void run() override { do_read(); }
};

namespace
{
template <class T> T make_proto_endpoint(std::string_view path);
template <> net::local::stream_protocol::endpoint make_proto_endpoint(std::string_view path)
{
  ::unlink(path.data()); // silently ignore result
  return { path };
}
template <> net::ip::tcp::endpoint make_proto_endpoint(std::string_view path) { return net::ip::tcp::endpoint(net::ip::make_address_v4("localhost"), std::stoul(path.data())); }
std::string endpoint_name(const net::local::stream_protocol::endpoint& endpoint) { return endpoint.path(); }
std::string endpoint_name(const net::ip::tcp::endpoint& endpoint) { return endpoint.address().to_string() + std::to_string(+endpoint.port()); }
} // namespace

template <class Protocol> class local_api_server : public runnable
{
  using Acceptor = net::basic_socket_acceptor<Protocol>;
  using Stream = typename net::basic_stream_socket<Protocol>;
  net::io_context& ctx_;
  pppos_if& pppos_if_;
  Acceptor acceptor_;
  logger logger_ = LOGGER_FOR_CLASSNAME(local_api_server);
  std::unique_ptr<port_reader<Stream>> stream_;

  private:
  void on_client_dead(const net::error_code& ec)
  {
    logger_->info("client dropped: {}, continue accepting", ec.message());
    do_accept();
  }
  void on_accept(net::error_code ec, Stream socket)
  {
    if (ec)
    {
      logger_->error("{}: {}", __func__, ec.message());
      do_accept();
      return;
    }
    {
      net::error_code l_ec;
      auto ep = socket.remote_endpoint(l_ec);
      std::string ep_name;
      if (l_ec)
      {
        ep_name = "unknown";
      }
      else
      {
        ep_name = endpoint_name(ep);
      }
      logger_->info("client arrived: {}, start accepting", ep_name);
    }
    stream_ = std::make_unique<port_reader<Stream>>(ctx_, std::move(socket), pppos_if_, std::bind(&local_api_server::on_client_dead, this, std::placeholders::_1));
    stream_->run();
  }
  void do_accept() { acceptor_.async_accept(std::bind(&local_api_server::on_accept, this, std::placeholders::_1, std::placeholders::_2)); }

  public:
  local_api_server(net::io_context& ctx, pppos_if& pppos_if, std::string_view path)
      : ctx_(ctx)
      , pppos_if_(pppos_if)
      , acceptor_(ctx_, make_proto_endpoint<typename Protocol::endpoint>(path))

  {
  }
  void run() override { do_accept(); }
};

struct application
{
  struct arguments
  {
    bool handle_signals = true;
    bool use_plain_serial = false;
  };

  private:
  logger logger_ = LOGGER_FOR_CLASSNAME(application);
  net::io_context ctx;
  std::vector<std::shared_ptr<apps::base_app>> apps_;

  constexpr static auto ERROR_RETURN_CONSTANT = std::numeric_limits<std::size_t>::max();
  constexpr static auto OK_RETURN_CONSTANT = std::numeric_limits<std::size_t>::min();
  void start_apps()
  {
    {
      net::post(
          ctx,
          [this]()
          {
            for (auto& app : apps_)
            {
              app->run();
            }
          });
    }
  }
  void stop_apps()
  {
    net::post(
        ctx,
        [this]()
        {
          for (auto& app : apps_)
          {
            app->stop();
          }
        });
  }

  public:
  void stop()
  {
    logger_->info("{}", __func__);
    if (ctx.stopped())
    {
      return;
    }
    ctx.post([this]() { ctx.stop(); });
  }
  /**
   * @brief я есть главная функция
   * @param api_endpoint_path, путь на ФС или абстрактный путь, socat вот так: socat -d -d -d -d /dev/ttyUSB0,rawer,b115200 ABSTRACT-CLIENT:kktnetd
   * @param args
   * @return ошибка std::size_t max или возврат от io_context.run()
   */
  std::size_t run(std::string_view api_endpoint_path = { "\0kktnetd", 8 }, const arguments& args = { false, false })
  {
    auto anon = api_endpoint_path[0] == 0;
    uint32_t count = 0;
    logger_->info("{}(path={}, anon={}, handle_signals={}, use_plain={})", __func__, api_endpoint_path.data() + (anon ? 1 : 0), anon, args.handle_signals, args.use_plain_serial);
    logger_->flush();

    if (ctx.stopped())
    {

      ctx.restart();
    }

    net::error_code ec;

    if (args.handle_signals)
    {
      net::signal_set signal_set(ctx);

#ifndef _WIN32
      // Intercept SIGHUP and SIGINT
      signal_set.add(SIGHUP, ec);
      if (ec)
      {
        logger_->error("cannot handle SIGHUP"); // Should not happen
      }
      signal_set.add(SIGUSR1, ec);
      if (ec)
      {
        logger_->error("cannot handle SIGUSR1"); // Should not happen
      }
#endif //#ifndef _WIN32
      signal_set.add(SIGINT, ec);
      if (ec)
      {
        logger_->error("cannot handle SIGINT"); // Will always happen
      }
      signal_set.add(SIGTERM, ec);
      if (ec)
      {
        logger_->error("cannot handle SIGTERM"); // Should not happen
      }
      signal_set.async_wait(signal_handler);
    }
    try
    {
      lwip_stack lwip(ctx);

      pppos_if ppp { pppos_if::Mode::Server };
      std::unique_ptr<runnable> server;
#ifdef _WIN32
      std::unique_ptr<runnable> wdog;
#endif
      if (args.use_plain_serial)
      {

        net::serial_port serial_port(net::make_strand(ctx));
        {
          std::error_code ec;
          serial_port.open(api_endpoint_path.data(), ec);
          if (ec)
          {
            logger_->error("serial port open failed: {} , stopping ...", ec.message());
            kktnetd_stop_app();
            return ERROR_RETURN_CONSTANT;
          }

          serial_port.set_option(net::serial_port::baud_rate(115200), ec);
          if (ec)
          {
            logger_->error("serial port set baud_rate failed: {} , stopping ...", ec.message());
            kktnetd_stop_app();
            return ERROR_RETURN_CONSTANT;
          }
          serial_port.set_option(net::serial_port::parity(net::serial_port::parity::none), ec);
          if (ec)
          {
            logger_->error("serial port set parity failed: {} , stopping ...", ec.message());
            kktnetd_stop_app();
            return ERROR_RETURN_CONSTANT;
          }
          serial_port.set_option(net::serial_port::stop_bits(net::serial_port::stop_bits::one), ec);
          if (ec)
          {
            logger_->error("serial port set stop_bits failed: {} , stopping ...", ec.message());
            kktnetd_stop_app();
            return ERROR_RETURN_CONSTANT;
          }
          serial_port.set_option(net::serial_port::flow_control(net::serial_port::flow_control::none), ec);
          if (ec)
          {
            logger_->error("serial port set flow_control failed: {} , stopping ...", ec.message());
            kktnetd_stop_app();
            return ERROR_RETURN_CONSTANT;
          }
          serial_port.set_option(net::serial_port::character_size(8));
          if (ec)
          {
            logger_->error("serial port set character_size failed: {} , stopping ...", ec.message());
            kktnetd_stop_app();
            return ERROR_RETURN_CONSTANT;
          }
        }
        server = std::make_unique<port_reader<net::serial_port>>(
            ctx, std::move(serial_port), ppp,
            [this](std::error_code ec)
            {
              logger_->error("serial port problem: {}, stopping ...", ec.message());
              kktnetd_stop_app();
            });
#ifdef _WIN32
        class serial_port_wdog : public runnable
        {
          logger logger_ = LOGGER_FOR_CLASSNAME(serial_port_wdog);
          bool stopped_ = false;
          net::steady_timer timer_;
          string device_;
          void on_expired(const net::error_code& timer_ec)
          {
            if (stopped_)
            {
              logger_->error("stopped");
              return;
            }
            if (timer_ec)
            {
              logger_->error("{}: timer error {}: {}", __func__, timer_ec.value(), timer_ec.message());
              return;
            }
            {
              net::serial_port tmp_port(timer_.get_executor());
              net::error_code ec;
              tmp_port.open(device_, ec);
              if (ec == net::error::no_permission)
              {
                // it must be like that - ok
                do_reschedule();
                return;
              }
              else if (ec == net::error_code(ERROR_FILE_NOT_FOUND, net::error::get_system_category()))
              {
                logger_->error("serial port {} disappeared, stopping...", device_);
                kktnetd_stop_app();
                return;
              }
              else
              {
                logger_->error("unexpected error {}: {}, stopping...", ec.value(), ec.message());
                kktnetd_stop_app();
                return;
              }
            }
          }
          void do_reschedule()
          {
            timer_.expires_from_now(std::chrono::milliseconds(1000));
            timer_.async_wait(std::bind(&serial_port_wdog::on_expired, this, std::placeholders::_1));
          }

      public:
          explicit serial_port_wdog(net::io_context& ctx, string_view device)
              : timer_(net::steady_timer(ctx))
              , device_(device)
          {
          }
          void run() override
          {
            stopped_ = false;
            do_reschedule();
          }
          void stop()
          {
            stopped_ = true;
            timer_.cancel();
          }
        };
        wdog = std::make_unique<serial_port_wdog>(ctx, api_endpoint_path.data());
#endif //_WIN32
      }
      else
      {
#ifdef _WIN32
        server = std::make_unique<local_api_server<net::ip::tcp>>(ctx, ppp, api_endpoint_path);
#else
        server = std::make_unique<local_api_server<net::local::stream_protocol>>(ctx, ppp, api_endpoint_path);
#endif
      }
      apps_.emplace_back(std::make_shared<__KKTNETD_NAMESPACE__::apps::resender_app>(ctx, "192.168.1.168", 7778));
      apps_.emplace_back(std::make_shared<__KKTNETD_NAMESPACE__::apps::socks5_app>(ctx));

      ppp.start_apps_cb(std::bind(&application::start_apps, this));
      ppp.stop_apps_cb(std::bind(&application::stop_apps, this));

      lwip.run();
      logger_->info("lwip thread started");

      server->run();
      logger_->info("unix domain/tcp listener started");
#ifdef _WIN32
      if (wdog)
      {
        wdog->run();
        logger_->info("serial port watchdog started");
      }
#endif
      ppp.run();
      logger_->info("ppp interface started");

      logger_->info("starting io_context");
      return ctx.run();
    }
    catch (const std::exception& e)
    {
      logger_->error("failed to start: {}", e.what());
      return ERROR_RETURN_CONSTANT;
    }
    catch (...)
    {
      logger_->error("failed to start: {}", "unknown reason");
      return ERROR_RETURN_CONSTANT;
    }

    return OK_RETURN_CONSTANT;
  }
};

KKTNETD_NAMESPACE_END

static __KKTNETD_NAMESPACE__::application* kktnetd_g_application = nullptr;
/**
 * @brief
 * @param name
 * @param size
 * @param flags BIT(0) - signals
 * @return
 */

#ifdef __cplusplus
extern "C"
{
#endif

  KKTNETD_LIB_API size_t kktnetd_run_app(const char* name, size_t size, uint32_t flags)
  {
    std::size_t ret;
    {
      __KKTNETD_NAMESPACE__::application app;
      if (!kktnetd_g_application)
      {
        kktnetd_g_application = &app;
      }
      ret = app.run(
          { name, size },
          {
              bool(flags & 1UL),
              bool(flags & 1UL << 1),
          });
    }
    // we are stopped so null global app
    kktnetd_g_application = nullptr;
    return ret;
  }
  KKTNETD_LIB_API void kktnetd_stop_app()
  {
    if (!kktnetd_g_application)
    {
      return;
    }
    kktnetd_g_application->stop();
  }

#ifdef __cplusplus
}
#endif

#ifdef __ANDROID__
/*
 * Class:     ru_shtrihm_kktnetd_Api
 * Method:    start
 * Signature: (Ljava/lang/String;)I
 */
JNIEXPORT jint JNICALL Java_ru_shtrih_1m_kktnetd_Api_start(JNIEnv* env, jclass, jstring path)
{
  const char* utf_path = (env)->GetStringUTFChars(path, nullptr);
  auto anonymous_path = std::string("\0", 1);
  anonymous_path += std::string(utf_path);
  env->ReleaseStringUTFChars(path, utf_path);
  return kktnetd_run_app(anonymous_path.data(), anonymous_path.size(), 0);
}

/*
 * Class:     ru_shtrihm_kktnetd_Api
 * Method:    stop
 * Signature: ()V
 */
JNIEXPORT void JNICALL Java_ru_shtrih_1m_kktnetd_Api_stop(JNIEnv*, jclass) { kktnetd_stop_app(); }

#endif //__ANDROID__
