#ifndef LWIPSOCKETIO_H
#define LWIPSOCKETIO_H

#include <asio/buffer.hpp>
#include <functional>
#include <kktnet_common.h>
#include <system_error>
#include <utils/async_poster.h>
#include <utils/log.h>

KKTNETD_NAMESPACE_BEGIN
class lwip_socket_io
{
  using on_opened = std::function<void(std::error_code ec)>;
  using on_transfer_ends = std::function<void(std::error_code, size_t)>;
  using on_client_connection_accepted = std::function<void(std::error_code, std::unique_ptr<lwip_socket_io>)>;
  std::shared_ptr<spdlog::logger> logger_;
  std::shared_ptr<async_poster_factory> poster_factory_;
  std::unique_ptr<async_poster> poster_;

  const u8string host_;
  const uint16_t port_;
  int sockfd_ = -1;

  public:
  lwip_socket_io(std::shared_ptr<async_poster_factory> factory, std::string_view host, uint16_t port);
  ~lwip_socket_io();

  public:
  bool do_listen();
  void async_accept(on_client_connection_accepted cb);
  void async_connect(on_opened cb);
  void close();
  void async_write_some(net::const_buffer buf, on_transfer_ends cb);
  void async_read_some(net::mutable_buffer buf, on_transfer_ends cb);
  bool is_alive() const;

  private:
  void do_open(uint32_t dstaddr, on_opened cb);
  static std::unique_ptr<lwip_socket_io> make_one(std::shared_ptr<async_poster_factory> poster_factory, int fd);
};

KKTNETD_NAMESPACE_END
#endif // LWIPSOCKETIO_H
