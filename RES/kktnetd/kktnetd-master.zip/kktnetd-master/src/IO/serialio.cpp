﻿#include "serialio.h"
#include <spdlog/common.h>
#include <spdlog/logger.h>
#ifndef _WIN32
#include <sys/ioctl.h>
#include <termios.h>

#endif

KKTNETD_NAMESPACE_BEGIN

#ifdef _WIN32
#else
static const std::map<int, speed_t> getBaudrateMap()
{
  static const std::map<int, speed_t> result = {
#ifdef B50
    { 50, B50 },
#endif

#ifdef B75
    { 75, B75 },
#endif

#ifdef B110
    { 110, B110 },
#endif

#ifdef B134
    { 134, B134 },
#endif

#ifdef B150
    { 150, B150 },
#endif

#ifdef B200
    { 200, B200 },
#endif

#ifdef B300
    { 300, B300 },
#endif

#ifdef B600
    { 600, B600 },
#endif

#ifdef B1200
    { 1200, B1200 },
#endif

#ifdef B1800
    { 1800, B1800 },
#endif

#ifdef B2400
    { 2400, B2400 },
#endif

#ifdef B4800
    { 4800, B4800 },
#endif

#ifdef B7200
    { 7200, B7200 },
#endif

#ifdef B9600
    { 9600, B9600 },
#endif

#ifdef B14400
    { 14400, B14400 },
#endif

#ifdef B19200
    { 19200, B19200 },
#endif

#ifdef B28800
    { 28800, B28800 },
#endif

#ifdef B38400
    { 38400, B38400 },
#endif

#ifdef B57600
    { 57600, B57600 },
#endif

#ifdef B76800
    { 76800, B76800 },
#endif

#ifdef B115200
    { 115200, B115200 },
#endif

#ifdef B230400
    { 230400, B230400 },
#endif

#ifdef B460800
    { 460800, B460800 },
#endif

#ifdef B500000
    { 500000, B500000 },
#endif

#ifdef B576000
    { 576000, B576000 },
#endif

#ifdef B921600
    { 921600, B921600 },
#endif

#ifdef B1000000
    { 1000000, B1000000 },
#endif

#ifdef B1152000
    { 1152000, B1152000 },
#endif

#ifdef B1500000
    { 1500000, B1500000 },
#endif

#ifdef B2000000
    { 2000000, B2000000 },
#endif

#ifdef B2500000
    { 2500000, B2500000 },
#endif

#ifdef B3000000
    { 3000000, B3000000 },
#endif

#ifdef B3500000
    { 3500000, B3500000 },
#endif

#ifdef B4000000
    { 4000000, B4000000 },
#endif
  };

  return result;
}
#endif

#ifdef _WIN32
static u8string portNameToSystemLocation(const u8string& source) { return source.find("COM") == 0 ? ("\\\\.\\" + source) : source; }

#else
static u8string portNameToSystemLocation(const u8string& source) { return (source.find('/') == 0 || source.find("./") == 0 || source.find("../") == 0) ? source : u8string("/dev/") + source; }
#endif

SerialIO::SerialIO(const u8string& path, int baudrate, SerialIO::DataBits dataBits, SerialIO::StopBits stopBits, Parity parity, SerialIO::FlowControl flowControl)
    : IoLayer(LOGGER_FOR_CLASSNAME(SerialIO))
    , m_path(portNameToSystemLocation(path))
    , m_baudrate(baudrate)
    , m_dataBits(dataBits)
    , m_stopBits(stopBits)
    , m_parity(parity)
    , m_flowControl(flowControl)
{
  m_logger->set_level(spdlog::level::info);
}

SerialIO::~SerialIO() { close(); }

#ifdef _WIN32
bool SerialIO::internal_open()
{
  DWORD desiredAccess = GENERIC_READ | GENERIC_WRITE;
  std::wstring path_utf16(m_path.begin(), m_path.end());
  COMMTIMEOUTS tm = { byteTimeout().count(), byteTimeout().count(), 0, 100, 0 };
  m_handle = ::CreateFile(path_utf16.c_str(), desiredAccess, 0, nullptr, OPEN_EXISTING, FILE_FLAG_OVERLAPPED, nullptr);

  if (m_handle == INVALID_HANDLE_VALUE)
  {
    return false;
  }
  DCB dcb;
  ::ZeroMemory(&dcb, sizeof(DCB));
  dcb.DCBlength = sizeof(DCB);

  if (!::GetCommState(m_handle, &dcb))
  {
    goto error_cleanup;
  }
  dcb.fBinary = TRUE;
  dcb.fAbortOnError = FALSE;
  dcb.fNull = FALSE;
  dcb.fErrorChar = FALSE;

  if (dcb.fDtrControl == DTR_CONTROL_HANDSHAKE)
    dcb.fDtrControl = DTR_CONTROL_DISABLE;
  dcb.BaudRate = static_cast<DWORD>(m_baudrate);
  dcb.ByteSize = static_cast<BYTE>(m_dataBits);
  dcb.fParity = TRUE;
  switch (m_parity)
  {
  case NoParity:
    dcb.Parity = NOPARITY;
    dcb.fParity = FALSE;
    break;
  case OddParity:
    dcb.Parity = ODDPARITY;
    break;
  case EvenParity:
    dcb.Parity = EVENPARITY;
    break;
  case MarkParity:
    dcb.Parity = MARKPARITY;
    break;
  case SpaceParity:
    dcb.Parity = SPACEPARITY;
    break;
  default:
    dcb.Parity = NOPARITY;
    dcb.fParity = FALSE;
    break;
  }
  switch (m_stopBits)
  {
  case OneStop:
    dcb.StopBits = ONESTOPBIT;
    break;
  case OneAndHalfStop:
    dcb.StopBits = ONE5STOPBITS;
    break;
  case TwoStop:
    dcb.StopBits = TWOSTOPBITS;
    break;
  default:
    dcb.StopBits = ONESTOPBIT;
    break;
  }
  dcb.fInX = FALSE;
  dcb.fOutX = FALSE;
  dcb.fOutxCtsFlow = FALSE;
  dcb.fRtsControl = RTS_CONTROL_DISABLE;
  switch (m_flowControl)
  {
  case NoFlowControl:
    break;
  case SoftwareControl:
    dcb.fInX = TRUE;
    dcb.fOutX = TRUE;
    break;
  case HardwareControl:
    dcb.fOutxCtsFlow = TRUE;
    dcb.fRtsControl = RTS_CONTROL_HANDSHAKE;
    break;
  default:
    break;
  }

  if (!::SetCommState(m_handle, &dcb))
  {
    goto error_cleanup;
  }
  if (!::SetCommTimeouts(m_handle, &tm))
  {
    goto error_cleanup;
  }
  DWORD originalEventMask = EV_RXCHAR;
  if (!::SetCommMask(m_handle, originalEventMask))
  {
    goto error_cleanup;
  }
  m_event = CreateEvent(NULL, TRUE, FALSE, NULL);
  return true;
error_cleanup:
  m_logger->error("error: o {} ", ::GetLastError());
  ::CloseHandle(m_handle);
  return false;
}
#else

bool SerialIO::internal_open()
{
  static const auto& BAUDRATE_MAP = getBaudrateMap();
  speed_t baudrate = B4800;
  int flush;
  auto ret = BAUDRATE_MAP.find(m_baudrate);
  if (ret != BAUDRATE_MAP.end())
  {
    baudrate = ret->second;
  }
  m_fd = ::open(m_path.c_str(), O_RDWR | O_NOCTTY | O_NONBLOCK | O_CLOEXEC);
  if (m_fd == -1)
  {
    m_logger->error("error: {} ", strerror(errno));
    return false;
  }
  FD_ZERO(&fds);
  FD_SET(m_fd, &fds);
  if (::ioctl(m_fd, TIOCEXCL) == -1)
  {
    m_logger->error("error: {} ", strerror(errno));
  }
  termios tio;
  memset(&tio, 0, sizeof(tio));
  if (::tcgetattr(m_fd, &tio) == -1)
  {
    goto error_cleanup;
  }
  ::cfmakeraw(&tio);
  tio.c_cflag |= CLOCAL;
  tio.c_cc[VTIME] = 0;
  tio.c_cc[VMIN] = 0;
  tio.c_cflag &= ~CSIZE;
  // data bits
  switch (m_dataBits)
  {
  case Data5:
    tio.c_cflag |= CS5;
    break;
  case Data6:
    tio.c_cflag |= CS6;
    break;
  case Data7:
    tio.c_cflag |= CS7;
    break;
  case Data8:
    tio.c_cflag |= CS8;
    break;
  default:
    tio.c_cflag |= CS8;
    break;
  }
  // parity
  tio.c_iflag &= ~(PARMRK | INPCK);
  tio.c_iflag |= IGNPAR;

  switch (m_parity)
  {

#ifdef CMSPAR
  // Here Installation parity only for GNU/Linux where the macro CMSPAR.
  case SpaceParity:
    tio.c_cflag &= ~PARODD;
    tio.c_cflag |= PARENB | CMSPAR;
    break;
  case MarkParity:
    tio.c_cflag |= PARENB | CMSPAR | PARODD;
    break;
#endif
  case NoParity:
    tio.c_cflag &= ~PARENB;
    break;
  case EvenParity:
    tio.c_cflag &= ~PARODD;
    tio.c_cflag |= PARENB;
    break;
  case OddParity:
    tio.c_cflag |= PARENB | PARODD;
    break;
  default:
    tio.c_cflag |= PARENB;
    tio.c_iflag |= PARMRK | INPCK;
    tio.c_iflag &= ~IGNPAR;
    break;
  }
  // stop bits
  switch (m_stopBits)
  {
  case OneStop:
    tio.c_cflag &= ~CSTOPB;
    break;
  case TwoStop:
    tio.c_cflag |= CSTOPB;
    break;
  default:
    tio.c_cflag &= ~CSTOPB;
    break;
  }
  // flow control
  switch (m_flowControl)
  {
  case NoFlowControl:
    tio.c_cflag &= ~CRTSCTS;
    tio.c_iflag &= ~(IXON | IXOFF | IXANY);
    break;
  case HardwareControl:
    tio.c_cflag |= CRTSCTS;
    tio.c_iflag &= ~(IXON | IXOFF | IXANY);
    break;
  case SoftwareControl:
    tio.c_cflag &= ~CRTSCTS;
    tio.c_iflag |= IXON | IXOFF | IXANY;
    break;
  default:
    tio.c_cflag &= ~CRTSCTS;
    tio.c_iflag &= ~(IXON | IXOFF | IXANY);
    break;
  }
  if (::tcsetattr(m_fd, TCSANOW, &tio) == -1)
  {
    goto error_cleanup;
  }

  if (::cfsetispeed(&tio, baudrate) == -1)
  {
    goto error_cleanup;
  }

  if (::cfsetospeed(&tio, baudrate) == -1)
  {
    goto error_cleanup;
  }
  if (::tcsetattr(m_fd, TCSANOW, &tio) == -1)
  {
    goto error_cleanup;
  }
  flush = tcflush(m_fd, TCIOFLUSH);
  if (flush)
  {
    m_logger->error("error: {} ", strerror(errno));
  }
  return true;
error_cleanup:
  m_logger->error("error: {} ", strerror(errno));
  auto res = ::close(m_fd);
  if (res)
  {
    m_logger->error("error: {} ", strerror(errno));
  }
  return false;
}
#endif

#ifdef _WIN32
void SerialIO::internal_close()
{
  CloseHandle(m_handle);
  CloseHandle(m_event);
  m_handle = INVALID_HANDLE_VALUE;
}
#else
void SerialIO::internal_close()
{
  auto ret = ::close(m_fd);
  if (ret)
  {
    m_logger->error("error: {} ", strerror(errno));
  }
  m_fd = -1;
}
#endif

bool SerialIO::doOpen()
{
  m_logger->info("port: {}, baudrate: {}, stop bits: {}, parity {}, flow control: {}", m_path, m_baudrate, m_stopBits, m_parity, m_flowControl);
  auto ret = internal_open();
  return ret;
}

void SerialIO::doClose() { internal_close(); }

#ifdef _WIN32
int64_t SerialIO::doWrite(const char* data, size_t maxSize)
{
  OVERLAPPED o = {};
  o.hEvent = m_event;
  DWORD written = 0;
  BOOL b = WriteFile(m_handle, data, static_cast<DWORD>(maxSize), &written, &o);
  if (!b && GetLastError() == ERROR_IO_PENDING)
  {
    b = GetOverlappedResult(m_handle, &o, &written, TRUE);
  }
  if (!b)
  {
    m_logger->info("error: w {}", GetLastError());
    return -1;
  }
  return written;
}
#else
int64_t SerialIO::doWrite(const char* data, size_t maxSize)
{
  int64_t ret;
  FD_SET(m_fd, &fds);
  tv.tv_sec = byteTimeout().count() / 1000;
  tv.tv_usec = (byteTimeout().count() % 1000) * 1000;
  ret = select(m_fd + 1, nullptr, &fds, nullptr, &tv);
  if (ret == -1)
  {
    if (errno == EINTR)
    {
      return 0;
    }
    m_logger->info("error: {}", strerror(errno));
    return ret;
  }
  if (FD_ISSET(m_fd, &fds))
  {
    ret = static_cast<int64_t>(::write(m_fd, data, maxSize));
    if (ret == -1)
    {
      close();
    }
    return ret;
  }
  return 0;
}
#endif

#ifdef _WIN32
// если в буфере есть данные, то читает данные из буфера
// если буфер пуст, то читает один байт с таймаутом
int64_t SerialIO::doRead(char* data, size_t maxSize)
{
  DWORD errors;
  COMSTAT stats;
  BOOL b = ClearCommError(m_handle, &errors, &stats);
  if (!b)
  {
    m_logger->error("ClearCommError fail {}", GetLastError());
    return -1;
  }
  DWORD avail = stats.cbInQue;
  if (avail == 0)
    avail = 1; // чтобы прочитало 1 байт с таймаутом
  if (avail > maxSize)
    avail = maxSize;

  DWORD read;
  OVERLAPPED o = {};
  o.hEvent = m_event;
  b = ReadFile(m_handle, data, avail, &read, &o);
  if (!b && GetLastError() == ERROR_IO_PENDING)
  {
    b = GetOverlappedResult(m_handle, &o, &read, TRUE);
  }
  if (!b)
  {
    m_logger->error("ReadFile fail {}", GetLastError());
    return -1;
  }
  return read;
}
#else
int64_t SerialIO::doRead(char* data, size_t maxSize)
{
  int64_t ret;
  FD_SET(m_fd, &fds);
  tv.tv_sec = byteTimeout().count() / 1000;
  tv.tv_usec = (byteTimeout().count() % 1000) * 1000;
  ret = select(m_fd + 1, &fds, nullptr, nullptr, &tv);
  if (ret == -1)
  {
    if (errno == EINTR)
    {
      return 0;
    }
    m_logger->info("error: {}", strerror(errno));
    return ret;
  }
  if (FD_ISSET(m_fd, &fds))
  {
    ret = static_cast<int64_t>(::read(m_fd, data, maxSize));
    if (ret == -1)
    {
      close();
    }
    return ret;
  }
  return 0;
}
#endif

bool SerialIO::clear()
{
  if (!opened())
  {
    return false;
  }
#ifdef _WIN32
  BOOL b = PurgeComm(m_handle, PURGE_TXCLEAR | PURGE_RXCLEAR | PURGE_TXABORT | PURGE_RXABORT);
  if (!b)
    m_logger->info("error: c {}", GetLastError());
  return b;
#else

  auto ret = tcflush(m_fd, TCIFLUSH);
  std::this_thread::sleep_for(byteTimeout() / 2);
  // нужно поспать т.к. usb переходники глючат
  // https://bugzilla.kernel.org/show_bug.cgi?id=5730
  return ret == 0;
#endif
}

void SerialIO::setByteTimeout(const ms& byteTimeout)
{
  IoLayer::setByteTimeout(byteTimeout);

#ifdef _WIN32
  if (!opened())
    return;
  COMMTIMEOUTS tm = { byteTimeout.count(), byteTimeout.count(), 0, 100, 0 };
  if (!::SetCommTimeouts(m_handle, &tm))
    m_logger->error("SetCommTimeouts fail {} ", ::GetLastError());

#endif
}

int SerialIO::baudrate() const { return m_baudrate; }

u8string SerialIO::path() const { return m_path; }

SerialIO::DataBits SerialIO::dataBits() const { return m_dataBits; }

SerialIO::StopBits SerialIO::stopBits() const { return m_stopBits; }

SerialIO::Parity SerialIO::parity() const { return m_parity; }

SerialIO::FlowControl SerialIO::flowControl() const { return m_flowControl; }

std::ostream& operator<<(std::ostream& os, int baudrate)
{
  if (baudrate <= 0)
  {
    return os << "Unknown";
  }
  return os << static_cast<int>(baudrate);
}

std::ostream& operator<<(std::ostream& os, SerialIO::DataBits databits)
{
  if (databits <= 0)
  {
    return os << "Unknown";
  }
  return os << static_cast<int>(databits);
}

std::ostream& operator<<(std::ostream& os, SerialIO::Parity parity)
{
  switch (parity)
  {
  case SerialIO::Parity::EvenParity:
    return os << std::string_view("EvenParity");
  case SerialIO::Parity::MarkParity:
    return os << std::string_view("MarkParity");
  case SerialIO::Parity::NoParity:
    return os << std::string_view("NoParity");
  case SerialIO::Parity::OddParity:
    return os << std::string_view("OddParity");
  case SerialIO::Parity::SpaceParity:
    return os << std::string_view("SpaceParity");
  default:
    return os << "Unknown";
  }
}

std::ostream& operator<<(std::ostream& os, SerialIO::StopBits stopbits)
{
  switch (stopbits)
  {
  case SerialIO::OneStop:
    return os << std::string_view("OneStop");
  case SerialIO::OneAndHalfStop:
    return os << std::string_view("OneAndHalfStop");
  case SerialIO::TwoStop:
    return os << std::string_view("TwoStop");
  default:
    return os << "Unknown";
  }
}

std::ostream& operator<<(std::ostream& os, SerialIO::FlowControl flowcontrol)
{
  switch (flowcontrol)
  {
  case SerialIO::NoFlowControl:
    return os << std::string_view("NoFlowControl");
  case SerialIO::HardwareControl:
    return os << std::string_view("HardwareControl");
  case SerialIO::SoftwareControl:
    return os << std::string_view("SoftwareControl");
  default:
    return os << "Unknown";
  }
}
KKTNETD_NAMESPACE_END
