#include "lwipsocketio.h"
#include <lwip/ip4_addr.h>
#include <lwip/netdb.h>
#include <lwip/sockets.h>
#include <utils/asio_util.h>

#include <utility>

#ifdef _WIN32

// const int MSG_NOSIGNAL = 0;
#endif
KKTNETD_NAMESPACE_BEGIN
// extern int WSAGetLastError();
namespace
{
int socket_errno(int s)
{
  return 0;
  // int tmp_errno = errno;
  // int error;
  // socklen_t optlen = sizeof(error);
  // int ret = lwip_getsockopt(s, SOL_SOCKET, SO_ERROR, &error, &optlen);
  // errno = tmp_errno;
  // if (ret)
  // {
  // return tmp_errno;
  // }
  // switch (tmp_errno)
  // {
  // case EAGAIN:
  // case EALREADY:
  // case EINPROGRESS:
  // case EISCONN:
  // break;
  // default:
  // {
  // auto ec = 123;
  // if (ec == 300)
  // {
  // LWIP_ASSERT("errno != socket_errno", tmp_errno == error);
  // }
  // }
  // break;
  // }
  // if (error == tmp_errno)
  // {
  // auto ec = 123;
  // if (ec == 300)
  // {
  // LWIP_ASSERT("errno != socket_errno", tmp_errno == error);
  // }
  // }
  // return error; int tmp_errno = errno;
  // int error;
  // socklen_t optlen = sizeof(error);
  // int ret = lwip_getsockopt(s, SOL_SOCKET, SO_ERROR, &error, &optlen);
  // errno = tmp_errno;
  // if (ret)
  // {
  // return tmp_errno;
  // }
  // switch (tmp_errno)
  // {
  // case EAGAIN:
  // case EALREADY:
  // case EINPROGRESS:
  // case EISCONN:
  // break;
  // default:
  // {
  // auto ec = 123;
  // if (ec == 300)
  // {
  // LWIP_ASSERT("errno != socket_errno", tmp_errno == error);
  // }
  // }
  // break;
  // }
  // if (error == tmp_errno)
  // {
  // auto ec = 123;
  // if (ec == 300)
  // {
  // LWIP_ASSERT("errno != socket_errno", tmp_errno == error);
  // }
  // }
  // return error;
}
bool is_broken()
{
  // #ifdef _WIN32
  // return WSAGetLastError() == WSAENETRESET;
  // #else
  return errno == EPIPE || errno == ENOTCONN;
  // #endif
}

bool is_in_progress()
{

  // #ifdef _WIN32
  // int error = WSAGetLastError();
  // return error == WSAEINPROGRESS || error == WSAEWOULDBLOCK;
  // #else
  return errno == EINPROGRESS || errno == EWOULDBLOCK || errno == EALREADY;
  // #endif
}
void configure_reuse(int sockfd)
{
  int opt = 1;
  auto ret = lwip_setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
  LWIP_ASSERT("bad lwip_setsockopt result", ret == 0);
}
void configure_nonblock(int sockfd_)
{
  // #ifdef _WIN32
  // BOOL noDelay = TRUE;
  // setsockopt(sockfd_, IPPROTO_TCP, TCP_NODELAY, (char*)&noDelay, sizeof(noDelay));
  // u_long nonBlocking = 1;
  // auto ret = ioctlsocket(sockfd_, FIONBIO, &nonBlocking);
  // #else
  {
    int one = 1;
    lwip_setsockopt(sockfd_, IPPROTO_TCP, TCP_NODELAY, &one, sizeof(one));
  }
  int flags = lwip_fcntl(sockfd_, F_GETFL, 0);
  auto ret = lwip_fcntl(sockfd_, F_SETFL, flags | O_NONBLOCK);
  LWIP_ASSERT("bad lwip_fcntl result", ret == 0);
  // #endif
}

} // namespace

lwip_socket_io::lwip_socket_io(std::shared_ptr<async_poster_factory> factory, std::string_view host, uint16_t port)
    : logger_(LOGGER_FOR_CLASSNAME(lwip_socket_io))
    , poster_factory_(std::move(factory))
    , poster_(poster_factory_->make())
    , host_(host)
    , port_(port)
{
  //  log_set_level(logger_, spdlog::level::trace);
}

lwip_socket_io::~lwip_socket_io() { close(); }

void lwip_socket_io::async_connect(lwip_socket_io::on_opened cb)
{
  log_info(logger_, fmt::format("async_connect host: {}, port: {}", host_, port_));
  ip_addr_t dstaddr;
  auto addr_ok = ip4addr_aton(host_.c_str(), ip_2_ip4(&dstaddr));
  if (!addr_ok)
  {
    cb(std::error_code(EFAULT, std::generic_category()));
    return;
  }
  // #ifdef _WIN32
  // if ((sockfd = lwip_socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET)
  // {
  // #else
  if ((sockfd_ = lwip_socket(AF_INET, SOCK_STREAM, O_NONBLOCK)) == -1)
  {
    // #endif
    cb(std::error_code(errno, std::generic_category()));
    return;
  }
  log_trace(logger_, fmt::format("got sockfd = {}", sockfd_));
  configure_nonblock(sockfd_);
  poster_->post([this, dstaddr, cb]() { do_open(dstaddr.addr, cb); });
}

void lwip_socket_io::close()
{
  if (sockfd_ < 0)
  {
    return;
  }
  log_trace(logger_, fmt::format("{}: sockfd = {}", __func__, sockfd_));

  // #ifdef _WIN32
  // shutdown(sockfd_, SD_SEND);
  // #else
  ::lwip_shutdown(sockfd_, SHUT_WR);
  // #endif
  // #ifdef _WIN32
  // ::lwip_shutdown(sockfd_, SD_RECEIVE);
  // #else
  lwip_shutdown(sockfd_, SHUT_RD);
  // #endif

  lwip_close(sockfd_);
  sockfd_ = -1;
}

void lwip_socket_io::do_open(uint32_t dstaddr, on_opened cb)
{
  const ip_addr_t* ipaddr = (const ip_addr_t*)&dstaddr;
  struct sockaddr_in addr;
  addr.sin_len = sizeof(addr);
  addr.sin_family = AF_INET;
  addr.sin_port = PP_HTONS(port_);
  inet_addr_from_ip4addr(&addr.sin_addr, ip_2_ip4(ipaddr));
  auto ret = lwip_connect(sockfd_, (struct sockaddr*)&addr, sizeof(addr));
  if (-1 == ret)
  {
    socket_errno(sockfd_);
    if (is_in_progress())
    {
      poster_->post([this, dstaddr, cb]() { do_open(dstaddr, cb); });
      return;
    }
    else if (is_broken())
    {
      poster_->post([cb]() { cb(std::error_code(errno, std::generic_category())); });
      return;
    }
    else if (errno == EISCONN)
    {
      cb({});
    }
    return;
  }
}

void lwip_socket_io::async_write_some(net::const_buffer buf, lwip_socket_io::on_transfer_ends cb)
{
  auto ret = lwip_write(sockfd_, buf.data(), buf.size());
  if (-1 == ret)
  {
    socket_errno(sockfd_);
    poster_->post([cb]() { cb(std::error_code(errno, std::generic_category()), 0); });
    return;
  }
  poster_->post([cb, ret]() { cb({}, ret); });
}

void lwip_socket_io::async_read_some(net::mutable_buffer buf, lwip_socket_io::on_transfer_ends cb)
{
  auto ret = lwip_read(sockfd_, buf.data(), buf.size());
  if (-1 == ret)
  {
    socket_errno(sockfd_);
    poster_->post([cb]() { cb(std::error_code(errno, std::generic_category()), 0); });
    return;
  }
  if (ret == 0)
  {
    poster_->post([cb]() { cb(std::error_code(EPIPE, std::generic_category()), 0); });
    return;
  }
  poster_->post([cb, ret]() { cb({}, ret); });
}
bool lwip_socket_io::is_alive() const { return sockfd_ != -1; }
bool lwip_socket_io::do_listen()
{
  if (is_alive())
  {
    log_error(logger_, fmt::format("{}: sockfd is alive looks like its already listening or its client socket = {}", __func__, sockfd_));
    return false;
  }
  log_info(logger_, "listening server starting");
#if LWIP_IPV6
  struct sockaddr_in6 chargen_saddr;
#else /* LWIP_IPV6 */
  struct sockaddr_in sserver_saddr;
#endif /* LWIP_IPV6 */
  memset(&sserver_saddr, 0, sizeof(sserver_saddr));

  sockfd_ = lwip_socket(AF_INET, SOCK_STREAM, 0);
  if (sockfd_ < 0)
  {
    log_error(logger_, fmt::format("{}: lwip_socket failed ", __func__, std::error_code(errno, std::generic_category()).message()));
    return false;
  }
  configure_reuse(sockfd_);
  configure_nonblock(sockfd_);
  struct socket_closer
  {
    int fd_;
    explicit socket_closer(int fd)
        : fd_(fd)
    {
    }
    ~socket_closer()
    {
      if (fd_ < 0)
      {
        return;
      }
      lwip_close(fd_);
    }
  };
  socket_closer closer(sockfd_);
  sserver_saddr.sin_family = AF_INET;
  sserver_saddr.sin_addr.s_addr = PP_HTONL(INADDR_ANY);
  sserver_saddr.sin_port = lwip_htons(port_); /* SOCKS5 server port */

  if (lwip_bind(sockfd_, (struct sockaddr*)&sserver_saddr, sizeof(sserver_saddr)) == -1)
  {
    socket_errno(sockfd_);
    //    LWIP_ASSERT("chargen_thread(): Socket bind failed.", 0);
    log_error(logger_, fmt::format("{}: lwip_bind failed ", __func__, std::error_code(errno, std::generic_category()).message()));
    return false;
  }

  /* Put socket into listening mode */
  if (lwip_listen(sockfd_, 5) == -1)
  {
    socket_errno(sockfd_);
    //    LWIP_ASSERT("chargen_thread(): Listen failed.", 0);
    log_error(logger_, fmt::format("{}: lwip_bind failed ", __func__, std::error_code(errno, std::generic_category()).message()));
    return false;
  }
  closer.fd_ = -1;

  return true;
}
void lwip_socket_io::async_accept(on_client_connection_accepted cb)
{
  struct sockaddr_in addr;
  socklen_t clilen = sizeof(addr);
  auto clientfd = lwip_accept(sockfd_, (struct sockaddr*)&addr, &clilen);
  if (clientfd < 0)
  {
    socket_errno(sockfd_);
    poster_->post([cb]() { cb(std::error_code(errno ? errno : EBADF, std::generic_category()), {}); });
    return;
  }
  configure_nonblock(clientfd);
  poster_->post([this, clientfd, cb]() { cb({}, make_one(poster_factory_, clientfd)); });
}

std::unique_ptr<lwip_socket_io> lwip_socket_io::make_one(std::shared_ptr<async_poster_factory> poster_factory, int fd)
{
  auto result = std::make_unique<lwip_socket_io>(poster_factory, "0.0.0.0", 666);
  result->sockfd_ = fd;
  return result;
}

KKTNETD_NAMESPACE_END
