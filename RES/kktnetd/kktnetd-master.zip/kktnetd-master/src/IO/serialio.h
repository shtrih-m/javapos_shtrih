﻿#ifndef SERIALIO_H
#define SERIALIO_H
#include <IO/iolayer.h>
#include <map>
#ifdef _WIN32

#else
#include <sys/select.h>
#include <sys/types.h>
#endif

KKTNETD_NAMESPACE_BEGIN
class SerialIO : public IoLayer
{
  public:
  enum BaudRate
  {
    Baud1200 = 1200,
    Baud2400 = 2400,
    Baud4800 = 4800,
    Baud9600 = 9600,
    Baud19200 = 19200,
    Baud38400 = 38400,
    Baud57600 = 57600,
    Baud115200 = 115200,
    UnknownBaud = -1
  };

  enum DataBits
  {
    Data5 = 5,
    Data6 = 6,
    Data7 = 7,
    Data8 = 8,
    UnknownDataBits = -1
  };

  enum Parity
  {
    NoParity = 0,
    EvenParity = 2,
    OddParity = 3,
    SpaceParity = 4,
    MarkParity = 5,
    UnknownParity = -1
  };

  enum StopBits
  {
    OneStop = 1,
    OneAndHalfStop = 3,
    TwoStop = 2,
    UnknownStopBits = -1
  };

  enum FlowControl
  {
    NoFlowControl,
    HardwareControl,
    SoftwareControl,
    UnknownFlowControl = -1
  };

  public:
  explicit SerialIO(const u8string& path, int baudrate = 4800, DataBits dataBits = Data8, StopBits stopBits = OneStop, Parity parity = NoParity, FlowControl flowControl = NoFlowControl);
  ~SerialIO() override;
  // IoLayer interface
  bool doOpen() override;
  void doClose() override;
  int64_t doWrite(const char* data, size_t maxSize) override;
  int64_t doRead(char* data, size_t maxSize) override;
  bool clear() override;
  void setByteTimeout(const ms& byteTimeout) override;

  int baudrate() const;
  u8string path() const;
  DataBits dataBits() const;
  StopBits stopBits() const;
  Parity parity() const;
  FlowControl flowControl() const;

  private:
  const u8string m_path;
  const int m_baudrate;
  const DataBits m_dataBits;
  const StopBits m_stopBits;
  const Parity m_parity;
  const FlowControl m_flowControl;

#ifdef _WIN32
  HANDLE m_handle = INVALID_HANDLE_VALUE;
  HANDLE m_event = INVALID_HANDLE_VALUE;
#else
  int m_fd = -1;
  fd_set fds;
  struct timeval tv;
#endif

  bool internal_open();
  void internal_close();
};

std::ostream& operator<<(std::ostream& os, int baudrate);
std::ostream& operator<<(std::ostream& os, SerialIO::DataBits databits);
std::ostream& operator<<(std::ostream& os, SerialIO::Parity parity);
std::ostream& operator<<(std::ostream& os, SerialIO::StopBits stopbits);
std::ostream& operator<<(std::ostream& os, SerialIO::FlowControl flowcontrol);
KKTNETD_NAMESPACE_END

#endif // SERIALIO_H
