﻿#ifndef CDCACMIO_H
#define CDCACMIO_H
#include "iolayer.h"
#ifdef __ANDROID__
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wpedantic"
#include <libusb/libusb.h>
#include <utils/androidhelper.h>
#pragma GCC diagnostic pop

#elif __linux__
#include <libusb-1.0/libusb.h>
#elif _WIN32
#include <libusb/libusb.h>
#endif

KKTNETD_NAMESPACE_BEGIN

class CdcAcmIO : public IoLayer
{
  public:
  struct UsbVidPidEpInEpOut
  {
    uint16_t vid, pid;
    uint8_t epIn, epOut;
    uint8_t lineStateRequest;
  };

  private:
  struct libusb_device_handle* devh;
  bool setupDev(libusb_device* dev);
  UsbVidPidEpInEpOut m_deviceSpecialization;

  public:
  CdcAcmIO();
  ~CdcAcmIO() override;
  // IoLayer interface
  public:
  bool doOpen() override;
  void doClose() override;
  int64_t doWrite(const char* data, size_t maxSize) override;
  int64_t doRead(char* data, size_t maxSize) override;
#ifdef __ANDROID__
  int m_fd;
#endif
};
KKTNETD_NAMESPACE_END
#endif // CDCACMIO_H
