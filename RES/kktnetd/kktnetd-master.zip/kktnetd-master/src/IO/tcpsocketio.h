﻿#ifndef TCPSOCKETIO_H
#define TCPSOCKETIO_H
#include <IO/iolayer.h>
#include <cstdint>
#include <string>
#ifdef _WIN32
#include <WS2tcpip.h>
#include <string.h>
#else
#include <arpa/inet.h>
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/types.h>
#endif
#include <mutex>

KKTNETD_NAMESPACE_BEGIN
/**
 * @brief The TcpSocketIO class
 * избавляемся от qt шного сокета
 */
class TcpSocketIO : public IoLayer {
    const u8string m_host;
    const uint16_t m_port;
    std::recursive_mutex m_mutex;

public:
    enum class Type {
        Client,
        Server
    };
    TcpSocketIO(const u8string& host, uint16_t port);
    ~TcpSocketIO() override;

private:
    Type m_type = Type::Client;

public:
    bool doOpen() override;
    void doClose() override;
    int64_t doWrite(const char* data, size_t maxSize) override;
    int64_t doRead(char* data, size_t maxSize) override;
    bool clear() override;
    Type type() const;
    void setType(const Type type);

private:
    bool listenAndWaitForClient();
    // platform specific functions
#ifdef _WIN32
    SOCKET sockfd = INVALID_SOCKET;
    SOCKET listen_sockfd = INVALID_SOCKET;
#else
    int sockfd = -1;
    int listen_sockfd = -1;
#endif
    void configure();
    bool isSocketBroken();
    bool waitForConnected();
    bool isInProgress();
    void internal_close();
};
KKTNETD_NAMESPACE_END
#endif // TCPSOCKETIO_H
