﻿#include "cdcacmio.h"
#include <spdlog/logger.h>

#define VENDOR_ID 0x1fc9 // NXP (Shtrih-M)
#define PRODUCT_ID 0x0083 // Fiscal printer

#define ACM_CTRL_DTR 0x01
#define ACM_CTRL_RTS 0x02

KKTNETD_NAMESPACE_BEGIN

constexpr const static CdcAcmIO::UsbVidPidEpInEpOut shtrih_vids_pids[] = {
  { 0x1fc9, 0x0083, 0x81, 0x01, ACM_CTRL_DTR | ACM_CTRL_RTS }, // NXP (Shtrih-M) Fiscal printer
  { 0x04d9, 0xb534, 0x83, 0x02, 0 }, // Holtek Semiconductor, Inc. Штрих-Нано
};

CdcAcmIO::CdcAcmIO()
    : IoLayer(LOGGER_FOR_CLASSNAME(CdcAcmIO))
    , devh(nullptr)
{
}

CdcAcmIO::~CdcAcmIO() { close(); }

bool CdcAcmIO::setupDev(libusb_device* dev)
{
  libusb_device_descriptor desc;
  int r = libusb_get_device_descriptor(dev, &desc);
  if (r < 0)
  {
    m_logger->error("failed to get device descriptor");
    return false;
  }
  bool isDeviceKnown = false;
  for (const auto& vidpid : shtrih_vids_pids)
  {
    if (vidpid.vid == desc.idVendor && vidpid.pid == desc.idProduct)
    {
      m_logger->info("I know this device");
      m_deviceSpecialization = vidpid;
      isDeviceKnown = true;
      break;
    }
  }
  m_logger->info("Number of possible configurations: {}", +desc.bNumConfigurations);
  m_logger->info("Device Class: {}", +desc.bDeviceClass);
  m_logger->info("VendorID:ProductID {:#06x}:{:#06x}", desc.idVendor, desc.idProduct);

  libusb_config_descriptor* config;

  auto ret = libusb_get_config_descriptor(dev, 0, &config);
  if (ret)
  {
    m_logger->error("Unable to get config descriptor: {}", ret);
    return false;
  }
  std::unique_ptr<libusb_config_descriptor, decltype(&libusb_free_config_descriptor)> pConfig(config, libusb_free_config_descriptor);
  m_logger->info("Interfaces: {}", +config->bNumInterfaces);
  const libusb_interface* inter;
  const libusb_interface_descriptor* interdesc;
  const libusb_endpoint_descriptor* epdesc;
  for (uint8_t i = 0; i < config->bNumInterfaces; i++)
  {
    inter = &config->interface[i];
    for (int j = 0; j < inter->num_altsetting; j++)
    {
      interdesc = &inter->altsetting[j];
      m_logger->info("  Interface Number: {}", +interdesc->bInterfaceNumber);
      m_logger->info("  Number of endpoints: {}", +interdesc->bNumEndpoints);
      if (isDeviceKnown)
      {
        auto rc = libusb_claim_interface(devh, interdesc->bInterfaceNumber);
        if (rc < 0)
        {
          m_logger->error("Error claiming interface: {}", libusb_error_name(rc));
          return false;
        }
      }

      for (uint8_t k = 0; k < interdesc->bNumEndpoints; k++)
      {
        epdesc = &interdesc->endpoint[k];
        m_logger->info("    Descriptor Type: {}", +epdesc->bDescriptorType);
        m_logger->info("    EP Address: {:#06x}", +epdesc->bEndpointAddress);
      }
    }
  }
  return true;
}

bool CdcAcmIO::doOpen()
{
#ifdef __ANDROID__
  auto helper = AndroidHelper::instance(nullptr);
  if (!helper.initOk)
    return false;
  auto holder = helper.env();
  auto env = holder.env();
  env->CallStaticVoidMethod(helper.UsbCdcAcmHelper, helper.UsbCdcAcmHelper_updateFd);
  m_fd = env->CallStaticIntMethod(helper.UsbCdcAcmHelper, helper.UsbCdcAcmHelper_getFd);
  m_logger->info("current fd={}", m_fd);
  if (m_fd == -1)
    return false;
  auto rc = libusb_init(nullptr);
  if (rc < 0)
    goto out;
  rc = libusb_wrap_fd(nullptr, m_fd, &devh);
  if (rc < 0)
    goto out;
#else
  auto rc = libusb_init(nullptr);
  if (rc < 0)
    goto out;
  libusb_set_debug(nullptr, 3);
  for (const auto& vidpid : shtrih_vids_pids)
  {
    devh = libusb_open_device_with_vid_pid(nullptr, vidpid.vid, vidpid.pid);
    if (devh)
    {
      break;
    }
  }
#endif

  if (!devh)
  {
    m_logger->error("Error finding USB device");
    goto out;
  }
  {
    auto device = libusb_get_device(devh);
    if (!device)
    {
      m_logger->error("unable to get device");
      goto out;
    }

    {
      auto ret = libusb_set_auto_detach_kernel_driver(devh, 1);
      if (ret)
      {
        m_logger->error("auto detach kernel driver: failed: {}", ret);
        goto out;
      }
      else
      {
        m_logger->info("auto detach kernel driver: ok");
      }
    }
    if (!setupDev(device))
    {
      m_logger->error("Error device setup");
      goto out;
    }
  }
  {
    // set line state
    rc = libusb_control_transfer(devh, 0x21, 0x22, m_deviceSpecialization.lineStateRequest, 0, NULL, 0, 0);
    if (rc < 0)
    {
      m_logger->error("Error during control transfer: {}", libusb_error_name(rc));
      goto out;
    }
  }
  {
    // set line encoding
    uint8_t encoding[] = { 0x00, 0xc2, 0x01, 0x00, 0x00, 0x00, 0x08 };
    rc = libusb_control_transfer(devh, 0x21, 0x20, 0, 0, encoding, sizeof(encoding), 0);
    if (rc < 0)
    {
      m_logger->error("Error during control transfer: {}", libusb_error_name(rc));
      goto out;
    }
  }
  return true;
out:
  if (devh)
    libusb_close(devh);

  libusb_exit(NULL);
#ifdef __ANDROID__
  {
    auto helper = AndroidHelper::instance(nullptr);
    if (!helper.initOk)
      return false;
    auto holder = helper.env();
    auto env = holder.env();
    env->CallStaticVoidMethod(helper.UsbCdcAcmHelper, helper.UsbCdcAcmHelper_setFd, -1);
    m_fd = -1;
  }
#endif
  return false;
}

void CdcAcmIO::doClose()
{
  if (devh)
    libusb_close(devh);
  libusb_exit(NULL);
#ifdef __ANDROID__
  m_fd = -1;
#endif
}

int64_t CdcAcmIO::doWrite(const char* data, size_t maxSize)
{
  /* To send a char to the device simply initiate a bulk_transfer to the
   * Endpoint with address ep_out_addr.
   */
  int actual_length;
  auto pdata = reinterpret_cast<uint8_t*>(const_cast<char*>(data));
  auto timeout = static_cast<unsigned int>(static_cast<size_t>(byteTimeout().count()));

  auto rc = libusb_bulk_transfer(devh, m_deviceSpecialization.epOut, pdata, static_cast<int>(maxSize), &actual_length, timeout);
  if (rc < 0)
  {
    m_logger->error("Error while sending char");
    return -1;
  }
  return static_cast<int64_t>(actual_length);
}

int64_t CdcAcmIO::doRead(char* data, size_t maxSize)
{
  /* To receive characters from the device initiate a bulk_transfer to the
   * Endpoint with address ep_in_addr.
   */
  int actual_length = 0;
  auto timeout = static_cast<unsigned int>(static_cast<size_t>(byteTimeout().count()));
  int rc = libusb_bulk_transfer(devh, m_deviceSpecialization.epIn, reinterpret_cast<uint8_t*>(data), static_cast<int>(maxSize), &actual_length, timeout);
  if (rc == LIBUSB_ERROR_TIMEOUT)
  {
    m_logger->info("timeout {}", actual_length);
    return -1;
  }
  else if (rc < 0)
  {
    m_logger->error("Error while waiting for char");
    return -1;
  }

  return actual_length;
}
KKTNETD_NAMESPACE_END
