#ifndef SYSTEMTCPSOCKETIO_H
#define SYSTEMTCPSOCKETIO_H
#include <IO/iolayer.h>

KKTNETD_NAMESPACE_BEGIN
class TcpSocketIO;
class SystemTCPSocketIO : public IoLayer {

public:
    enum class Type {
        Client,
        Server
    };
    SystemTCPSocketIO(const u8string& host, uint16_t port);
    ~SystemTCPSocketIO();
    // IoLayer interface
protected:
    bool doOpen() override;
    void doClose() override;
    int64_t doWrite(const char* data, size_t maxSize) override;
    int64_t doRead(char* data, size_t maxSize) override;

public:
    ms byteTimeout() const override;
    void setByteTimeout(const ms& byteTimeout) override;
    bool opened() const override;
    bool clear() override;
    Type m_type = Type::Client;

    Type type() const;
    void setType(const Type type);

private:
    const std::unique_ptr<TcpSocketIO> m_pimpl;
};

KKTNETD_NAMESPACE_END
#endif // SYSTEMTCPSOCKETIO_H
