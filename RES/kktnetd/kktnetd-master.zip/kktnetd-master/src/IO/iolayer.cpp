﻿#include <IO/iolayer.h>
#include <spdlog/logger.h>
#include <utility>
#include <utils/util.h>

KKTNETD_NAMESPACE_BEGIN
constexpr const IoLayer::ms IoLayer::defaultByteTimeout;

IoLayer::ms IoLayer::byteTimeout() const { return m_byteTimeout; }

void IoLayer::setByteTimeout(const ms& byteTimeout) { m_byteTimeout = byteTimeout; }

bool IoLayer::opened() const { return m_opened; }

bool IoLayer::clear() { return false; }

bool IoLayer::accumulateIO() const { return m_accumulateIO; }

void IoLayer::setAccumulateIO(bool accumulateIO) { m_accumulateIO = accumulateIO; }

void IoLayer::setLogLevel(spdlog::level::level_enum level) { m_logger->set_level(level); }

spdlog::level::level_enum IoLayer::logLevel() const { return m_logger->level(); }

IoLayer::IoLayer(logger logger, bool accumulateIO)
    : m_logger(std::move(logger))
    , m_accumulateIO(accumulateIO)
{
  m_logger->set_level(spdlog::level::debug);
}

bool IoLayer::open()
{
  if (opened())
  {
    return true;
  }
  //    m_logger->info("timeout = {}ms", m_timeout.count());
  m_logger->info("byte timeout = {}ms", m_byteTimeout.count());
  auto ret = doOpen();
  if (ret)
  {
    m_logger->info("open() {}", ret);
  }
  else
  {
    m_logger->warn("open() {}", ret);
  }
  m_opened = ret;
  return ret;
}

void IoLayer::close()
{
  if (!m_opened)
  {
    return;
  }
  m_logger->info("close()");
  doClose();
  m_opened = false;
}

int64_t IoLayer::write(const char* data, size_t maxSize)
{
  if (!m_opened)
  {
    m_logger->warn("write() called, but IO closed");
    return -1;
  }
  auto ret = doWrite(data, maxSize);
  if (m_logger->level() > spdlog::level::debug)
  {
    return ret;
  }
  u8string dbg;
  for (auto i = 0; i < ret; i++)
  {
    dbg += fmt::format("{:02X} ", static_cast<uint8_t>(data[i]));
  }
  if (ret < 0)
  {
    dbg = "FAIL ";
  }
  if (!m_accumulateIO)
  {
    m_logger->debug("-> " + Util::rtrim(dbg));
  }
  else
  {
    if (m_lastOp == READ)
    {
      if (!m_readAccum.empty())
      {
        m_logger->debug("<- " + Util::rtrim(m_readAccum));
        m_readAccum.clear();
      }
    }
    if (ret > 0 && ret == static_cast<int64_t>(maxSize))
    {
      m_logger->debug("-> " + Util::rtrim(dbg));
    }
    else
    {
      m_writeAccum += dbg;
    }
  }
  m_lastOp = WRITE;
  return ret;
}

int64_t IoLayer::read(char* data, size_t maxSize)
{
  if (!m_opened)
  {
    m_logger->warn("read() called, but IO closed");
    return -1;
  }
  auto ret = doRead(data, maxSize);
  if (m_logger->level() > spdlog::level::debug)
  {
    return ret;
  }
  u8string dbg;
  for (auto i = 0; i < ret; i++)
  {
    dbg += fmt::format("{:02X} ", static_cast<uint8_t>(data[i]));
  }

  if (ret < 0)
  {
    dbg = "FAIL ";
  }
  if (!m_accumulateIO)
  {
    m_logger->debug("<- " + Util::rtrim(dbg));
  }
  else
  {
    if (m_lastOp == WRITE)
    {
      if (!m_writeAccum.empty())
      {
        m_logger->debug("-> " + Util::rtrim(m_writeAccum));
        m_writeAccum.clear();
      }
    }
    if (ret > 0 && ret == static_cast<int64_t>(maxSize))
    {
      m_logger->debug("<- " + Util::rtrim(dbg));
    }
    else
    {
      m_readAccum += dbg;
    }
  }
  m_lastOp = READ;
  return ret;
}

IoLayer::~IoLayer() { }

KKTNETD_NAMESPACE_END
