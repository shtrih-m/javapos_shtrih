#include <api.h>
#include <iostream>
#include <limits>
#include <thread>

void print_usage(std::string_view progname)
{
  auto slash_pos = progname.find_last_of('/');
  if (slash_pos != std::string_view::npos)
  {
    progname = std::string_view(progname.data() + slash_pos + 1, progname.size() - slash_pos);
  }

  std::cerr << "usage: " << progname.data() << " [type] [path]"
            << "\n\ttype:\n"
            << "\t\tforwarder - tcp/unix socket ppp forwarder "
            << "\t\tserial - work with serial port"
            << "\n\tpath:\n"
            << "\t\tforwarder:  tcp - port, unix socket - path"
            << "\n\t\tserial: port path/name\n"
            << "\n"
            << "       " << progname.data() << " -v"
            << "\n"
            << "\tprint version"
            << "\n\n"
            << "       " << progname.data() << " -h"
            << "\n"
            << "\tprint this help\n";
}
void print_version() { std::cerr << APPLICATION_VERSION << '\n'; }

static int emain(int argc, char* argv[])
{
#ifdef _WIN32
  const char default_path[] = "17778\0";
#else
  const char default_path[] = "\0kktnetd";
#endif
  std::string_view path = std::string_view(default_path, sizeof(default_path) - 1);
  std::string_view type { "forwarder" };
  if (argc == 2 && std::string_view(argv[1]) == "-h")
  {
    print_usage(argv[0]);
    return EXIT_SUCCESS;
  }
  if (argc == 2 && std::string_view(argv[1]) == "-v")
  {
    print_version();
    return EXIT_SUCCESS;
  }
  if (argc > 1)
  {
    type = argv[1];

    if (type != "forwarder" && type != "serial")
    {
      std::cerr << "only forwarder or serial type allowed" << std::endl;
      return EXIT_FAILURE;
    }
    if (type == "serial")
    {
#ifdef _WIN32
      path = "COM1";
#else
      path = "/dev/ttyUSB0";
#endif
    }
  }
  if (argc > 2)
  {
    path = argv[2];
  }

  bool is_serial = type == "serial";
  uint32_t flags = kktnetd_app_flags::watch_signals;
  if (is_serial)
  {
    flags |= kktnetd_app_flags::use_serial;
  }

  auto ret = kktnetd_run_app(path.data(), path.size(), flags);
  return ret == std::numeric_limits<std::size_t>::max() ? EXIT_FAILURE : EXIT_SUCCESS;
}
int main(int argc, char* argv[])
{
  try
  {
    return emain(argc, argv);
  }
  catch (const std::exception& e)
  {
    std::cerr << e.what() << '\n';
  }
  catch (...)
  {
    std::cerr << "unknown error" << '\n';
  }
}