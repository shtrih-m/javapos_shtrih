#include "pppos_netif.h"
#include <memory>
#include <spdlog/logger.h>
#include <utils/lwipcorelocker.h>

extern "C"
{
  /* lwIP core includes */
#include "lwip/opt.h"

#include "lwip/api.h"
#include "lwip/debug.h"
#include "lwip/init.h"
#include "lwip/netif.h"
#include "lwip/stats.h"
#include "lwip/sys.h"
#include "lwip/tcpip.h"
#include "lwip/timeouts.h"

#include "lwip/autoip.h"
#include "lwip/dhcp.h"
#include "lwip/dns.h"
#include "lwip/tcp.h"
#include "lwip/udp.h"

  /* lwIP netif includes */
#include "lwip/etharp.h"
#include "netif/ethernet.h"

#if NO_SYS
  /* ... then we need information about the timer intervals: */
#  include "lwip/igmp.h"
#  include "lwip/ip4_frag.h"
#endif /* NO_SYS */

#include "netif/ppp/ppp_opts.h"
#if PPP_SUPPORT
  /* PPP includes */
#  include "netif/ppp/pppapi.h"
#  include "netif/ppp/pppos.h"
#endif /* PPP_SUPPORT */

  /* include the port-dependent configuration */
#include "lwipcfg.h"
}

#define TSTS_OPTION TCP_TMR_INTERVAL

KKTNETD_NAMESPACE_BEGIN

struct pppos_if::impl
{
  Mode mode = Mode::Server;
  std::string our_ip;
  std::string peer_ip;
  ppp_pcb_s* ppp_pcb = nullptr;
  struct netif netif;

  pppos_output_fn output_cb;
  start_apps_fn start_apps_cb;
  stop_apps_fn stop_apps_cb;

  std::shared_ptr<spdlog::logger> logger = LOGGER_FOR_CLASSNAME(pppos_if);
  std::atomic_bool stopping = false;
  impl(Mode mode_, std::string_view our_ip_, std::string_view peer_ip_)
      : mode(mode_)
      , our_ip(our_ip_)
      , peer_ip(peer_ip_)
  {
  }
  int listenPPP()
  {
    logger->debug("listenPPP");
    return ppp_listen(ppp_pcb);
  }
  int connectPPP()
  {
    logger->debug("connectPPP");
    return ppp_connect(ppp_pcb, 0);
  }
  int establishPPPConnection()
  {
    if (mode == Mode::Server)
    {
      return listenPPP();
    }
    return connectPPP();
  }
  uint32_t write(const char* data, size_t size)
  {
    if (!output_cb)
    {
      return 0;
    }
    return output_cb(net::buffer(data, size));
  }
};

/* This function initializes applications */
static void apps_init(pppos_if::impl* ctx)
{
  if (!ctx->start_apps_cb)
  {
    return;
  }
  ctx->start_apps_cb();
}
static void apps_deinit(pppos_if::impl* ctx)
{
  if (!ctx->stop_apps_cb)
  {
    return;
  }
  ctx->stop_apps_cb();
}

#if LWIP_NETIF_STATUS_CALLBACK

static auto netifLogger = []()
{
  static auto logger = getLog("lwip netif");
  return logger;
};

static void status_callback(struct netif* state_netif)
{
  static auto logger = netifLogger();
  if (netif_is_up(state_netif))
  {
#  if LWIP_IPV4
    logger->info("status_callback==UP, local interface IP is {}", ip4addr_ntoa(netif_ip4_addr(state_netif)));
#  else
    me->logger->debug("status_callback==UP");
#  endif
  }
  else
  {
    logger->info("status_callback==DOWN");
  }
}
#endif /* LWIP_NETIF_STATUS_CALLBACK */

#if LWIP_NETIF_LINK_CALLBACK
static void link_callback(struct netif* state_netif)
{
  static auto logger = netifLogger();

  if (netif_is_link_up(state_netif))
  {
    logger->info("link_callback==UP");
  }
  else
  {
    logger->info("link_callback==DOWN");
  }
}
#endif /* LWIP_NETIF_LINK_CALLBACK */

static void linkStatusCallback(ppp_pcb* pcb, int errCode, void* ctx)
{
  struct netif* pppif = ppp_netif(pcb);
  auto me = static_cast<pppos_if::impl*>(ctx);
  switch (errCode)
  {
  case PPPERR_NONE:
  { /* No error. */

    me->logger->debug("PPPERR_NONE");
#if LWIP_IPV4
    me->logger->debug("   our_ipaddr  = {}", ip4addr_ntoa(netif_ip4_addr(pppif)));
    me->logger->debug("   his_ipaddr  = {}", ip4addr_ntoa(netif_ip4_gw(pppif)));
    me->logger->debug("   netmask     = {}", ip4addr_ntoa(netif_ip4_netmask(pppif)));
#endif /* LWIP_IPV4 */
#if LWIP_DNS
    me->logger->debug("   dns1        = {}", ipaddr_ntoa(dns_getserver(0)));
    me->logger->debug("   dns2        = {}", ipaddr_ntoa(dns_getserver(1)));
#endif /* LWIP_DNS */
#if PPP_IPV6_SUPPORT
    me->logger->debug("   our6_ipaddr = {}", ip6addr_ntoa(netif_ip6_addr(pppif, 0)));
#endif /* PPP_IPV6_SUPPORT */
    apps_init(me); // TODO: start from here
    return;
  }
  case PPPERR_PARAM:
  { /* Invalid parameter. */
    me->logger->debug("PPPERR_PARAM");
    break;
  }
  case PPPERR_OPEN:
  { /* Unable to open PPP session. */
    me->logger->debug("PPPERR_OPEN");
    break;
  }
  case PPPERR_DEVICE:
  { /* Invalid I/O device for PPP. */
    me->logger->debug("PPPERR_DEVICE");
    break;
  }
  case PPPERR_ALLOC:
  { /* Unable to allocate resources. */
    me->logger->debug("PPPERR_ALLOC");
    break;
  }
  case PPPERR_USER:
  { /* User interrupt. */
    me->logger->debug("PPPERR_USER");
    break;
  }
  case PPPERR_CONNECT:
  { /* Connection lost. */
    me->logger->debug("PPPERR_CONNECT");
    break;
  }
  case PPPERR_AUTHFAIL:
  { /* Failed authentication challenge. */
    me->logger->debug("PPPERR_AUTHFAIL");
    break;
  }
  case PPPERR_PROTOCOL:
  { /* Failed to meet protocol. */
    me->logger->debug("PPPERR_PROTOCOL");
    break;
  }
  case PPPERR_PEERDEAD:
  { /* Connection timeout */
    me->logger->debug("PPPERR_PEERDEAD");
    break;
  }
  case PPPERR_IDLETIMEOUT:
  { /* Idle Timeout */
    me->logger->debug("PPPERR_IDLETIMEOUT");
    break;
  }
  case PPPERR_CONNECTTIME:
  { /* Max connect time reached */
    me->logger->debug("PPPERR_CONNECTTIME");
    break;
  }
  case PPPERR_LOOPBACK:
  { /* Loopback detected */
    me->logger->debug("PPPERR_LOOPBACK");
    break;
  }
  default:
  {
    me->logger->debug("unknown errCode {}", errCode);
    break;
  }
  }
}
KKTNETD_NAMESPACE_END
KKTNETD_NAMESPACE_BEGIN

pppos_if::pppos_if(Mode mode, std::string_view our_ip, std::string_view peer_ip)
    : m_impl(std::make_unique<pppos_if::impl>(mode, our_ip, peer_ip))
{
  m_impl->logger->set_level(spdlog::level::debug);
}

pppos_if::~pppos_if()
{
  m_impl->stopping = true;
  if (m_impl->ppp_pcb)
  {

    err_t ret;
    {
      LWIPCoreLocker lock;
      ret = ppp_close(m_impl->ppp_pcb, 1);
      if (ret)
      {
        m_impl->logger->error("ppp_close failed with: {}", ret);
      }
    }
    while (0 == 0)
    {
      {
        LWIPCoreLocker lock;
        ret = ppp_free(m_impl->ppp_pcb);
      }
      if (ret != 0)
      {
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
      }
      else
      {
        return;
      }
    }
  }
}
static u32_t zsio_write(ppp_pcb* pcb, u8_t* data, u32_t len, void* ctx)
{
  LWIP_UNUSED_ARG(pcb);
  LWIP_UNUSED_ARG(ctx);
  if (!ctx)
  {
    return -1;
  }
  auto me = static_cast<pppos_if::impl*>(ctx);
  return me->write(reinterpret_cast<const char*>(data), len);
}

static void ppp_notify_phase_cb(ppp_pcb* pcb, u8_t phase, void* ctx)
{
  auto me = static_cast<pppos_if::impl*>(ctx);

  switch (phase)
  {

  /* Session is down (either permanently or briefly) */
  case PPP_PHASE_DEAD:
    //        led_set(PPP_LED, LED_OFF);
    me->logger->debug("PPP_PHASE_DEAD");
    if (me->stopping)
    {
      return;
    }
    me->establishPPPConnection();

    break;

  /* We are between two sessions */
  case PPP_PHASE_HOLDOFF:
    //        led_set(PPP_LED, LED_SLOW_BLINK);
    me->logger->debug("PPP_PHASE_HOLDOFF");

    break;

  /* Session just started */
  case PPP_PHASE_INITIALIZE:
    //        led_set(PPP_LED, LED_FAST_BLINK);
    me->logger->debug("PPP_PHASE_INITIALIZE");

    break;

  /* Session is running */
  case PPP_PHASE_RUNNING:
    me->logger->debug("PPP_PHASE_RUNNING");
    break;
  case PPP_PHASE_NETWORK:
    me->logger->debug("PPP_PHASE_NETWORK");
    break;
  case PPP_PHASE_ESTABLISH:
    me->logger->debug("PPP_PHASE_ESTABLISH");
    break;
  case PPP_PHASE_DISCONNECT:
    me->logger->debug("PPP_PHASE_DISCONNECT");
    apps_deinit(me);
    break;
  case PPP_PHASE_AUTHENTICATE:
    me->logger->debug("PPP_PHASE_AUTHENTICATE");
    break;
  case PPP_PHASE_TERMINATE:
    me->logger->debug("PPP_PHASE_TERMINATE");
    break;
  default:
    me->logger->debug("PPP_PHASE_UNKNOWN {}", +phase);

    break;
  }
}

void pppos_if::run()
{
  LWIPCoreLocker locker;

  m_impl->netif = { 0 };
  m_impl->ppp_pcb = pppos_create(&m_impl->netif, &zsio_write, linkStatusCallback, m_impl.get());
  if (!m_impl->ppp_pcb)
  {
    throw std::runtime_error("unable to create pppos interface");
  }
  netif_set_status_callback(&m_impl->netif, status_callback);
  netif_set_link_callback(&m_impl->netif, link_callback);
  ppp_set_auth(m_impl->ppp_pcb, PPPAUTHTYPE_ANY, "ppp", "ppp");

  ppp_set_default(m_impl->ppp_pcb);
  if (m_impl->mode == Mode::Server)
  {
    ip4_addr_t addr;

    /* Set our address */
    IP4_ADDR(&addr, 192, 168, 1, 169);
    ppp_set_ipcp_ouraddr(m_impl->ppp_pcb, &addr);

    /* Set peer(his) address */
    IP4_ADDR(&addr, 192, 168, 1, 168);
    ppp_set_ipcp_hisaddr(m_impl->ppp_pcb, &addr);

    /* Set primary DNS server */
    IP4_ADDR(&addr, 8, 8, 8, 8);
    ppp_set_ipcp_dnsaddr(m_impl->ppp_pcb, 0, &addr);
  }

  ppp_set_notify_phase_callback(m_impl->ppp_pcb, ppp_notify_phase_cb);
}

struct netif* pppos_if::netif() { return &m_impl->netif; }

void pppos_if::input(net::const_buffer buf)
{
  LWIPCoreLocker lock;
  pppos_input(m_impl->ppp_pcb, (uint8_t*)buf.data(), buf.size());
}
void pppos_if::output_cb(pppos_if::pppos_output_fn output) { m_impl->output_cb = output; }
void pppos_if::start_apps_cb(pppos_if::start_apps_fn fn) { m_impl->start_apps_cb = fn; }
void pppos_if::stop_apps_cb(pppos_if::start_apps_fn fn) { m_impl->stop_apps_cb = fn; }

KKTNETD_NAMESPACE_END
