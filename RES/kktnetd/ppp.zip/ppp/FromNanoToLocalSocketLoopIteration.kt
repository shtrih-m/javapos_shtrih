package ru.shtrihm.soft.shtrihcash.model.pluggabledevices.nano.ppp

import ru.shtrihm.soft.shtrihcash.model.utils.*

interface IFromNanoToLocalSocketLoopIteration {
	suspend fun execute()
}

private val Log = getLogger<FromNanoToLocalSocketLoopIteration>()

class FromNanoToLocalSocketLoopIteration(
	private val mNanoDevice: INanoDevice,
	private val mLocalSocket: IKktLocalSocket
) : IFromNanoToLocalSocketLoopIteration {

	override suspend fun execute() {
		val data = mNanoDevice.read()
		if (NanoLoggingSettings.ITERATION_BYTES)
			Log.d("Nano->LocalSocket[${data.size}]: ${data.toHexString()}")
		mLocalSocket.write(data)
	}
}