package ru.shtrihm.soft.shtrihcash.model.pluggabledevices.nano.ppp

interface INanoDevice {

	suspend fun connect()
	fun disconnect()

	suspend fun read(): ByteArray
	suspend fun write(data: ByteArray)
}

// private val Log = getLogger<NanoDevice>()

class NanoDevice(private val mNanoMac: String) : INanoDevice {

	private var mManager: NanoBleManager? = null

	override suspend fun connect() {
		disconnect()
		mManager = NanoBleManager()
		mManager?.connect(mNanoMac)
	}

	override fun disconnect() {
		mManager?.disconnectFrom()
	}

	override suspend fun read(): ByteArray {
		return mManager?.read() ?: throw Exception("Ошибка чтения данных из nano: устройство не подключено")
	}

	override suspend fun write(data: ByteArray) {
		mManager?.write(data) ?: throw Exception("Ошибка записи данных в nano: устройство не подключено")
	}
}