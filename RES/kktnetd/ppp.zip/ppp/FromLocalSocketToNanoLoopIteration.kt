package ru.shtrihm.soft.shtrihcash.model.pluggabledevices.nano.ppp

import ru.shtrihm.soft.shtrihcash.model.utils.*

interface IFromLocalSocketToNanoLoopIteration {
	suspend fun execute()
}

private val Log = getLogger<FromLocalSocketToNanoLoopIteration>()

class FromLocalSocketToNanoLoopIteration(
	private val mLocalSocket: IKktLocalSocket,
	private val mNanoDevice: INanoDevice
) : IFromLocalSocketToNanoLoopIteration {

	override suspend fun execute() {
		val data = mLocalSocket.read()
		if (NanoLoggingSettings.ITERATION_BYTES)
			Log.d("LocalSocket->Nano[${data.size}]: ${data.toHexString()}")
		mNanoDevice.write(data)
	}
}