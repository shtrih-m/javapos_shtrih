package ru.shtrihm.soft.shtrihcash.model.pluggabledevices.nano.ppp

import java.io.*

interface IKktLocalSocketReader {
	fun read(input: InputStream): ByteArray
}

class KktLocalSocketReader : IKktLocalSocketReader {

	companion object {
		const val BUFFER_SIZE = 1024 * 4
	}

	private val mReadBuf = ByteArray(BUFFER_SIZE)

	override fun read(input: InputStream): ByteArray {
		val nRead = input.read(mReadBuf)
		if (nRead < 0)
			throw Exception("Read negative number of bytes: $nRead")
		val data = ByteArray(nRead)
		mReadBuf.copyInto(data, endIndex = nRead)
		return data
	}
}