package ru.shtrihm.soft.shtrihcash.model.pluggabledevices.nano.ppp

import android.bluetooth.*
import android.bluetooth.BluetoothGattCharacteristic.*
import android.content.*
import android.util.Log.*
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.*
import no.nordicsemi.android.ble.*
import no.nordicsemi.android.ble.data.*
import no.nordicsemi.android.ble.exception.*
import no.nordicsemi.android.ble.ktx.*
import ru.shtrihm.soft.shtrihcash.model.services.*
import ru.shtrihm.soft.shtrihcash.model.utils.*
import java.util.*

private val Log = getLogger<NanoBleManager>()

class NanoBleManager : BleManager(App.getImpl() as Context) {

	private companion object {
		val UART_UUID: UUID = UUID.fromString("0000ABF0-0000-1000-8000-00805f9b34fb")
		val RX_UUID: UUID = UUID.fromString("0000ABF1-0000-1000-8000-00805f9b34fb")
		val TX_UUID: UUID = UUID.fromString("0000ABF2-0000-1000-8000-00805f9b34fb")
	}

	private var mRx: BluetoothGattCharacteristic? = null
	private var mTx: BluetoothGattCharacteristic? = null
	private val mReadBytesChannel = Channel<ByteArray>(Channel.BUFFERED)

	override fun getGattCallback(): BleManagerGattCallback = NanoGattCallback()

	suspend fun connect(nanoMac: String) {
		val device = getNanoDeviceByMac(nanoMac)
		Log.d("Nano-устройство успешно найдено по mac: $nanoMac, connecting...")
		connect(device).suspend()
		Log.d("Успешное подключение к nano")
	}

	fun disconnectFrom() {
		try {
			if (isConnected)
				disconnect().await()
		} catch (e: InvalidRequestException) {
			// ignore
		}
		close()
	}

	suspend fun read() =
		mReadBytesChannel.receive()

	suspend fun write(data: ByteArray) {
		if (mRx == null)
			throw Exception("Ошибка записи данных в nano: rx is null")
		writeCharacteristic(mRx, data, WRITE_TYPE_DEFAULT)
			.split()
			.suspend()
	}

	override fun log(priority: Int, message: String) {
		if (!NanoLoggingSettings.BLE_MANAGER_DETAILS)
			return
		when (priority) {
			VERBOSE, DEBUG -> Log.d(message)
			INFO -> Log.i(message)
			WARN -> Log.w(message)
			ERROR, ASSERT -> Log.e(message)
			else -> Log.d(message)
		}
	}

	@Suppress("DEPRECATION")
	private fun getNanoDeviceByMac(nanoMac: String): BluetoothDevice =
		BluetoothAdapter.getDefaultAdapter().getRemoteDevice(nanoMac)
			?: throw Exception("Не удалось найти nano-устройство по его mac: $nanoMac")

	private inner class NanoGattCallback : BleManagerGattCallback() {

		override fun initialize() {
			Log.d("initialize()")
			requestMtu(20 + 3).fail { _, status ->
				Log.e("Requested MTU not supported: $status")
			}.enqueue()
			setNotificationCallback(mTx).with { _, data: Data ->
				writeDataOnNotification(data.value)
			}
			enableNotifications(mTx).fail { _, status ->
				Log.e("Notifications not supported: $status")
			}.enqueue()
		}

		override fun isRequiredServiceSupported(gatt: BluetoothGatt) =
			try {
				Log.d("isRequiredServiceSupported()")
				val uartService = getService(gatt, UART_UUID)
				mRx = getCharacteristic(uartService, RX_UUID, "RX")
				mTx = getCharacteristic(uartService, TX_UUID, "TX")
				true
			} catch (e: Exception) {
				Log.e(e, "Ошибка инициализации ble")
				false
			}

		override fun onServicesInvalidated() {
			Log.d("onServicesInvalidated()")
			mRx = null
			mTx = null
			mReadBytesChannel.close()
		}

		private fun writeDataOnNotification(data: ByteArray?) {
			if (data == null)
				mReadBytesChannel.cancel(CancellationException("Null bytes received"))
			else
				mReadBytesChannel.trySend(data)
		}

		private fun getService(gatt: BluetoothGatt, uuid: UUID): BluetoothGattService =
			gatt.getService(uuid) ?: throw Exception("Uart service not found")

		private fun getCharacteristic(service: BluetoothGattService, uuid: UUID, name: String): BluetoothGattCharacteristic =
			service.getCharacteristic(uuid) ?: throw Exception("$name characteristic not found")
	}
}