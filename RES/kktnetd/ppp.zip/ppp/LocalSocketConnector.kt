package ru.shtrihm.soft.shtrihcash.model.pluggabledevices.nano.ppp

import kotlinx.coroutines.*
import ru.shtrihm.soft.shtrihcash.model.utils.*

interface ILocalSocketConnector {

	suspend fun connect()
	fun disconnect()
}

private val Log = getLogger<LocalSocketConnector>()

class LocalSocketConnector(
	private val mLocalSocket: IKktLocalSocket
) : ILocalSocketConnector {

	override suspend fun connect() {
		while (true) {
			try {
				yield()
				mLocalSocket.connect()
				Log.d("Успешное подключение к локальному сокету: ${mLocalSocket.name}")
				break
			} catch (e: Exception) {
				Log.e(e, "Ошибка подключения к локальному сокету: ${mLocalSocket.name}")
				delay(10_000)
			}
		}
	}

	override fun disconnect() {
		try {
			mLocalSocket.disconnect()
		} catch (e: Exception) {
			Log.e(e, "Ошибка отключения локального сокета ${mLocalSocket.name}")
		}
	}
}
