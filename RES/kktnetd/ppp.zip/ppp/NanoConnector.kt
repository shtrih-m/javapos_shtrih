package ru.shtrihm.soft.shtrihcash.model.pluggabledevices.nano.ppp

import kotlinx.coroutines.*
import ru.shtrihm.soft.shtrihcash.model.utils.*

interface INanoConnector {

	suspend fun connect()
	fun disconnect()
}

private val Log = getLogger<NanoConnector>()

class NanoConnector(
	private val mNanoDevice: INanoDevice
) : INanoConnector {

	override suspend fun connect() {
		while (true) {
			try {
				yield()
				mNanoDevice.connect()
				Log.d("Успешное подключение к nano-устройству")
				break
			} catch (e: Exception) {
				Log.e(e, "Ошибка подключения к nano-устройству")
				delay(10_000)
			}
		}
	}

	override fun disconnect() {
		try {
			mNanoDevice.disconnect()
		} catch (e: Exception) {
			Log.e(e, "Ошибка отключения nano-устройства")
		}
	}
}