package ru.shtrihm.soft.shtrihcash.model.pluggabledevices.nano.ppp

import android.net.*

interface IKktLocalSocket {

	val name: String

	fun connect()
	fun disconnect()

	fun read(): ByteArray
	fun write(data: ByteArray)
}

// private val Log = getLogger<KktLocalSocket>()

class KktLocalSocket(
	private val mName: String,
	private val mReader: IKktLocalSocketReader
) : IKktLocalSocket {

	private var mLocalSocket = LocalSocket()

	override val name get() = mName

	override fun connect() {
		disconnect()
		mLocalSocket = LocalSocket()
		mLocalSocket.connect(LocalSocketAddress(mName))
	}

	override fun disconnect() {
		mLocalSocket.shutdownInput()
		mLocalSocket.shutdownOutput()
		mLocalSocket.close()
	}

	override fun read() =
		mReader.read(mLocalSocket.inputStream)

	override fun write(data: ByteArray) =
		mLocalSocket.outputStream.write(data)
}