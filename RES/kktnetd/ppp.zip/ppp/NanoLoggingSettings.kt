package ru.shtrihm.soft.shtrihcash.model.pluggabledevices.nano.ppp

object NanoLoggingSettings {
	const val BLE_MANAGER_DETAILS = true
	const val ITERATION_BYTES = true
}