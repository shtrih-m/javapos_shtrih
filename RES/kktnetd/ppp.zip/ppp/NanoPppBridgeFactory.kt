package ru.shtrihm.soft.shtrihcash.model.pluggabledevices.nano.ppp

import kotlinx.coroutines.*

object NanoPppBridgeFactory {

	private const val LOCAL_SOCKET_NAME = "KKT_NET"

	fun new(nanoMac: String): NanoPppBridge {
		KktNetStarter.startIfNotStarted(LOCAL_SOCKET_NAME)
		val nanoDevice = NanoDevice(nanoMac)
		val localSocket = KktLocalSocket(LOCAL_SOCKET_NAME, KktLocalSocketReader())
		return NanoPppBridge(
			Dispatchers.IO,
			NanoConnector(nanoDevice),
			LocalSocketConnector(localSocket),
			FromNanoToLocalSocketLoopIteration(nanoDevice, localSocket),
			FromLocalSocketToNanoLoopIteration(localSocket, nanoDevice)
		)
	}
}