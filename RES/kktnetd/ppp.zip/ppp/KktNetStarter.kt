package ru.shtrihm.soft.shtrihcash.model.pluggabledevices.nano.ppp

import kotlinx.coroutines.*
import ru.shtrih_m.kktnetd.*
import ru.shtrihm.soft.shtrihcash.model.utils.*

object KktNetStarter {

	private val Log: ILog = getLogger<KktNetStarter>()

	private var IsKktNetStarted = false

	fun startIfNotStarted(localSocketName: String) {
		if (IsKktNetStarted)
			return
		IsKktNetStarted = true
		GlobalScope.launch(newSingleThreadContext("kktnetd")) {
			Log.d("Запуск kktnetd...")
			// Этот вызов блокирующий, если запуск успешен.
			val result = Api.start(localSocketName)
			Log.d("Api.start() завершён: result=$result")
		}
	}
}