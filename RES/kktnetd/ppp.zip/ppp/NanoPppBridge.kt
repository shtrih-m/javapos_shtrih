package ru.shtrihm.soft.shtrihcash.model.pluggabledevices.nano.ppp

import kotlinx.coroutines.*
import ru.shtrihm.soft.shtrihcash.model.utils.*

// Важно помнить следующее про метод awaitAll():
// при возникновении исключения в одной из корутин, другая будет отменена, т.к.
// awaitAll выкинет исключение в текущем coroutine scope.

private val Log = getLogger<NanoPppBridge>()

class NanoPppBridge(
	dispatcher: CoroutineDispatcher,
	private val mNanoConnector: INanoConnector,
	private val mLocalSocketConnector: ILocalSocketConnector,
	private val mFromNanoToLocalSocketLoopIteration: IFromNanoToLocalSocketLoopIteration,
	private val mFromLocalSocketToNanoLoopIteration: IFromLocalSocketToNanoLoopIteration
) {

	private val mScope = CoroutineScope(dispatcher + SupervisorJob())

	fun start() {
		mScope.launch {
			mainExchangeLoop()
		}
	}

	fun dispose() {
		Log.d("Disposing bridge...")
		mNanoConnector.disconnect()
		mLocalSocketConnector.disconnect()
		mScope.cancel("dispose() called on bridge")
	}

	// Если какое либо исключение, то заново коннектимся к нано и локальному сокету и снова начинаем обмен.
	private suspend fun mainExchangeLoop() {
		while (mScope.isActive) {
			connectAllUntilSuccess()
			try {
				runExchangeLoops()
			} catch (e: CancellationException) {
				Log.d("CancellationException catched in bridge")
			} catch (e: Exception) {
				Log.e(e, "Ошибка обмена: делаем реконнект к нано и локальному сокету и снова запускаем обмен")
			}
		}
		Log.d("Main exchange loop finished")
	}

	private suspend fun connectAllUntilSuccess() = coroutineScope {
		awaitAll(
			async { mNanoConnector.connect() },
			async { mLocalSocketConnector.connect() }
		)
	}

	private suspend fun runExchangeLoops() = coroutineScope {
		awaitAll(
			async { fromLocalSocketToNanoLoop() },
			async { fromNanoToLocalSocketLoop() }
		)
	}

	private suspend fun fromLocalSocketToNanoLoop() {
		exchangeLoop("LocalSocket->Nano loop") {
			mFromLocalSocketToNanoLoopIteration.execute()
		}
	}

	private suspend fun fromNanoToLocalSocketLoop() {
		exchangeLoop("Nano->LocalSocket loop") {
			mFromNanoToLocalSocketLoopIteration.execute()
		}
	}

	private suspend fun exchangeLoop(loopName: String, iterate: suspend () -> Unit) {
		try {
			Log.d("$loopName started")
			while (true) {
				yield() // возможность отмены
				iterate()
			}
		} finally {
			Log.d("$loopName finished")
		}
	}
}