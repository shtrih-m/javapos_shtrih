#!/bin/bash
set -e
GIT_LAST_TAG=$(git describe --always --tags|cut -f1 -d-)
GIT_COMMITS_COUNT=$(git rev-list --count HEAD)
GIT_VERSION=$GIT_LAST_TAG.$GIT_COMMITS_COUNT
mkdir -p dist/win_$GIT_VERSION/

function compile()
{
    local ARCH=$1
    echo "compiling for $ARCH"
    mkdir -p build/$ARCH
    mkdir -p dist/win_$GIT_VERSION/$ARCH/
    cd build/$ARCH
    local STUDIO_CMAKE_ARG
    if [ "$ARCH" == "i386" ]
    then
    local STUDIO_CMAKE_ARG="Visual Studio 15 2017"
    else
    local STUDIO_CMAKE_ARG="Visual Studio 15 2017 Win64"
    fi
    cmake ../../ -G"$STUDIO_CMAKE_ARG" -Tv141_xp ../../ -DCMAKE_BUILD_TYPE=Release 
    cmake --build . --config Release
    cp "Release\kktnetd.exe" "../../dist/win_$GIT_VERSION/$ARCH/kktnetd.exe"
    rm -Rf *
    cmake ../../ -G"$STUDIO_CMAKE_ARG" -Dkktnetd_SHARED_LIBS=ON  -Tv141_xp ../../ -DCMAKE_BUILD_TYPE=Release
    cmake --build . --config Release --target kktnetd-lib
    cp "Release\kktnetd.dll" "../../dist/win_$GIT_VERSION/$ARCH/kktnetd.dll"
    cd ../../
}

compile "$1"
