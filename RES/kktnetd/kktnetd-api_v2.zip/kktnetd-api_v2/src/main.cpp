#include <api.h>
#include <boost/json.hpp>
#include <boost/json/src.hpp>
#include <iostream>
#include <limits>
#include <thread>

namespace
{
using kktnetd_api_context_t_ptr = std::unique_ptr<kktnetd_api_context_t, decltype(&kktnetd_api_deinit)>;

}

void print_usage(std::string_view progname)
{
  auto slash_pos = progname.find_last_of('/');
  if (slash_pos != std::string_view::npos)
  {
    progname = std::string_view(progname.data() + slash_pos + 1, progname.size() - slash_pos);
  }

  std::cerr << "usage: " << progname.data() << " [type] [path]"
            << "\n\ttype:\n"
            << "\t\tforwarder - tcp/unix socket ppp forwarder "
            << "\t\tserial - work with serial port"
            << "\n\tpath:\n"
            << "\t\tforwarder:  tcp - port, unix socket - path"
            << "\n\t\tserial: port path/name\n"
            << "\n"
            << "       " << progname.data() << " -v"
            << "\n"
            << "\tprint version"
            << "\n\n"
            << "       " << progname.data() << " -h"
            << "\n"
            << "\tprint this help\n";
}
void print_version() { std::cerr << APPLICATION_VERSION << '\n'; }
static constexpr std::string_view DEFAULT_CONFIG =
#ifdef _WIN32
    R"__(
{
  "handle_signals": true,
  "resender": {
    "host": "localhost",
    "port": 7778,
    "remote_port": 7778,
    "socks_port": 1080
  },
  "transport": {
    "type": "forwarder",
    "path": "17778"
  },
  "ppp": {
    "our_ip": "192.168.1.169",
    "peer_ip": "192.168.1.168",
    "peer_dns": "8.8.8.8"
  }
}
)__";
#else
    R"__(
{
  "handle_signals": true,
  "resender": {
    "host": "localhost",
    "port": 7778,
    "remote_port": 7778,
    "socks_port": 1080
  },
  "transport": {
    "type": "forwarder",
    "path": "kktnetd"
  },
  "ppp": {
    "our_ip": "192.168.1.169",
    "peer_ip": "192.168.1.168",
    "peer_dns": "8.8.8.8"
  }
}
)__";
#endif

static int emain(int argc, char* argv[])
{
#ifdef _WIN32
  constexpr std::string_view default_path = "17778";
#else
  constexpr std::string_view default_path = "kktnetd";
#endif
  std::string_view path = default_path;
  std::string_view type { "forwarder" };
  if (argc == 2 && std::string_view(argv[1]) == "-h")
  {
    print_usage(argv[0]);
    return EXIT_SUCCESS;
  }
  if (argc == 2 && std::string_view(argv[1]) == "-v")
  {
    print_version();
    return EXIT_SUCCESS;
  }
  if (argc > 1)
  {
    type = argv[1];

    if (type != "forwarder" && type != "serial")
    {
      std::cerr << "only forwarder or serial type allowed" << std::endl;
      return EXIT_FAILURE;
    }
    if (type == "serial")
    {
#ifdef _WIN32
      path = "COM1";
#else
      path = "/dev/ttyUSB0";
#endif
    }
  }
  if (argc > 2)
  {
    path = argv[2];
  }

  bool is_serial = type == "serial";

  namespace json = boost::json;

  static json::value config = json::parse(DEFAULT_CONFIG);
  auto& config_o = config.as_object();
  auto& transport_o = config_o["transport"].as_object();

  if (is_serial)
  {
    transport_o["type"] = "serial";
  }
  transport_o["path"] = path;
  auto dump = json::serialize(config);
  auto ctx = kktnetd_api_context_t_ptr(kktnetd_api_init(dump.data()), kktnetd_api_deinit);
  if (!ctx)
  {
    throw std::runtime_error("unable to init kktnetd context");
  }
  //  // TMP BEGIN
  //  auto dump2 = std::string_view(R"__(
  //  {
  //    "handle_signals": true,
  //    "resender": {
  //      "host": "localhost",
  //      "port": 17778,
  //      "remote_port": 7778,
  //      "socks_port": 1080
  //    },
  //    "transport": {
  //      "type": "serial",
  //      "path": "/dev/ttyUSB0"
  //    },
  //    "ppp": {
  //      "our_ip": "192.168.1.171",
  //      "peer_ip": "192.168.1.170",
  //      "peer_dns": "8.8.8.8"
  //    }
  //  }
  //  )__");
  //  auto ctx2 = kktnetd_api_context_t_ptr(kktnetd_api_init(dump2.data()), kktnetd_api_deinit);
  //  std::vector<std::thread> threads;
  //  for (auto context : { &ctx, &ctx2 })
  //  {
  //    threads.push_back(std::thread([&context]() { kktnetd_api_run(context->get()); }));
  //  }
  //  std::this_thread::sleep_for(std::chrono::minutes(1));
  //  for (auto& thread : threads)
  //  {
  //    thread.join();
  //  }
  //  return 0;
  //  // TMP END
  auto ret = kktnetd_api_run(ctx.get());
  auto ret_val = ret == std::numeric_limits<std::size_t>::max() ? EXIT_FAILURE : EXIT_SUCCESS;
  kktnetd_api_stop(ctx.get());

  return ret_val;
}
int main(int argc, char* argv[])
{
  try
  {
    return emain(argc, argv);
  }
  catch (const std::exception& e)
  {
    std::cerr << e.what() << '\n';
  }
  catch (...)
  {
    std::cerr << "unknown error" << '\n';
  }
}
