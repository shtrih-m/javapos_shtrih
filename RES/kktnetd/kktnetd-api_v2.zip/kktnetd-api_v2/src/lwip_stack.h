#ifndef KKTNETWORKDAEMON_H
#define KKTNETWORKDAEMON_H

#include <kktnet_common.h>

KKTNETD_NAMESPACE_BEGIN

class lwip_stack
{
  public:
  /**
   * @brief exec mainloop
   */
  static void run();
};
KKTNETD_NAMESPACE_END
#endif // KKTNETWORKDAEMON_H
