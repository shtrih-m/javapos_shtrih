#include "socks5app.h"
#include "impl/resender_impl.h"
#include <IO/lwipsocketio.h>
#include <IO/systemtcpsocketio.h>
#include <algorithm>
#include <asio/connect.hpp>
#include <numeric>
#include <optional>
#include <utils/asio_async_poster_factory.h>

KKTNETD_NAMESPACE_BEGIN
namespace apps
{
namespace
{

static constexpr const uint8_t SOCKS_VERSION = 5;

enum SocksState
{
  SS_Initial,
  SS_ConnectedToProxy,
  SS_VersionIdentifierSent,
};
enum Socks5Auth
{
  /**
 o  X'00' NO AUTHENTICATION REQUIRED
 o  X'01' GSSAPI
 o  X'02' USERNAME/PASSWORD
 o  X'03' to X'7F' IANA ASSIGNED
 o  X'80' to X'FE' RESERVED FOR PRIVATE METHODS
 o  X'FF' NO ACCEPTABLE METHODS
 */
  S5A_NoAuth = 0,
  S5A_GSSAPI = 1,
  S5A_UsernamePassword = 2,
  S5A_Invalid = 0xFF,
};
enum Socks5Commands
{
  /**
 o  CONNECT X'01'
 o  BIND X'02'
 o  UDP ASSOCIATE X'03'
 */
  S5C_Connect = 1,
  S5C_Bind = 2,
  S5C_UDP_Associate = 3,
};
enum Socks5AddressType
{
  /**
 o  IP V4 address: X'01'
 o  DOMAINNAME: X'03'
 o  IP V6 address: X'04'
 */
  S5AT_IPV4 = 1,
  S5AT_DOMAINNAME = 3,
  S5AT_IPV6 = 4,
};

struct socks_handshaker : public std::enable_shared_from_this<socks_handshaker>
{
  net::io_context& ctx_;
  std::unique_ptr<lwip_socket_io> lwip_socket_;
  std::optional<net::ip::tcp::resolver> tcp_respolver_;
  std::optional<net::ip::tcp::socket> net_socket_;

  enum class state
  {
    greeting,
    auth,
    connection_request,
    getting_host_port,
    making_remote_connection,
    done
  };

  state state_ = state::greeting;
  std::array<uint8_t, 256 + 32> buf;
  size_t offset_ = 0;
  std::shared_ptr<spdlog::logger> logger_;

  uint8_t auth_methods_num;
  std::string hostname_;

  public:
  explicit socks_handshaker(net::io_context& ctx, std::unique_ptr<lwip_socket_io> socket)
      : ctx_(ctx)
      , lwip_socket_(std::move(socket))
      , logger_(LOGGER_FOR_CLASSNAME(socks_handshaker))
  {
    //    log_set_level(logger_, spdlog::level::trace);
  }
  void on_write(std::error_code ec, std::size_t bytes)
  {
    log_trace(logger_, fmt::format("{}: {}: {} , state: {}, bytes: {}", __func__, ec.value(), ec.message(), int(state_), bytes));

    if (ec)
    {
      log_error(logger_, fmt::format("{}:{} stopping", __func__, ec.message()));
      return;
    }
    offset_ += bytes;
    if (offset_ < to_write_for_state())
    {
      // TODO: continue write
      return;
    }
    switch (state_)
    {
    case state::auth:
    {
      offset_ = 0;
      state_ = state::connection_request;

      do_read();
      return;
    }
    case state::making_remote_connection:
    {
      state_ = state::done;
      std::make_shared<resender_session>(std::move(*net_socket_), std::move(lwip_socket_))->run();
      return;
    }
    default:
      assert(false);
    }
  }
  void on_system_connect(const std::error_code& ec)
  {
    if (ec)
    {
      log_error(logger_, fmt::format("{}: {}", __func__, ec.message()));
      return;
    }
    //    string hostname(reinterpret_cast<const char*>(buf.data()), hostname_len);
    buf[0] = SOCKS_VERSION;
    buf[1] = 0; // OK
    buf[2] = 0; // must be 0
    buf[3] = S5AT_DOMAINNAME;
    buf[4] = hostname_.size();
    memcpy(&buf[5], hostname_.data(), hostname_.size());
    lwip_socket_->async_write_some(net::buffer(buf.data(), 5 + hostname_.size()), std::bind(&socks_handshaker::on_write, shared_from_this(), std::placeholders::_1, std::placeholders::_2));
  }
  void on_system_resolve(const std::error_code& ec, const net::ip::tcp::resolver::results_type& endpoints)
  {
    if (!ec)
    {
      tcp_respolver_.reset();
      auto col_appender = [](std::string a, net::ip::tcp::resolver::results_type::value_type b) { return std::move(a) + ',' + b.endpoint().address().to_string(); };
      auto str = std::accumulate(std::next(endpoints.begin()), endpoints.end(), endpoints.begin()->host_name(), col_appender);
      log_info(logger_, fmt::format("{}: endpoints: {}", __func__, str));
      net::async_connect(*net_socket_, endpoints, std::bind(&socks_handshaker::on_system_connect, shared_from_this(), std::placeholders::_1));
    }
    else
    {
      log_error(logger_, fmt::format("{}: {}", __func__, ec.message()));
    }
  }
  void on_read(std::error_code ec, std::size_t bytes)
  {
    log_trace(logger_, fmt::format("{}: {}: {} , state: {}, bytes: {}", __func__, ec.value(), ec.message(), int(state_), bytes));
    if (ec == std::errc::operation_would_block || ec == std::errc::operation_in_progress || ec == std::errc::connection_already_in_progress)
    {
      do_read();
      return;
    }
    else if (ec)
    {
      log_error(logger_, fmt::format("{}:{} stopping", __func__, ec.message()));
      return;
    }
    offset_ += bytes;
    if (offset_ < to_read_for_state())
    {
      do_read();
      return;
    }
    switch (state_)
    {
    case state::greeting:
    {
      if (buf[0] != 5)
      {
        log_error(logger_, fmt::format("{}: invalid socks5 header", __func__));
        return;
      }
      auth_methods_num = buf[1];
      state_ = state::auth;
      offset_ = 0;
      do_read();
      return;
    }
    case state::auth:
    {
      Socks5Auth chosenAuth = S5A_Invalid;
      for (size_t i = 0; i < auth_methods_num; i++)
      {
        if (buf[i] == S5A_NoAuth)
        {
          chosenAuth = S5A_NoAuth;
          break;
        }
        else if (buf[i] == S5A_UsernamePassword)
        {
          chosenAuth = S5A_UsernamePassword;
        }
      }
      buf[0] = SOCKS_VERSION;
      buf[1] = chosenAuth;
      lwip_socket_->async_write_some(net::buffer(buf.data(), 2), std::bind(&socks_handshaker::on_write, shared_from_this(), std::placeholders::_1, std::placeholders::_2));

      return;
    }
    case state::connection_request:
    {
      if (buf[0] != SOCKS_VERSION)
      {
        // must be 5
        log_error(logger_, fmt::format("{}: invalid socks5 header", __func__));
        return;
      }
      if (buf[1] != S5C_Connect)
      {
        log_error(logger_, fmt::format("{}: for now suuport only connect method supported", __func__));
        return; // for now suuport only connect method
      }
      if (buf[2])
      {
        log_error(logger_, fmt::format("{}: invalid socks5 header", __func__));

        return;
      }
      if (buf[3] != S5AT_DOMAINNAME)
      {
        // only domainname supported
        log_error(logger_, fmt::format("{}: only domainname supported", __func__));
        return;
      }
      hostname_ = std::string(std::string::size_type(buf[4]), ' ');
      offset_ = 0;
      state_ = state::getting_host_port;
      do_read();
      return;
    }
    case state::getting_host_port:
    {
      uint16_t port;
      memcpy(&port, &buf[hostname_.size()], 2);
      port = ntohs(port);
      //      buf[hostname_len] = 0;
      //      std::string_view remote_hostname { reinterpret_cast<const char*>(buf.data()), hostname_len };
      memcpy(hostname_.data(), buf.data(), hostname_.size());
      log_info(logger_, fmt::format("{}: client requests connect to {}:{}", __func__, hostname_, port));
      tcp_respolver_ = net::ip::tcp::resolver(ctx_);
      net_socket_ = net::ip::tcp::socket(net::make_strand(ctx_));
      tcp_respolver_->async_resolve(hostname_, std::to_string(port), std::bind(&socks_handshaker::on_system_resolve, shared_from_this(), std::placeholders::_1, std::placeholders::_2));

      offset_ = 0;
      state_ = state::making_remote_connection;
      return;
    }
    default:
      assert(false);
    }
  }
  std::size_t to_write_for_state()
  {
    switch (state_)
    {
    case state::auth:
      return 2;
    case state::making_remote_connection:
      return 5;
    default:
      assert(false);
      return 0;
    }
    return 0;
  }
  std::size_t to_read_for_state()
  {
    switch (state_)
    {
    case state::greeting:
      return 2;
    case state::auth:
      return auth_methods_num;
    case state::connection_request:
      return 5;
    case state::getting_host_port:
      return hostname_.size() + 2;
    default:
      assert(false);
    };
    return 0;
  }
  void do_read()
  {
    std::size_t to_get = to_read_for_state();
    log_trace(logger_, fmt::format("{}: state: {}, to_get: {}", __func__, int(state_), to_get));

    lwip_socket_->async_read_some(net::buffer(buf.data() + offset_, to_get - offset_), std::bind(&socks_handshaker::on_read, shared_from_this(), std::placeholders::_1, std::placeholders::_2));
  }
  void run() { do_read(); }
};

struct socks5_server : public std::enable_shared_from_this<socks5_server>
{
  net::io_context& ctx_;
  lwip_socket_io lwip_socket_io_;
  logger logger_ = LOGGER_FOR_CLASSNAME(socks5_server);

  explicit socks5_server(net::io_context& ctx, std::string_view ip, uint16_t port)
      : ctx_(ctx)
      , lwip_socket_io_(std::make_shared<asio_async_poster_factory>(ctx_), ip.data(), port)
  {
  }
  void on_accepted(std::error_code ec, std::unique_ptr<lwip_socket_io> socket)
  {
    if (ec == std::errc::operation_would_block || ec == std::errc::operation_in_progress || ec == std::errc::connection_already_in_progress || ec == std::errc::not_connected)
    {
      do_async_accept();
      return;
    }
    else if (ec)
    {
      log_error(logger_, fmt::format("{}: {}: {} looking for next", __func__, ec.value(), ec.message()));
      do_async_accept();
      return;
    }

    auto s = std::move(socket);
    log_info(logger_, fmt::format("accepted: {}:{}", ec.message(), (void*)s.get()));
    std::make_shared<socks_handshaker>(ctx_, std::move(s))->run();
    do_async_accept();
  }
  void do_async_accept() { lwip_socket_io_.async_accept(std::bind(&socks5_server::on_accepted, this, std::placeholders::_1, std::placeholders::_2)); }
  void run()
  {
    log_debug(logger_, fmt::format("{}", __func__));

    if (lwip_socket_io_.do_listen())
    {
      do_async_accept();
    }
  }
  void stop()
  {
    log_debug(logger_, fmt::format("{}", __func__));
    lwip_socket_io_.close();
  }
};

} // namespace

socks5_app::socks5_app(net::io_context& ctx, std::string_view our_ip, uint16_t our_port)
    : base_app(ctx)
    , worker_(std::make_shared<socks5_server>(ctx, our_ip, our_port))
{
}

void socks5_app::stop() { std::static_pointer_cast<socks5_server>(worker_)->stop(); }
void socks5_app::run() { std::static_pointer_cast<socks5_server>(worker_)->run(); }
socks5_app::~socks5_app() { stop(); }
} // namespace apps
KKTNETD_NAMESPACE_END
