#ifndef SOCKS5_APP_H
#define SOCKS5_APP_H

#include "baselwipapp.h"

KKTNETD_NAMESPACE_BEGIN
namespace apps
{
class socks5_app : public base_app
{
  std::shared_ptr<void> worker_;

  public:
  explicit socks5_app(net::io_context& ctx, std::string_view our_ip, uint16_t our_port = 1080);
  ~socks5_app();

  public:
  void run() override;
  void stop() override;
};

} // namespace apps
KKTNETD_NAMESPACE_END

#endif // SOCKS5_APP_H
