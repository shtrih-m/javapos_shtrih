#include "pingapp.h"

#include "impl/pingapp_impl.h"
#include <asio/post.hpp>
#include <asio/steady_timer.hpp>
#include <random>
#include <spdlog/fmt/bundled/chrono.h>
#include <thread>

KKTNETD_NAMESPACE_BEGIN

namespace apps
{
namespace
{
static uint16_t make_random_id()
{
  static std::random_device rd; // Will be used to obtain a seed for the random number engine
  static std::mt19937 gen(rd()); // Standard mersenne_twister_engine seeded with rd()
  static std::uniform_int_distribution<uint16_t> distrib;
  return distrib(gen);
}
class socks5_server : public std::enable_shared_from_this<socks5_server>
{

  pingapp_impl impl_ = pingapp_impl { make_random_id(), 0 };
  std::shared_ptr<spdlog::logger> logger = LOGGER_FOR_CLASSNAME(ping_app);
  uint32_t seqnum = 1;
  net::io_context& ctx_;
  std::string host_;
  net::steady_timer timer;
  std::shared_ptr<pingapp_impl::ping_ctx> ping_ctx;
  bool need_stop;

  void on_error(const std::error_code& ec) { }
  void do_recv()
  {
    if (need_stop)
    {
      return;
    }
    std::error_code ec;
    impl_.recv(*ping_ctx, ec);
    if (ec == net::error::would_block)
    {
      if (std::chrono::steady_clock::now() - ping_ctx->sent_time > std::chrono::seconds(1))
      {
        log_info(logger, fmt::format("no answer in 1000 ms"));

        reschedule_run();
        return;
      }
      schedule_recv();
      return;
    }
    else if (ec)
    {
      on_error(ec);
      return;
    }
    // GOOD
    log_info(logger, fmt::format("32 bytes from {}: icmp_seq={} ttl=256 time={} ms", host_, seqnum + 1, ping_ctx->diff_time));
    reschedule_run();
  }
  void schedule_recv()
  {
    if (need_stop)
    {
      return;
    }
    timer.expires_from_now(std::chrono::milliseconds(1));
    timer.async_wait([self = shared_from_this()](const std::error_code& ec) { self->do_recv(); });
  }
  void do_send(std::string_view host)
  {
    if (need_stop)
    {
      return;
    }
    std::error_code ec;
    ping_ctx = impl_.send(host, ec);
    if (ec)
    {
      on_error(ec);
      return;
    }
    schedule_recv();
  }
  void reschedule_run()
  {
    if (need_stop)
    {
      return;
    }
    seqnum += 1;
    impl_ = pingapp_impl { make_random_id(), seqnum };
    ping_ctx = {};
    timer.expires_from_now(std::chrono::seconds(1));
    timer.async_wait([self = shared_from_this()](const std::error_code& ec) { self->run(); });
  }

  public:
  void run()
  {
    need_stop = false;
    do_send(host_);
  }
  void stop() { need_stop = true; }
  socks5_server(net::io_context& ctx, std::string_view host)
      : ctx_(ctx)
      , host_(host)
      , timer(ctx_)
      , need_stop(false)
  {
  }
};

} // namespace

ping_app::ping_app(net::io_context& ctx, std::string_view host)
    : base_app(ctx)
    , host_(host)
{
  worker_ = std::make_shared<socks5_server>(ctx_, host_);
}

void ping_app::run() { std::static_pointer_cast<socks5_server>(worker_)->run(); }
void ping_app::stop() { std::static_pointer_cast<socks5_server>(worker_)->stop(); }

} // namespace apps
KKTNETD_NAMESPACE_END
