#ifndef KKTNETD_PINGAPP_IMPL_H
#define KKTNETD_PINGAPP_IMPL_H
#include <kktnet_common.h>
#include <utils/log.h>

KKTNETD_NAMESPACE_BEGIN
namespace apps
{
struct pppos_if;
struct pingapp_impl
{
  public:
  struct ping_ctx
  {
    decltype(std::chrono::steady_clock::now()) sent_time;
    std::chrono::duration<double, std::milli> diff_time;
    int fd = -1;
    ~ping_ctx();
  };
  std::shared_ptr<pingapp_impl::ping_ctx> send(std::string_view host, std::error_code& ec);
  void recv(ping_ctx& ctx, std::error_code& ec);
  explicit pingapp_impl(uint16_t ping_id = 0xafaf, uint32_t seqnum = 0);
  ~pingapp_impl();

  private:
  std::shared_ptr<spdlog::logger> logger_ = LOGGER_FOR_CLASSNAME(pingapp_impl);
  uint16_t id_;
  uint32_t seqnum_;
};
} // namespace apps
KKTNETD_NAMESPACE_END
#endif // KKTNETD_PINGAPP_IMPL_H
