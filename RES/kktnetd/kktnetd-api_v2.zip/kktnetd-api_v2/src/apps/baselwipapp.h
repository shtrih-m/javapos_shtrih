#ifndef BASELWIPAPP_H
#define BASELWIPAPP_H

#include <asio/io_context.hpp>
#include <kktnet_common.h>

KKTNETD_NAMESPACE_BEGIN

namespace apps
{

class base_app
{

  protected:
  net::io_context& ctx_;

  public:
  explicit base_app(net::io_context& ctx);
  virtual ~base_app();

  virtual void run() = 0;
  virtual void stop() = 0;
};
} // namespace apps
KKTNETD_NAMESPACE_END
#endif // BASELWIPAPP_H
