//
// Created by swex on 8/24/21.
//

#ifndef KKTNETD_API_H
#define KKTNETD_API_H
#include <kktnet_common.h>

// Generic helper definitions for shared library support
#if defined _WIN32 || defined __CYGWIN__
#  define KKTNETD_LIB_HELPER_DLL_IMPORT __declspec(dllimport)
#  define KKTNETD_LIB_HELPER_DLL_EXPORT __declspec(dllexport)
#  define KKTNETD_LIB_HELPER_DLL_LOCAL
#else
#  if __GNUC__ >= 4
#    define KKTNETD_LIB_HELPER_DLL_IMPORT __attribute__((visibility("default")))
#    define KKTNETD_LIB_HELPER_DLL_EXPORT __attribute__((visibility("default")))
#    define KKTNETD_LIB_HELPER_DLL_LOCAL __attribute__((visibility("hidden")))
#  else
#    define KKTNETD_LIB_HELPER_DLL_IMPORT
#    define KKTNETD_LIB_HELPER_DLL_EXPORT
#    define KKTNETD_LIB_HELPER_DLL_LOCAL
#  endif
#endif

// Now we use the generic helper definitions above to define KKTNETD_LIB_API and
// KKTNETD_LIB_LOCAL. KKTNETD_LIB_API is used for the public API symbols. It either DLL
// imports or DLL exports (or does nothing for static build) KKTNETD_LIB_LOCAL is used for
// non-api symbols.

#ifdef KKTNETD_LIB_DLL // defined if KKTNETD_LIB is compiled as a DLL
#  ifdef KKTNETD_LIB_DLL_EXPORTS // defined if we are building the KKTNETD_LIB DLL (instead of using it)
#    define KKTNETD_LIB_API KKTNETD_LIB_HELPER_DLL_EXPORT
#  else
#    define KKTNETD_LIB_API KKTNETD_LIB_HELPER_DLL_IMPORT
#  endif // KKTNETD_LIB_DLL_EXPORTS
#  define KKTNETD_LIB_LOCAL KKTNETD_LIB_HELPER_DLL_LOCAL
#else // KKTNETD_LIB_DLL is not defined: this means KKTNETD_LIB is a static lib.
#  define KKTNETD_LIB_API
#  define KKTNETD_LIB_LOCAL
#endif // KKTNETD_LIB_DLL

#ifdef __cplusplus
extern "C"
{
#endif
  enum kktnetd_app_flags
  {
    watch_signals = 1,
    use_serial = 2,
  };
  KKTNETD_LIB_API size_t kktnetd_run_app(const char* name, size_t size, uint32_t flags);
  KKTNETD_LIB_API void kktnetd_stop_app();

  struct kktnetd_api_context;
  typedef struct kktnetd_api_context kktnetd_api_context_t;

  /**
   * @brief kktnetd_api_init
   * @param instance_config if NULL - default used
   * @return new context or NULL if error
   */
  KKTNETD_LIB_API kktnetd_api_context_t* kktnetd_api_init(const char* instance_config);

  KKTNETD_LIB_API void kktnetd_api_deinit(kktnetd_api_context_t* ctx);

  KKTNETD_LIB_API size_t kktnetd_api_run(kktnetd_api_context_t* ctx);
  enum kktnetd_error_codes
  {
    kktnetd_ok = 0,
    kktnetd_failure = 1,
  };

  KKTNETD_LIB_API int kktnetd_api_status(kktnetd_api_context_t* ctx, char* out, size_t out_size);

  KKTNETD_LIB_API void kktnetd_api_stop(kktnetd_api_context_t* ctx);

#ifdef __cplusplus
}
#endif

#endif // KKTNETD_API_H
