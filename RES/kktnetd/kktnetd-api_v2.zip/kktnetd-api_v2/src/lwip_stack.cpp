#include "lwip_stack.h"
#include <impl/lwip_stack_impl.h>
#include <spdlog/logger.h>
#include <utils/log.h>

KKTNETD_NAMESPACE_BEGIN

void lwip_stack::run() { lwip_stack_impl::init(); }

KKTNETD_NAMESPACE_END
