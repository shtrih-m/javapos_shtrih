#ifndef KKTNET_COMMON_H
#define KKTNET_COMMON_H

#include <array>
#include <string>

// namespace definitions
#define __KKTNETD_NAMESPACE__ kktnetd
#define KKTNETD_NAMESPACE_BEGIN                                                                                                                                                                        \
  namespace __KKTNETD_NAMESPACE__                                                                                                                                                                      \
  {
#define KKTNETD_NAMESPACE_END } // namespace kktnetd
namespace asio
{
}
KKTNETD_NAMESPACE_BEGIN

using u8string = std::string;
using string_view = std::string_view;
using string = std::string;

template <class T, std::size_t N> using array = std::array<T, N>;

namespace net = asio;

KKTNETD_NAMESPACE_END

#endif // KKTNET_COMMON_H
