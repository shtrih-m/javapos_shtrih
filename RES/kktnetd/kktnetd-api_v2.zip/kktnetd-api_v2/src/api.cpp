#include "api.h"
#include <apps/pingapp.h>
#include <apps/resender_app.h>
#include <apps/socks5app.h>
#include <asio/ip/tcp.hpp>
#include <asio/local/stream_protocol.hpp>
#include <asio/read.hpp>
#include <asio/serial_port.hpp>
#include <asio/signal_set.hpp>
#include <asio/strand.hpp>
#include <asio/write.hpp>
#include <boost/json.hpp>
#include <lwip_stack.h>
#include <mutex>
#include <optional>
#include <pppos_netif.h>
#include <queue>
#include <spdlog/logger.h>
#include <utils/async_poster.h>
#include <utils/log.h>

#include <jni/ru_shtrih_m_kktnetd_Api.h>

namespace json = boost::json;

#ifdef _WIN32
#  include <signal.h>
//#include <winbase.h>
#endif

namespace
{
__KKTNETD_NAMESPACE__::logger getLWIPLog()
{
  static auto logger = __KKTNETD_NAMESPACE__::getLog("LWIP");
  logger->set_level(spdlog::level::trace);
  return logger;
}
__KKTNETD_NAMESPACE__::logger getMainLogger()
{
  static auto logger = __KKTNETD_NAMESPACE__::getLog("MAIN");
  logger->set_level(spdlog::level::trace);
  return logger;
}

} // namespace
#ifdef __cplusplus
extern "C"
{
#endif

  void spdlogWrapper(const char* fmt, ...)
  {
    static auto logger = getLWIPLog();

    std::array<char, 1024> buf;
    va_list myargs;

    /* Initialise the va_list variable with the ... after fmt */

    va_start(myargs, fmt);

    /* Forward the '...' to vprintf */
    auto ret = vsnprintf(buf.data(), buf.size(), fmt, myargs);
    /* Clean up the va_list */
    va_end(myargs);
    if (buf[ret - 1] == '\n')
    {
      buf[ret - 1] = 0; // cut \n
    }
    logger->debug(buf.data());
  }

#ifdef __cplusplus
}
#endif

KKTNETD_NAMESPACE_BEGIN
static void handle_signal(int signal)
{
  const char* signal_name;

  // Find out which signal we're handling
  switch (signal)
  {
#ifndef _WIN32
  case SIGHUP:
    signal_name = "SIGHUP";
    break;
  case SIGUSR1:
    signal_name = "SIGUSR1";
    break;
#endif // ifndef _WIN32
  case SIGINT:
    printf("Caught SIGINT, exiting now\n");
    exit(0);
    break;
  case SIGTERM:
    printf("Caught SIGTERM stopping daemon\n");
    exit(0);
    break;
  default:
    fprintf(stderr, "Caught wrong signal: %d\n", signal);
    return;
  }
}
static void signal_handler(const net::error_code& ec, int signum)
{
  if (ec)
  {
    perror(ec.message().c_str());
    return;
  }
  handle_signal(signum);
}

class runnable
{
  public:
  virtual ~runnable() = default;
  virtual void run() = 0;
};

template <class AsyncStream> class port_reader : public runnable
{
  net::io_context& ctx_;
  AsyncStream stream_;
  pppos_if& ppp_;
  std::array<uint8_t, 1024> input_buf_;
  std::function<void(const net::error_code&)> on_error_;
  std::shared_ptr<spdlog::logger> logger_ = LOGGER_FOR_CLASSNAME(port_reader);
  std::queue<std::shared_ptr<std::vector<uint8_t>>> write_queue_;
  std::mutex write_queue_mutex_;
  void on_error(const net::error_code& ec, std::string_view op)
  {
    logger_->error("{}: {}", op, ec.message());

    if (on_error_)
    {
      on_error_(ec);
      return;
    }
  }
  void on_write(const net::error_code& ec, std::size_t bytes_transferred)
  {
    logger_->trace("{}: ec={}, bt={}", __func__, ec.message(), bytes_transferred);
    auto lock = std::lock_guard(write_queue_mutex_);
    write_queue_.pop();

    if (ec)
    {
      on_error(ec, __func__);
      return;
    }
    if (!write_queue_.empty())
    {
      initiate_write();
    }
  }
  void on_read(const net::error_code& ec, std::size_t bytes_transferred)
  {
    logger_->trace("{}: ec={}, bt={}", __func__, ec.message(), bytes_transferred);
    if (ec)
    {
      on_error(ec, __func__);
      return;
    }
    ppp_.input(net::buffer(input_buf_.data(), bytes_transferred));
    do_read();
  }
  void do_read() { net::async_read(stream_, net::buffer(input_buf_), net::transfer_at_least(1), std::bind(&port_reader::on_read, this, std::placeholders::_1, std::placeholders::_2)); }
  void queue_write(net::const_buffer buf)
  {
    auto lock = std::lock_guard(write_queue_mutex_);
    auto do_need_initiate_write = write_queue_.empty();
    auto begin = reinterpret_cast<const char*>(buf.data());
    write_queue_.emplace(std::make_shared<std::vector<uint8_t>>(begin, begin + buf.size()));
    if (do_need_initiate_write)
    {
      initiate_write();
    }
  }
  void initiate_write()
  {
    // assume write_queue_mutex_ locked somewhere above
    auto copy = write_queue_.front();

    net::async_write(stream_, net::buffer(copy->data(), copy->size()), [copy, this](const net::error_code& ec, std::size_t bytes_transferred) { on_write(ec, bytes_transferred); });
  }

  public:
  ~port_reader()
  {
    ppp_.output_cb([](net::const_buffer buf) -> uint32_t { return 0; });
  }
  port_reader(net::io_context& ctx, AsyncStream&& stream, pppos_if& ppp, std::function<void(const net::error_code&)> on_error)
      : ctx_(ctx)
      , stream_(std::move(stream))
      , ppp_(ppp)
      , on_error_(on_error)
  {
    ppp_.output_cb(
        [this](net::const_buffer buf) -> uint32_t
        {
          queue_write(buf);
          //          do_write(buf);
          return buf.size();
        });
  }
  void run() override { do_read(); }
};

namespace
{
template <class T> T make_proto_endpoint(std::string_view path);
template <> net::local::stream_protocol::endpoint make_proto_endpoint(std::string_view path)
{
  ::unlink(path.data()); // silently ignore result
  return { path };
}
template <> net::ip::tcp::endpoint make_proto_endpoint(std::string_view path) { return net::ip::tcp::endpoint(net::ip::make_address_v4("127.0.0.1"), std::stoul(path.data())); }
std::string endpoint_name(const net::local::stream_protocol::endpoint& endpoint) { return endpoint.path(); }
std::string endpoint_name(const net::ip::tcp::endpoint& endpoint) { return endpoint.address().to_string() + std::to_string(+endpoint.port()); }
} // namespace

template <class Protocol> class local_api_server : public runnable
{
  using Acceptor = net::basic_socket_acceptor<Protocol>;
  using Stream = typename net::basic_stream_socket<Protocol>;
  net::io_context& ctx_;
  pppos_if& pppos_if_;
  Acceptor acceptor_;
  logger logger_ = LOGGER_FOR_CLASSNAME(local_api_server);
  std::unique_ptr<port_reader<Stream>> stream_;

  private:
  void on_client_dead(const net::error_code& ec)
  {
    logger_->info("client dropped: {}, continue accepting", ec.message());
    do_accept();
  }
  void on_accept(net::error_code ec, Stream socket)
  {
    if (ec)
    {
      logger_->error("{}: {}", __func__, ec.message());
      do_accept();
      return;
    }
    {
      net::error_code l_ec;
      auto ep = socket.remote_endpoint(l_ec);
      std::string ep_name;
      if (l_ec)
      {
        ep_name = "unknown";
      }
      else
      {
        ep_name = endpoint_name(ep);
      }
      logger_->info("client arrived: {}, start accepting", ep_name);
    }
    stream_ = std::make_unique<port_reader<Stream>>(ctx_, std::move(socket), pppos_if_, std::bind(&local_api_server::on_client_dead, this, std::placeholders::_1));
    stream_->run();
  }
  void do_accept() { acceptor_.async_accept(std::bind(&local_api_server::on_accept, this, std::placeholders::_1, std::placeholders::_2)); }

  public:
  local_api_server(net::io_context& ctx, pppos_if& pppos_if, std::string_view path)
      : ctx_(ctx)
      , pppos_if_(pppos_if)
      , acceptor_(ctx_, make_proto_endpoint<typename Protocol::endpoint>(path))

  {
  }
  void run() override { do_accept(); }
};

struct application
{
  static inline const json::value DEFAULT_CONFIG = json::parse(R"__(
{
  "handle_signals": false,
  "resender": {
    "host": "localhost",
    "port": 7778,
    "remote_port": 7778,
    "socks_port": 1080
  },
  "transport": {
    "type": "serial",
    "path": "/dev/ttyUSB0"
  },
  "ppp": {
    "our_ip": "192.168.1.169",
    "peer_ip": "192.168.1.168",
    "peer_dns": "8.8.8.8"
  }
}
)__");

  struct config
  {

private:
    bool handle_signals_;
    bool use_plain_serial_;

    std::string transport_path_;
    std::string resender_host_;
    uint16_t resender_port_;
    uint16_t remote_port_;
    uint16_t socks_port_;
    std::string our_ip_;
    std::string peer_ip_;
    std::string peer_dns_;

public:
    bool handle_signals() const { return handle_signals_; }
    bool use_plain_serial() const { return use_plain_serial_; }
    std::string_view transport_path() const { return transport_path_; }
    std::string_view resender_host() const { return resender_host_; }
    uint16_t resender_port() const { return resender_port_; }
    uint16_t remote_port() const { return remote_port_; }
    uint16_t socks_port() const { return socks_port_; }
    std::string_view our_ip() const { return our_ip_; }
    std::string_view peer_ip() const { return peer_ip_; }
    std::string_view peer_dns() const { return peer_dns_; }

public:
    config(const json::value& cfg)
    {
      const auto& cfg_o = cfg.as_object();
      const auto& default_cfg_o = DEFAULT_CONFIG.as_object();
      auto check_port_valid = [](auto&& port)
      {
        if (port >= 1 && port <= 65535)
        {
          return;
        }
        throw std::runtime_error(fmt::format("invalid port: {}", port));
      };
      auto value_or_default = [](const auto& object, const auto& default_object, auto&& key)
      {
        const auto val = object.if_contains(key);
        if (val)
        {
          return *val;
        }
        return *default_object.if_contains(key);
      };
      handle_signals_ = value_or_default(cfg_o, default_cfg_o, "handle_signals").as_bool();
      {
        auto transport_o = value_or_default(cfg_o, default_cfg_o, "transport").as_object();
        auto default_transport_o = default_cfg_o.if_contains("transport")->as_object();
        use_plain_serial_ = value_or_default(transport_o, default_transport_o, "type").as_string() == "serial";
        transport_path_ = value_or_default(transport_o, default_transport_o, "path").as_string();
      }
      {
        auto resender_o = value_or_default(cfg_o, default_cfg_o, "resender").as_object();
        auto default_resender_o = default_cfg_o.if_contains("resender")->as_object();
        resender_host_ = value_or_default(resender_o, default_resender_o, "host").as_string();
        resender_port_ = value_or_default(resender_o, default_resender_o, "port").as_int64();
        check_port_valid(resender_port_);
        remote_port_ = value_or_default(resender_o, default_resender_o, "remote_port").as_int64();
        check_port_valid(remote_port_);
        socks_port_ = value_or_default(resender_o, default_resender_o, "socks_port").as_int64();
        check_port_valid(socks_port_);
      }
      {
        auto ppp_o = value_or_default(cfg_o, default_cfg_o, "ppp").as_object();
        auto default_ppp_o = default_cfg_o.if_contains("ppp")->as_object();
        our_ip_ = value_or_default(ppp_o, default_ppp_o, "our_ip").as_string();
        asio::ip::make_address_v4(our_ip_);
        peer_ip_ = value_or_default(ppp_o, default_ppp_o, "peer_ip").as_string();
        asio::ip::make_address_v4(peer_ip_);
        peer_dns_ = value_or_default(ppp_o, default_ppp_o, "peer_dns").as_string();
        asio::ip::make_address_v4(peer_dns_);
      }
    }
  } config_;

  private:
  logger logger_ = LOGGER_FOR_CLASSNAME(application);
  net::io_context ctx;
  std::vector<std::shared_ptr<apps::base_app>> apps_;

  constexpr static auto ERROR_RETURN_CONSTANT = std::numeric_limits<std::size_t>::max();
  constexpr static auto OK_RETURN_CONSTANT = std::numeric_limits<std::size_t>::min();
  void start_apps()
  {
    {
      net::post(
          ctx,
          [this]()
          {
            for (auto& app : apps_)
            {
              app->run();
            }
          });
    }
  }
  void stop_apps()
  {
    net::post(
        ctx,
        [this]()
        {
          for (auto& app : apps_)
          {
            app->stop();
          }
        });
  }
  pppos_if const* running_if_ = nullptr;

  public:
  application(json::value config)
      : config_(config)
  {
  }
  void stop()
  {
    logger_->info("{}", __func__);
    if (ctx.stopped())
    {
      return;
    }
    ctx.post(
        [this]()
        {
          ctx.stop();
          stop_apps();
          apps_.clear();
        });
  }
  /**
   * @brief я есть главная функция
   * @param api_endpoint_path, путь на ФС или абстрактный путь, socat вот так: socat -d -d -d -d /dev/ttyUSB0,rawer,b115200 ABSTRACT-CLIENT:kktnetd
   * @param args
   * @return ошибка std::size_t max или возврат от io_context.run()
   */
  std::size_t run()
  {
    struct pointer_setter
    {
      application* thiz_;

      pointer_setter(application* thiz, const pppos_if* ptr)
          : thiz_(thiz)
      {
        thiz_->running_if_ = ptr;
      }
      ~pointer_setter() { thiz_->running_if_ = nullptr; }
    };
    auto abstract_namespace = config_.transport_path()[0] == 0;
    logger_->info(
        "{}(path={}, anon={}, handle_signals={}, use_plain={})", __func__, config_.transport_path().data() + (abstract_namespace ? 1 : 0), abstract_namespace, config_.handle_signals(),
        config_.use_plain_serial());
    logger_->flush();

    if (ctx.stopped())
    {

      ctx.restart();
    }

    net::error_code ec;

    if (config_.handle_signals())
    {
      net::signal_set signal_set(ctx);

#ifndef _WIN32
      // Intercept SIGHUP and SIGINT
      signal_set.add(SIGHUP, ec);
      if (ec)
      {
        logger_->error("cannot handle SIGHUP"); // Should not happen
      }
      signal_set.add(SIGUSR1, ec);
      if (ec)
      {
        logger_->error("cannot handle SIGUSR1"); // Should not happen
      }
#endif //#ifndef _WIN32
      signal_set.add(SIGINT, ec);
      if (ec)
      {
        logger_->error("cannot handle SIGINT"); // Will always happen
      }
      signal_set.add(SIGTERM, ec);
      if (ec)
      {
        logger_->error("cannot handle SIGTERM"); // Should not happen
      }
      signal_set.async_wait(signal_handler);
    }
    try
    {

      pppos_if ppp { pppos_if::Mode::Server, config_.our_ip(), config_.peer_ip(), config_.peer_dns() };

      std::unique_ptr<runnable> server;
#ifdef _WIN32
      std::unique_ptr<runnable> wdog;
#endif
      if (config_.use_plain_serial())
      {

        net::serial_port serial_port(net::make_strand(ctx));
        {
          std::error_code ec;
          serial_port.open(config_.transport_path().data(), ec);
          if (ec)
          {
            logger_->error("serial port open failed: {} , stopping ...", ec.message());
            stop();
            return ERROR_RETURN_CONSTANT;
          }

          serial_port.set_option(net::serial_port::baud_rate(115200), ec);
          if (ec)
          {
            logger_->error("serial port set baud_rate failed: {} , stopping ...", ec.message());
            stop();
            return ERROR_RETURN_CONSTANT;
          }
          serial_port.set_option(net::serial_port::parity(net::serial_port::parity::none), ec);
          if (ec)
          {
            logger_->error("serial port set parity failed: {} , stopping ...", ec.message());
            stop();
            return ERROR_RETURN_CONSTANT;
          }
          serial_port.set_option(net::serial_port::stop_bits(net::serial_port::stop_bits::one), ec);
          if (ec)
          {
            logger_->error("serial port set stop_bits failed: {} , stopping ...", ec.message());
            stop();
            return ERROR_RETURN_CONSTANT;
          }
          serial_port.set_option(net::serial_port::flow_control(net::serial_port::flow_control::none), ec);
          if (ec)
          {
            logger_->error("serial port set flow_control failed: {} , stopping ...", ec.message());
            stop();
            return ERROR_RETURN_CONSTANT;
          }
          serial_port.set_option(net::serial_port::character_size(8));
          if (ec)
          {
            logger_->error("serial port set character_size failed: {} , stopping ...", ec.message());
            stop();
            return ERROR_RETURN_CONSTANT;
          }
        }
        server
            = std::make_unique<port_reader<net::serial_port>>(ctx, std::move(serial_port), ppp, [this](std::error_code ec) { logger_->error("serial port problem: {}, stopping ...", ec.message()); });
#ifdef _WIN32
        class serial_port_wdog : public runnable
        {
          logger logger_ = LOGGER_FOR_CLASSNAME(serial_port_wdog);
          bool stopped_ = false;
          net::steady_timer timer_;
          application* thiz_;
          void on_expired(const net::error_code& timer_ec)
          {
            if (stopped_)
            {
              logger_->error("stopped");
              return;
            }
            if (timer_ec)
            {
              logger_->error("{}: timer error {}: {}", __func__, timer_ec.value(), timer_ec.message());
              return;
            }
            {
              net::serial_port tmp_port(timer_.get_executor());
              net::error_code ec;
              tmp_port.open(thiz_->config_.transport_path().data(), ec);
              if (ec == net::error::no_permission)
              {
                // it must be like that - ok
                do_reschedule();
                return;
              }
              else if (ec == net::error_code(ERROR_FILE_NOT_FOUND, net::error::get_system_category()))
              {
                logger_->error("serial port {} disappeared, stopping...", thiz_->config_.transport_path());
                stop();
                return;
              }
              else
              {
                logger_->error("unexpected error {}: {}, stopping...", ec.value(), ec.message());
                stop();
                return;
              }
            }
          }
          void do_reschedule()
          {
            timer_.expires_from_now(std::chrono::milliseconds(1000));
            timer_.async_wait(std::bind(&serial_port_wdog::on_expired, this, std::placeholders::_1));
          }

      public:
          explicit serial_port_wdog(net::io_context& ctx, application* thiz)
              : timer_(net::steady_timer(ctx))
              , thiz_(thiz)
          {
          }
          void run() override
          {
            stopped_ = false;
            do_reschedule();
          }
          void stop()
          {
            stopped_ = true;
            timer_.cancel();
            thiz_->stop();
          }
        };
        wdog = std::make_unique<serial_port_wdog>(ctx, this);
#endif //_WIN32
      }
      else
      {
#ifdef _WIN32
        server = std::make_unique<local_api_server<net::ip::tcp>>(ctx, ppp, config_.transport_path());
#else
        std::string api_endpoint_path;
        api_endpoint_path.reserve(config_.transport_path().size() + 1);
        api_endpoint_path.append(std::string_view { "\0", 1 });
        api_endpoint_path.append(config_.transport_path());
        server = std::make_unique<local_api_server<net::local::stream_protocol>>(ctx, ppp, std::string_view(api_endpoint_path.data(), api_endpoint_path.size()));
#endif
      }
      apps_.emplace_back(std::make_shared<__KKTNETD_NAMESPACE__::apps::resender_app>(ctx, config_.peer_ip(), config_.remote_port(), config_.resender_host(), config_.resender_port()));
      apps_.emplace_back(std::make_shared<__KKTNETD_NAMESPACE__::apps::socks5_app>(ctx, config_.our_ip(), config_.socks_port()));

      ppp.start_apps_cb(std::bind(&application::start_apps, this));
      ppp.stop_apps_cb(std::bind(&application::stop_apps, this));

      lwip_stack::run();
      logger_->info("lwip thread started");

      server->run();
      logger_->info("unix domain/tcp listener started");
#ifdef _WIN32
      if (wdog)
      {
        wdog->run();
        logger_->info("serial port watchdog started");
      }
#endif
      ppp.run();
      logger_->info("ppp interface started");

      logger_->info("starting io_context");
      pointer_setter ptr(this, &ppp);
      return ctx.run();
    }
    catch (const std::exception& e)
    {
      logger_->error("failed to start: {}", e.what());
      return ERROR_RETURN_CONSTANT;
    }
    catch (...)
    {
      logger_->error("failed to start: {}", "unknown reason");
      return ERROR_RETURN_CONSTANT;
    }

    return OK_RETURN_CONSTANT;
  }
  json::object status() const
  {
    if (!running_if_)
    {

      json::object o;
      o["status"] = "NOT_RUNNING";
      return o;
    }
    auto out = running_if_->status();
    out["status"] = "RUNNING";
    return out;
  }
};

KKTNETD_NAMESPACE_END

static __KKTNETD_NAMESPACE__::application* kktnetd_g_application = nullptr;
/**
 * @brief
 * @param name
 * @param size
 * @param flags BIT(0) - signals
 * @return
 */

#ifdef __cplusplus
extern "C"
{
#endif

  KKTNETD_LIB_API size_t kktnetd_run_app(const char* name, size_t size, uint32_t flags)
  {
    std::size_t ret;
    {
      json::value config = __KKTNETD_NAMESPACE__::application::DEFAULT_CONFIG;
      auto& config_o = config.as_object();
      if (flags & kktnetd_app_flags::watch_signals)
      {
        config_o["handle_signals"] = true;
      }
      auto& transport_o = config_o["transport"].as_object();
      if (flags & kktnetd_app_flags::use_serial)
      {
        transport_o["type"] = "serial";
        transport_o["path"] = std::string_view(name, size);
      }
      __KKTNETD_NAMESPACE__::application app(config);
      if (!kktnetd_g_application)
      {
        kktnetd_g_application = &app;
      }
      ret = app.run();
    }
    // we are stopped so null global app
    kktnetd_g_application = nullptr;
    return ret;
  }
  KKTNETD_LIB_API void kktnetd_stop_app()
  {
    if (!kktnetd_g_application)
    {
      return;
    }
    kktnetd_g_application->stop();
    kktnetd_g_application = nullptr;
  }

#ifdef __cplusplus
}
#endif

/*
 * Class:     ru_shtrihm_kktnetd_Api
 * Method:    start
 * Signature: (Ljava/lang/String;)I
 */
JNIEXPORT jint JNICALL Java_ru_shtrih_1m_kktnetd_Api_start(JNIEnv* env, jclass, jstring path)
{
  const char* utf_path = (env)->GetStringUTFChars(path, nullptr);
  auto anonymous_path = std::string("\0", 1);
  anonymous_path += std::string(utf_path);
  env->ReleaseStringUTFChars(path, utf_path);
  return kktnetd_run_app(anonymous_path.data(), anonymous_path.size(), 0);
}

/*
 * Class:     ru_shtrihm_kktnetd_Api
 * Method:    stop
 * Signature: ()V
 */
JNIEXPORT void JNICALL Java_ru_shtrih_1m_kktnetd_Api_stop(JNIEnv*, jclass) { kktnetd_stop_app(); }

/*
 * Class:     ru_shtrih_m_kktnetd_Api
 * Method:    api_init
 * Signature: (Ljava/lang/String;)J
 */
JNIEXPORT jlong JNICALL Java_ru_shtrih_1m_kktnetd_Api_api_1init(JNIEnv* env, jclass, jstring path)
{
  jlong result = 0;
  const char* utf_config = (env)->GetStringUTFChars(path, nullptr);
  if (utf_config)
  {
    std::string config { utf_config };
    result = (jlong)(kktnetd_api_init(config.data()));
  }
  else
  {
    result = (jlong)(kktnetd_api_init(nullptr));
  }
  env->ReleaseStringUTFChars(path, utf_config);
  return result;
}

/*
 * Class:     ru_shtrih_m_kktnetd_Api
 * Method:    api_run
 * Signature: (J)J
 */
JNIEXPORT jlong JNICALL Java_ru_shtrih_1m_kktnetd_Api_api_1run(JNIEnv*, jclass, jlong ctx_ptr)
{
  auto ctx = reinterpret_cast<kktnetd_api_context_t*>(ctx_ptr);
  return kktnetd_api_run(ctx);
}

/*
 * Class:     ru_shtrih_m_kktnetd_Api
 * Method:    api_stop
 * Signature: (J)V
 */
JNIEXPORT void JNICALL Java_ru_shtrih_1m_kktnetd_Api_api_1stop(JNIEnv*, jclass, jlong ctx_ptr)
{
  auto ctx = reinterpret_cast<kktnetd_api_context_t*>(ctx_ptr);
  return kktnetd_api_stop(ctx);
}

/*
 * Class:     ru_shtrih_m_kktnetd_Api
 * Method:    api_deinit
 * Signature: (J)V
 */
JNIEXPORT void JNICALL Java_ru_shtrih_1m_kktnetd_Api_api_1deinit(JNIEnv*, jclass, jlong ctx_ptr)
{
  auto ctx = reinterpret_cast<kktnetd_api_context_t*>(ctx_ptr);
  return kktnetd_api_deinit(ctx);
}

#ifdef __cplusplus

extern "C"
{
#endif
  struct kktnetd_api_context
  {
    kktnetd::application app;
    kktnetd_api_context(json::value config)
        : app(config)
    {
    }
  };

  kktnetd_api_context_t* kktnetd_api_init(const char* instance_config)
  {
    static auto logger = getMainLogger();
    logger->trace("{}({})", __func__, instance_config == nullptr ? "null" : instance_config);
    kktnetd_api_context* ctx = nullptr;
    try
    {
      if (instance_config)
      {
        json::error_code ec;
        auto config = json::parse(instance_config, ec);
        if (ec)
        {
          logger->error("unable to parse config json:{}", ec.message());
          return nullptr;
        }
        ctx = new kktnetd_api_context(config);
      }
      else
      {
        ctx = new kktnetd_api_context({});
      }
      logger->trace("{}() -> ctx_{}", __func__, static_cast<void*>(ctx));
      return ctx;
    }
    catch (const std::exception& e)
    {
      logger->error("{} unable to create context: {}", __func__, e.what());

      return nullptr;
    }
    catch (...)
    {
      return nullptr;
    }
  }
  int kktnetd_api_status(kktnetd_api_context_t* ctx, char* out, size_t out_size)
  {
    if (!out_size)
    {
      return kktnetd_failure;
    }
    static auto logger = getMainLogger();
    logger->trace("{}(ctx_{})", __func__, static_cast<void*>(ctx));
    auto status = ctx->app.status();
    std::string sstatus = json::serialize(status);
    auto last = std::copy_n(sstatus.begin(), std::min(out_size - 1, sstatus.size()), out);
    *last = 0;
    return kktnetd_ok;
  }

  size_t kktnetd_api_run(kktnetd_api_context_t* ctx)
  {
    static auto logger = getMainLogger();
    logger->trace("{}(ctx_{})", __func__, static_cast<void*>(ctx));
    return ctx->app.run();
  }
  void kktnetd_api_stop(kktnetd_api_context_t* ctx)
  {
    static auto logger = getMainLogger();
    logger->trace("{}(ctx_{})", __func__, static_cast<void*>(ctx));
    ctx->app.stop();
  }
  void kktnetd_api_deinit(kktnetd_api_context_t* ctx)
  {
    static auto logger = getMainLogger();
    logger->trace("{}(ctx_{})", __func__, static_cast<void*>(ctx));
    delete ctx;
  }
  JNIEXPORT jstring JNICALL Java_ru_shtrih_1m_kktnetd_Api_api_1status(JNIEnv* env, jclass, jlong ctx_ptr)
  {
    auto ctx = reinterpret_cast<kktnetd_api_context_t*>(ctx_ptr);
    auto out = ctx->app.status();
    std::string sout = json::serialize(out);
    auto result = env->NewStringUTF(sout.c_str());
    return result;
    ;
  }
#ifdef __cplusplus
}
#endif
