#ifndef KKTNETD_LWIP_STACK_IMPL_H
#define KKTNETD_LWIP_STACK_IMPL_H
#include <kktnet_common.h>

KKTNETD_NAMESPACE_BEGIN

struct lwip_stack_impl
{
  static void init();
};

KKTNETD_NAMESPACE_END

#endif // KKTNETD_LWIP_STACK_IMPL_H
