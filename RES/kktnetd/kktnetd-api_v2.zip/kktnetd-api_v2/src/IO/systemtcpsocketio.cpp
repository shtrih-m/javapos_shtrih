#include "systemtcpsocketio.h"
#include <IO/tcpsocketio.h>

KKTNETD_NAMESPACE_BEGIN

SystemTCPSocketIO::SystemTCPSocketIO(const kktnetd::u8string& host, uint16_t port)
    : IoLayer(LOGGER_FOR_CLASSNAME(SystemTCPSocketIO))
    , m_pimpl(std::make_unique<TcpSocketIO>(host, port))
{
}

SystemTCPSocketIO::~SystemTCPSocketIO() { }

bool SystemTCPSocketIO::doOpen() { return m_pimpl->open(); }

void SystemTCPSocketIO::doClose() { return m_pimpl->close(); }

int64_t SystemTCPSocketIO::doWrite(const char* data, size_t maxSize) { return m_pimpl->write(data, maxSize); }

int64_t SystemTCPSocketIO::doRead(char* data, size_t maxSize) { return m_pimpl->read(data, maxSize); }

IoLayer::ms SystemTCPSocketIO::byteTimeout() const { return m_pimpl->byteTimeout(); }

void SystemTCPSocketIO::setByteTimeout(const ms& byteTimeout) { return m_pimpl->setByteTimeout(byteTimeout); }

bool SystemTCPSocketIO::opened() const { return m_pimpl->opened(); }

bool SystemTCPSocketIO::clear() { return m_pimpl->clear(); }

SystemTCPSocketIO::Type SystemTCPSocketIO::type() const { return static_cast<SystemTCPSocketIO::Type>(m_pimpl->type()); }

void SystemTCPSocketIO::setType(const Type type) { m_pimpl->setType(static_cast<TcpSocketIO::Type>(type)); }
KKTNETD_NAMESPACE_END
