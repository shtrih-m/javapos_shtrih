﻿#include "tcpsocketio.h"
#include <spdlog/logger.h>

#ifdef _WIN32
const int MSG_NOSIGNAL = 0;
#endif
KKTNETD_NAMESPACE_BEGIN

TcpSocketIO::TcpSocketIO(const u8string& host, uint16_t port)
    : IoLayer(LOGGER_FOR_CLASSNAME(TcpSocketIO))
    , m_host(host)
    , m_port(port)
{
  m_logger->set_level(spdlog::level::info);
}

TcpSocketIO::~TcpSocketIO() { close(); }

void TcpSocketIO::setType(const Type type)
{
  if (opened())
  {
    return;
  }
  m_type = type;
}

bool TcpSocketIO::doOpen()
{
  if (m_type == Type::Server)
  {
    return listenAndWaitForClient();
  }
  m_logger->info("host: {}, port: {}", m_host, m_port);
  struct addrinfo hints, *servinfo = nullptr, *p = nullptr;
  memset(&hints, 0, sizeof hints);
  hints.ai_family = AF_UNSPEC;
  hints.ai_socktype = SOCK_STREAM;
#ifdef _WIN32
  WSADATA data;
  WSAStartup(MAKEWORD(2, 2), &data);
#endif
  auto ret = getaddrinfo(m_host.c_str(), std::to_string(m_port).c_str(), &hints, &servinfo);
  if (ret != 0)
  {
    return false;
  }
  for (p = servinfo; p != nullptr; p = p->ai_next)
  {
#ifdef _WIN32
    if ((sockfd = socket(p->ai_family, p->ai_socktype, p->ai_protocol)) == INVALID_SOCKET)
    {
#else
    if ((sockfd = socket(p->ai_family, p->ai_socktype, p->ai_protocol)) == -1)
    {
#endif
      continue;
    }
    configure();
    fd_set fds;
    FD_ZERO(&fds);
    FD_SET(sockfd, &fds);
    if (connect(sockfd, p->ai_addr, p->ai_addrlen) == -1)
    {
      if (!isInProgress())
      {
        internal_close();
        continue;
      }
    }
    if (waitForConnected())
    {
      break;
    }
  }
  if (p == nullptr)
  {
    freeaddrinfo(servinfo);
    return false;
  }
  freeaddrinfo(servinfo);
  return true;
}

void TcpSocketIO::doClose()
{
  std::lock_guard<std::recursive_mutex> lock(m_mutex);
#ifdef _WIN32
  shutdown(sockfd, SD_SEND);
#else
  ::shutdown(sockfd, SHUT_WR);
#endif
  char buf[10];
  while (::recv(sockfd, buf, sizeof(buf), MSG_NOSIGNAL) > 0) { }
#ifdef _WIN32
  ::shutdown(sockfd, SD_RECEIVE);
#else
  shutdown(sockfd, SHUT_RD);
#endif

  internal_close();
}

int64_t TcpSocketIO::doWrite(const char* data, size_t maxSize)
{
  struct timeval tv;
  memset(&tv, 0, sizeof(tv));
  fd_set fds;
  FD_ZERO(&fds);
  FD_SET(sockfd, &fds);
#ifdef _WIN32
  tv.tv_sec = static_cast<long>(byteTimeout().count() / 1000);
  tv.tv_usec = static_cast<long>((byteTimeout().count() % 1000) * 1000);
#else
  tv.tv_sec = static_cast<time_t>(byteTimeout().count() / 1000);
  tv.tv_usec = static_cast<long>((byteTimeout().count() % 1000) * 1000);
#endif
  int64_t ret = select(static_cast<int>(sockfd + 1), nullptr, &fds, nullptr, &tv);
  if (ret == -1)
  {
    if (errno == EINTR)
    {
      return 0;
    }
    m_logger->info("error: {}", strerror(errno));
    return ret;
  }
  if (FD_ISSET(sockfd, &fds))
  {
    ret = static_cast<int64_t>(::send(sockfd, data, static_cast<int>(maxSize), MSG_NOSIGNAL));
    if (ret == -1 && isSocketBroken())
    {
      close();
    }
    return ret;
  }
  return 0;
}

int64_t TcpSocketIO::doRead(char* data, size_t maxSize)
{
  std::lock_guard<std::recursive_mutex> lock(m_mutex);

  struct timeval tv;
  memset(&tv, 0, sizeof(tv));
  fd_set fds;
  fd_set efds;
  FD_ZERO(&fds);
  FD_SET(sockfd, &fds);
  FD_ZERO(&efds);
  FD_SET(sockfd, &efds);

#ifdef _WIN32
  tv.tv_sec = static_cast<long>(byteTimeout().count() / 1000);
  tv.tv_usec = static_cast<long>((byteTimeout().count() % 1000) * 1000);
#else
  tv.tv_sec = static_cast<time_t>(byteTimeout().count() / 1000);
  tv.tv_usec = static_cast<long>((byteTimeout().count() % 1000) * 1000);
#endif
  auto ret = select(static_cast<int>(sockfd + 1), &fds, nullptr, &efds, &tv);
  if (ret == -1)
  {
    if (errno == EINTR)
    {
      return 0;
    }
    m_logger->info("error: {}", strerror(errno));
    return -1;
  }
  if (FD_ISSET(sockfd, &fds))
  {
    ret = static_cast<int64_t>(::recv(sockfd, data, static_cast<int>(maxSize), MSG_NOSIGNAL));
    if (ret == -1 && isSocketBroken())
    {
      close();
    }

    if (m_type == Type::Server && ret == 0)
    {
      close();
      return -1;
    }

    return ret;
  }
  if (FD_ISSET(sockfd, &efds))
  {
    close();
    return -1;
  }
  return 0;
}

bool TcpSocketIO::clear()
{
  char buf[256];
  auto timeout_bak = byteTimeout();
  //не ждем в этом месте, просто читаем если вдруг что уже у ядра есть для нас.
  setByteTimeout(std::chrono::milliseconds(0));
  auto ret = (read(&buf[0], sizeof(buf)) > 0);
  setByteTimeout(timeout_bak);
  return ret;
}

bool TcpSocketIO::listenAndWaitForClient()
{
  if (opened())
  {
    return false;
  }
  listen_sockfd = socket(AF_INET, SOCK_STREAM, 0);
  if (listen_sockfd < 0)
  {
    m_logger->error("socket error:{}", strerror(errno));
    return false;
  }
  int reuse = 1;
  if (setsockopt(listen_sockfd, SOL_SOCKET, SO_REUSEADDR, (const char*)&reuse, sizeof(reuse)) < 0)
    log_error(m_logger, "setsockopt(SO_REUSEADDR) failed");
  sockaddr_in server;
  sockaddr client;
  server.sin_family = AF_INET;
  server.sin_addr.s_addr = INADDR_ANY;
  server.sin_port = htons(m_port);
  if (bind(listen_sockfd, (struct sockaddr*)&server, sizeof(server)) < 0)
  {
    // print the error message
    m_logger->error("bind error:{}", strerror(errno));
    ::close(listen_sockfd);
    return false;
  }
  auto ret = ::listen(listen_sockfd, 1);
  if (ret)
  {
    m_logger->error("listen error:{}", strerror(errno));
    ::close(listen_sockfd);
    return false;
  }
  socklen_t socklen;
  auto client_sock = accept(listen_sockfd, (struct sockaddr*)&client, (socklen_t*)&socklen);
  if (client_sock < 0)
  {
    m_logger->error("accept error:{}", strerror(errno));
    ::close(listen_sockfd);
    return false;
  }
  m_logger->info("client connection accepted: {}", client_sock);
  m_logger->info("closing listen socket: {}", listen_sockfd);
  ::close(listen_sockfd);
  listen_sockfd = -1;
  sockfd = client_sock;
  m_logger->info("conifguring client socket NONBLOCK");
  configure();
  return true;
}

TcpSocketIO::Type TcpSocketIO::type() const { return m_type; }

void TcpSocketIO::configure()
{
#ifdef _WIN32
  BOOL noDelay = TRUE;
  setsockopt(sockfd, IPPROTO_TCP, TCP_NODELAY, (char*)&noDelay, sizeof(noDelay));
  u_long nonBlocking = 1;
  ioctlsocket(sockfd, FIONBIO, &nonBlocking);
#else
  int reuse = 1;
  if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, (const char*)&reuse, sizeof(reuse)) < 0)
    log_error(m_logger, "setsockopt(SO_REUSEADDR) failed");

#ifdef SO_REUSEPORT
  if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEPORT, (const char*)&reuse, sizeof(reuse)) < 0)
    log_error(m_logger, "setsockopt(SO_REUSEPORT) failed");
#endif
  int one = 1;
  setsockopt(sockfd, SOL_TCP, TCP_NODELAY, &one, sizeof(one));
  int flags = fcntl(sockfd, F_GETFL, 0);
  fcntl(sockfd, F_SETFL, flags | O_NONBLOCK);
#endif
}

bool TcpSocketIO::isSocketBroken()
{
#ifdef _WIN32
  return WSAGetLastError() == WSAENETRESET;
#else
  auto rr = errno;
  return errno == EPIPE;
#endif
}

bool TcpSocketIO::waitForConnected()
{
  struct timeval tv;
  memset(&tv, 0, sizeof(tv));

#ifdef _WIN32
  tv.tv_sec = static_cast<long>(byteTimeout().count() / 1000);
  tv.tv_usec = static_cast<long>((byteTimeout().count() % 1000) * 1000);
#else
  tv.tv_sec = static_cast<time_t>(byteTimeout().count() / 1000);
  tv.tv_usec = static_cast<long>((byteTimeout().count() % 1000) * 1000);
#endif
#ifdef _WIN32
  /**
   * In Windows, you determine if the socket is connected by looking
   * at the return value of "select" in your code above.
   * In windows, select returns 1
   */
  if (select(static_cast<int>(sockfd + 1), NULL, &fds, NULL, &tv) == 1)
    return true;

  internal_close();
  return false;
#else
  fd_set fds;
  FD_ZERO(&fds);
  FD_SET(sockfd, &fds);
  auto ret = select(sockfd + 1, nullptr, &fds, nullptr, &tv);
  if (ret > 0 && FD_ISSET(sockfd, &fds))
  {
    int so_error;
    socklen_t len = sizeof so_error;
    getsockopt(sockfd, SOL_SOCKET, SO_ERROR, &so_error, &len);

    if (so_error == 0)
    {
      return true;
    }
    m_logger->error("error:{}", strerror(so_error));
    internal_close();
    return false;
  }
  if (ret == 0)
  {
    m_logger->error("error:{}", strerror(ETIMEDOUT));
    internal_close();
    return false;
  }
  else
  {
    m_logger->error("error:{}", strerror(errno));
    internal_close();
    return false;
  }
#endif
}

bool TcpSocketIO::isInProgress()
{
#ifdef _WIN32
  int error = WSAGetLastError();
  return error == WSAEINPROGRESS || error == WSAEWOULDBLOCK;
#else
  return errno == EINPROGRESS || errno == EWOULDBLOCK;
#endif
}

void TcpSocketIO::internal_close()
{
#ifdef _WIN32
  closesocket(sockfd);
#else

  int ret;
  if (sockfd >= 0)
  {
    ret = ::close(sockfd);
    if (ret)
    {
      m_logger->error("error: {} ", strerror(errno));
    }
    sockfd = -1;
  }
#endif
}
KKTNETD_NAMESPACE_END
