﻿#ifndef IOLAYER_H
#define IOLAYER_H

#include <chrono>
#include <cstdint>
#include <functional>
#include <memory>
#include <mutex>
#include <utils/log.h>
#include <vector>

KKTNETD_NAMESPACE_BEGIN

class IoLayer
{
  protected:
  logger m_logger;

  private:
  u8string m_readAccum;
  u8string m_writeAccum;
  bool m_accumulateIO;
  enum PrevOperationState
  {
    READ,
    WRITE,
  } m_lastOp { READ };

  public:
  using ms = std::chrono::milliseconds;
  using s = std::chrono::seconds;

  static constexpr const ms defaultByteTimeout { 10000 };
  void setLogLevel(spdlog::level::level_enum level);
  spdlog::level::level_enum logLevel() const;
  explicit IoLayer(logger logger, bool accumulateIO = false);
  IoLayer(const IoLayer&) = delete;
  IoLayer(const IoLayer&&) = delete;
  IoLayer& operator=(const IoLayer&) = delete;
  IoLayer& operator=(const IoLayer&&) = delete;

  private:
  ms m_byteTimeout = ms { defaultByteTimeout };
  bool m_opened = false;

  public:
  /**
   * @brief opening port
   * @return true if success, false otherwise
   */
  bool open();

  protected:
  virtual bool doOpen() = 0;

  public:
  /**
   * @brief close trying to silently close port.
   */
  void close();

  protected:
  virtual void doClose() = 0;

  public:
  /**
   * @brief write data to port
   * @param data to write
   * @param maxSize up to bytes from data
   * @return number of bytes actually written, -1 if error
   */
  int64_t write(const char* data, size_t maxSize);

  protected:
  virtual int64_t doWrite(const char* data, size_t maxSize) = 0;

  public:
  /**
   * @brief read data from port
   * @param data to read
   * @param maxSize up to bytes from port
   * @return number of bytes actually read, -1 if error
   */
  int64_t read(char* data, size_t maxSize);

  protected:
  virtual int64_t doRead(char* data, size_t maxSize) = 0;

  public:
  virtual ~IoLayer();
  /**
   * @brief timeout
   * @return current port operation timeout in ms
   */
  virtual ms byteTimeout() const;
  /**
   * @brief setByteTimeout
   * @param byteTimeout new per byte timeout
   */
  virtual void setByteTimeout(const ms& byteTimeout);
  /**
   * @brief opened check current open state
   * @return true if opened, false otherwise
   */
  virtual bool opened() const;
  /**
   * @brief clear port device buffers, discard all cached data
   * @return true if succsess.false otherwise
   */
  virtual bool clear();

  bool accumulateIO() const;
  void setAccumulateIO(bool accumulateIO);
};
KKTNETD_NAMESPACE_END
#endif // IOLAYER_H
