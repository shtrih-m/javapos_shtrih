//
// Created by swex on 8/17/21.
//

#ifndef KKTNETD_LWIP_PPP_INTERFACE_H
#define KKTNETD_LWIP_PPP_INTERFACE_H
#include <kktnet_common.h>
#include <memory>

KKTNETD_NAMESPACE_BEGIN

class lwip_ppp_interface
{
  struct impl;
};
KKTNETD_NAMESPACE_END
#endif // KKTNETD_LWIP_PPP_INTERFACE_H
