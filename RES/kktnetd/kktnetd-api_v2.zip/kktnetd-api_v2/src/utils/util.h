﻿#ifndef UTIL_H
#define UTIL_H

#include <algorithm>
#include <array>
#include <cassert>
#include <cctype>
#include <cerrno>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <exception>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <kktnet_common.h>
#include <memory>
#include <sstream>
#include <stdexcept>
#include <string>
#include <system_error>
#include <type_traits>
#include <utility>
#include <vector>

KKTNETD_NAMESPACE_BEGIN
/**
 * @brief localtime thread safe
 * @param time
 * @return
 */
std::tm localtime(std::time_t time);

class Util
{
  public:
  template <class IteratorT> static uint8_t crc(const IteratorT& begin, const IteratorT& end, uint8_t init = 0)
  {
    uint8_t crc = init;
    auto it = begin;
    while (it != end)
    {
      crc ^= *it;
      it++;
    }
    return crc;
  }

  template <class ContainerT> static uint8_t crc(const ContainerT& container, uint8_t init = 0) { return crc(std::begin(container), std::end(container), init); }

  template <class IteratorT> static uint16_t crc16_ccit(const IteratorT& begin, const IteratorT& end, uint16_t init = 0xFFFF)
  {
    uint16_t crc = init;
    auto it = begin;
    while (it != end)
    {
      crc = ((crc >> 0x08) | (crc << 0x08)) & 0xFFFF;
      crc ^= *it & 0xFF;
      crc ^= ((crc & 0xFF) >> 0x04);
      crc ^= (crc << 0x0C) & 0xFFFF;
      crc ^= ((crc & 0xFF) << 0x05) & 0xFFFF;
      it++;
    }
    return crc;
  }

  template <class ContainerT> static uint16_t crc16_ccit(const ContainerT& container, uint16_t init = 0xFFFF) { return crc16_ccit(std::begin(container), std::end(container), init); }
  /**
   * @brief rtrim trim given string from rigth using std::isspace
   * @param s string to trim
   * @return reference to s
   */
  template <class CharT, class TraitsT> static std::basic_string<CharT, TraitsT>& rtrim(std::basic_string<CharT, TraitsT>& s)
  {
    s.erase(std::find_if_not(s.rbegin(), s.rend(), [](int c) { return std::isspace(c); }).base(), s.end());
    return s;
  }
  /**
   * @brief ltrim trim given string from left using std::isspace
   * @param s string to trim
   * @return reference to s
   */
  template <class CharT, class TraitsT> static std::basic_string<CharT, TraitsT>& ltrim(std::basic_string<CharT, TraitsT>& s)
  {
    s.erase(s.begin(), std::find_if_not(s.begin(), s.end(), [](int c) { return std::isspace(c); }));
    return s;
  }
  /**
   * @brief trim trim given string form both sides using std::isspace
   * @param s string to trim
   * @return reference to s
   */
  template <class CharT, class TraitsT> static std::basic_string<CharT, TraitsT>& trim(std::basic_string<CharT, TraitsT>& s) { return ltrim(rtrim(s)); }

  template <typename ContainerT, typename std::enable_if<sizeof(typename std::remove_reference<ContainerT>::type::value_type) == 1>::type* = nullptr>
  static void putBitToPos(ContainerT&& container, std::size_t pos)
  {
    Util::putBitToPos(container.data(), pos);
  }

  template <typename ContainerT, typename std::enable_if<sizeof(typename ContainerT::value_type) == 1>::type* = nullptr> static uint8_t getBitAtPos(const ContainerT& container, std::size_t pos)
  {
    return Util::getBitAtPos(container.data(), pos);
  }
  static bool digitOrSpace(int c);

  public:
  static const uint8_t bitpos[8];

  public:
  static void putBitToPos(uint8_t* bits, size_t pos);
  static uint8_t getBitAtPos(const uint8_t* bits, size_t pos);
  static uint8_t reverseByte(uint8_t byte);
};

KKTNETD_NAMESPACE_END

#if !defined(_MSC_VER)
#if __cplusplus < 201402L
#ifndef __ANDROID__
#if defined(__GNUC__) || defined(__GNUG__)
namespace std
{
template <class T> struct _Unique_if
{
  typedef std::unique_ptr<T> _Single_object;
};

template <class T> struct _Unique_if<T[]>
{
  typedef std::unique_ptr<T[]> _Unknown_bound;
};

template <class T, size_t N> struct _Unique_if<T[N]>
{
  typedef void _Known_bound;
};

template <class T, class... Args> typename _Unique_if<T>::_Single_object make_unique(Args&&... args) { return std::unique_ptr<T>(new T(std::forward<Args>(args)...)); }

template <class T> typename _Unique_if<T>::_Unknown_bound make_unique(size_t n)
{
  typedef typename remove_extent<T>::type U;
  return std::unique_ptr<T>(new U[n]());
}

template <class T, class... Args> typename _Unique_if<T>::_Known_bound make_unique(Args&&...) = delete;
} // namespace std
#endif // (__GNUC__) || (__GNUG__)
#endif //__ANDROID__
#endif // __cplusplus < 201402L
#endif // !defined(_MSC_VER)

#endif // UTIL_H
