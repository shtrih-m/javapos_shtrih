//
// Created by swex on 8/20/21.
//

#include "asio_util.h"
#include <asio/error.hpp>
#include <stdexcept>
#include <system_error>

KKTNETD_NAMESPACE_BEGIN
namespace asio_util
{
const std::error_category& get_system_category() { return asio::error::get_system_category(); }
const std::error_category& get_misc_category() { return asio::error::get_misc_category(); }
const std::error_category& get_addrinfo_category() { return asio::error::get_addrinfo_category(); }
const std::error_category& get_netdb_category() { return asio::error::get_netdb_category(); }

}; // namespace asio_util
KKTNETD_NAMESPACE_END