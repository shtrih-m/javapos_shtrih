#include "lwipsockets.h"
#include <lwip/sockets.h>

KKTNETD_NAMESPACE_BEGIN

int lwip_accept(int s, sockaddr* addr, socklen_t* addrlen) { return ::lwip_accept(s, addr, addrlen); }

int lwip_bind(int s, const sockaddr* name, socklen_t namelen) { }

KKTNETD_NAMESPACE_END
