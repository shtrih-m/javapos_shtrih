#ifndef LWIPCORELOCKER_H
#define LWIPCORELOCKER_H

#include <kktnet_common.h>

KKTNETD_NAMESPACE_BEGIN
struct LWIPCoreLocker
{
  LWIPCoreLocker();
  ~LWIPCoreLocker();
};
KKTNETD_NAMESPACE_END
#endif // LWIPCORELOCKER_H
