﻿#include "log.h"
#include <spdlog/cfg/helpers.h>
#include <spdlog/fmt/fmt.h>
#include <spdlog/logger.h>
#include <spdlog/sinks/ansicolor_sink.h>
#include <spdlog/sinks/basic_file_sink.h>
#include <spdlog/sinks/rotating_file_sink.h>
#include <spdlog/sinks/sink.h>
#include <spdlog/spdlog.h>

#if defined(__ANDROID__)
#include <spdlog/sinks/android_sink.h>
#include <sys/system_properties.h>
#include <utils/util.h>
#endif //__ANDROID__
#ifdef _WIN32
#include <Windows.h>
#include <spdlog/sinks/wincolor_sink.h>
#else // all posix goes here
#include <sys/utsname.h>
#endif

KKTNETD_NAMESPACE_BEGIN

static constexpr const char* DEFAULT_LOG_PATH { "kktnetd.log" };

static bool g_console_log_failsafe = false;

static std::shared_ptr<spdlog::sinks::sink> createConsoleLogSink()
{
  {
#if defined(_WIN32)
    return std::make_shared<spdlog::sinks::wincolor_stderr_sink_mt>();
#elif defined(__ANDROID__)
    return std::make_shared<spdlog::sinks::android_sink_mt>("kktnetd");
#elif defined(__unix__)
    return std::make_shared<spdlog::sinks::ansicolor_stderr_sink_mt>();
#endif
  }
}

std::shared_ptr<spdlog::sinks::sink> createLogSink()
{

  if (getenv("KKTNETD_DEBUG_CONSOLE") != nullptr)
  {
    return createConsoleLogSink();
  }

  auto log_path = DEFAULT_LOG_PATH;
  auto clog_path = getenv("KKTNETD_LOG_PATH");
  if (clog_path != nullptr)
  {
    log_path = clog_path;
  }
  auto clog_fileCount = getenv("KKTNETD_LOG_FILE_COUNT");
  size_t log_files = 2;
  if (clog_fileCount != nullptr)
  {
    try
    {
      log_files = std::stoul(clog_fileCount);
    }
    catch (...)
    {
    }
  }
  auto clog_fileSize = getenv("KKTNETD_LOG_PART_SIZE");
  size_t log_part_size = 1024 * 1024 * 10;
  if (clog_fileSize != nullptr)
  {
    try
    {
      log_part_size = std::stoul(clog_fileSize);
    }
    catch (...)
    {
    }
  }
  try
  {
    if (log_part_size == 0 && log_files == 1)
    {
      // in case of 1 log file and 0 part size use single file(for logrotate copytruncate
      // users)
      auto sink = std::make_shared<spdlog::sinks::basic_file_sink_mt>(log_path);
      return sink;
    }
    auto sink = std::make_shared<spdlog::sinks::rotating_file_sink_mt>(log_path, log_part_size, log_files);
    return sink;
  }
  catch (...)
  {
    g_console_log_failsafe = true;
    return createConsoleLogSink();
  }
}

static bool logInit(spdlog::sink_ptr sink)
{
  spdlog::set_pattern("[%Y-%m-%d %H:%M:%S.%e] [%t] [%n] %^[%L] %v%$");
  auto log = std::make_shared<spdlog::logger>(fmt::format("{:<32}", "kktnetd"), sink);
  log->set_pattern("[%Y-%m-%d %H:%M:%S.%e] [%t] [%n] %^[%L] %v%$");
  log->set_level(spdlog::level::info);

  log->info("----------------------------------------------------------------------------------"
            "------------------");
  log->info("kktnetd log start!");
  log->info("cppbase version: {} ", APPLICATION_VERSION);
  if (g_console_log_failsafe)
  {
    log->warn("driver was unable to open log file path. fallback to console sink");
  }
  {

#if defined(__ANDROID__)
    std::string os;
    char model[PROP_VALUE_MAX];
    char version[PROP_VALUE_MAX];
    char arch[PROP_VALUE_MAX];
    __system_property_get("ro.product.model", model);
    __system_property_get("ro.build.version.release", version);
    __system_property_get("ro.product.cpu.abi", arch);
    os += model;
    os += " Android";
#elif defined(_WIN32)
    const char* os = "Windows";
    OSVERSIONINFO osv;
    SYSTEM_INFO si;
    ZeroMemory(&osv, sizeof(OSVERSIONINFO));
    osv.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
    GetVersionEx(&osv);
    GetSystemInfo(&si);
    const auto version = fmt::format("{}.{}", osv.dwMajorVersion, osv.dwMinorVersion);
    const char* arch = si.wProcessorArchitecture == PROCESSOR_ARCHITECTURE_AMD64 ? "x86_64" : "x86";
#else // posix
    struct utsname uname_out = {};
    ::uname(&uname_out);
    const char* os = &uname_out.sysname[0];
    const char* version = &uname_out.release[0];
    const char* arch = &uname_out.machine[0];
#endif // os detect
    log->info("OS: {} {}", os, version);
    log->info("ARCH: {}", arch);
  }
  spdlog::set_default_logger(log);

  spdlog::set_level(spdlog::level::info);
  return true;
}
static std::string cutPrefix(std::string prefix, size_t maxSize = 32)
{
  if (prefix.size() <= maxSize)
  {
    return prefix;
  }
  return (prefix.substr(0, maxSize - 1) + u8"…");
}
logger getLog(const std::string& prefix) noexcept
{
  static auto my_sink = createLogSink();
  static auto init = logInit(my_sink);
  static_cast<void>(init);
  auto fmt_prefix = fmt::format("{:<32}", cutPrefix(prefix));
  auto log = spdlog::get(fmt_prefix);
  if (log)
  {
    return log;
  }
  log = std::make_shared<spdlog::logger>(fmt_prefix, my_sink);
  return log;
}
static bool setLogCallbackCalled(void (*const func)(const std::string&)) { return true; }

void log_debug(logger logger, std::string_view message) { logger->debug(message); }

void log_trace(logger logger, std::string_view message) { logger->trace(message); }

void log_error(logger logger, std::string_view message) { logger->error(message); }

void log_info(logger logger, std::string_view message) { logger->info(message); }

void log_set_level(logger logger, spdlog::level::level_enum level) { logger->set_level(level); }

void log_levels(std::string_view levels)
{
  spdlog::default_logger()->info("set logging levels to: {}", levels.data());
  spdlog::cfg::helpers::load_levels(string(levels));
}

KKTNETD_NAMESPACE_END
