#ifndef KKTPPPNETIFROUTINE_H
#define KKTPPPNETIFROUTINE_H

#include <IO/iolayer.h>
#include <asio/buffer.hpp>
#include <utils/log.h>

#include <boost/json/object.hpp>

extern "C"
{
  struct netif;
  struct ppp_pcb_s;
}

KKTNETD_NAMESPACE_BEGIN

struct pppos_if
{
  struct impl;
  using pppos_output_fn = std::function<uint32_t(net::const_buffer)>;
  using start_apps_fn = std::function<void()>;
  using stop_apps_fn = std::function<void()>;

  public:
  enum class Mode
  {
    Server,
    Client,
  };

  public:
  explicit pppos_if(Mode, std::string_view our_ip, std::string_view peer_ip, std::string_view peer_dns);
  ~pppos_if();
  struct netif* netif();
  void input(net::const_buffer buf);
  void output_cb(pppos_output_fn output);
  void start_apps_cb(start_apps_fn fn);
  void stop_apps_cb(stop_apps_fn fn);

  public:
  void run();
  boost::json::object status() const;

  private:
  std::unique_ptr<impl> m_impl;
};
KKTNETD_NAMESPACE_END
#endif // KKTPPPNETIFROUTINE_H
