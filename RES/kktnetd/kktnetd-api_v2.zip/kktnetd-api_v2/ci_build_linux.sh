#!/bin/bash
set -e
BASE_ENVS_PATH=~/cross_envs/output
MEM_MB=$(free -m -t|tail -n1|sed 's/|/ /' | awk '{print $2 }')
CPU_NUM=$(echo "$MEM_MB / 1536"|bc) #1.5 gb ram per process
GIT_LAST_TAG=$(git describe --always --tags|cut -f1 -d-)
GIT_COMMITS_COUNT=$(git rev-list --count HEAD)
GIT_VERSION=$GIT_LAST_TAG.$GIT_COMMITS_COUNT

function copy_deps()
{
    FILEPATH=$1
    deps=$(readelf -d $FILEPATH |grep NEEDED|sed -r -e 's/^.*Shared library:[[:space:]]+\[([^]]+)\].*/\1/;'\
    | sed 's/,$/\n/')
    echo $deps
    for dep in $deps
    do
        echo $dep
        if [ -e "$DIST_OUT_COPY_PATH""$dep" ]
        then
            ln -s "../$dep" "$DIST_OUT_COPY_PATH""libs/$dep"
        fi
        if [ -e "$LIBPATH4/$dep" ]
        then
            cp "$LIBPATH4/$dep" "$DIST_OUT_COPY_PATH""libs/$dep"
        fi
        if [ -e "$LIBPATH3/$dep" ]
        then
            cp "$LIBPATH3/$dep" "$DIST_OUT_COPY_PATH""libs/$dep"
        fi
        if [ -e "$LIBPATH2/$dep" ]
        then
            cp "$LIBPATH2/$dep" "$DIST_OUT_COPY_PATH""libs/$dep"
        fi
        if [ -e "$LIBPATH/$dep" ]
        then
            cp "$LIBPATH/$dep" "$DIST_OUT_COPY_PATH""libs/$dep"
        fi
    done
}



function compile()
{
    local ARCH=$1
    echo "compiling for $ARCH"
    local PATH=$PATH:$BASE_ENVS_PATH/$ARCH/bin:$BASE_ENVS_PATH/$ARCH/*-buildroot-linux-*/bin
    LIBPATH=($BASE_ENVS_PATH/$ARCH/host/*-buildroot-linux-*/lib)
    LIBPATH2=($BASE_ENVS_PATH/$ARCH/host/*-buildroot-linux-*/usr/lib)
    LIBPATH3=($BASE_ENVS_PATH/$ARCH/host/*-buildroot-linux-*/sysroot/lib)
    LIBPATH4=($BASE_ENVS_PATH/$ARCH/host/*-buildroot-linux-*/sysroot/usr/lib)
    mkdir -p build/$ARCH
    mkdir -p dist/linux_$GIT_VERSION/$ARCH/libs
    cd build/$ARCH
    cmake ../../ -DCMAKE_TOOLCHAIN_FILE=$BASE_ENVS_PATH/$ARCH/host/share/buildroot/toolchainfile.cmake -DCMAKE_BUILD_TYPE=Release 
    make kktnetd -j$CPU_NUM
    DIST_OUT_COPY_PATH="../../dist/linux_$GIT_VERSION/$ARCH/"
    mv kktnetd $DIST_OUT_COPY_PATH/
    cmake ../../ -DCMAKE_TOOLCHAIN_FILE=$BASE_ENVS_PATH/$ARCH/host/share/buildroot/toolchainfile.cmake  -Dkktnetd_SHARED_LIBS=ON -DCMAKE_BUILD_TYPE=Release 
    make kktnetd-lib
    mv libkktnetd.so $DIST_OUT_COPY_PATH/
    cd ../../
}

compile "$1"
