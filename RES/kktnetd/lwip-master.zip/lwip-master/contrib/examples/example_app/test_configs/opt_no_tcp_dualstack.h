#include "test_configs/opt_dualstack.h"

#undef LWIP_TCP
#define LWIP_TCP 0
