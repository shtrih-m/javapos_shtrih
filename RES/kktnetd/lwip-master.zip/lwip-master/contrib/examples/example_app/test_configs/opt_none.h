/* test and empty lwipopts.h file */

