package com.shtrih.util;


public class SysUtils {

    public static String getFilesPath() {
        return "";
    }

    public static void sleep(long millis) throws InterruptedException 
    {
        Thread.sleep(millis);
    }
}
