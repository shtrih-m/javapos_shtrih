********************************************************************************

  Project : SHTRIH-M JavaPOS fiscal printer driver
  Company : SHTRIH-M www.shtrih-m.ru (095) 787-6090

********************************************************************************

1. Driver uses libraries:

   log4j-1.2.12.jar - APACHE log 
   comm.jar         - SUN serial port API